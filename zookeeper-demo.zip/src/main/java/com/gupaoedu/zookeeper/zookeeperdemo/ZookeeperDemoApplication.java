package com.gupaoedu.zookeeper.zookeeperdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZookeeperDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZookeeperDemoApplication.class, args);
    }

}
