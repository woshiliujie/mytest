package com.gupaoedu.zookeeper.zookeeperdemo;

import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

import java.io.IOException;

/**
 * Created by liuji on 2021/6/19.
 */
public class WatchDemo {

    public static void main(String[] args) throws IOException, KeeperException, InterruptedException {
        ZooKeeper zk = new ZooKeeper("localhost:" + 2181, 30000, new Watcher() {
            // 监控所有被触发的事件
            public void process(WatchedEvent event) {
                System.out.println(event.getPath() + "已经触发了" + event.getType() + "事件！");
            }
        });
        Stat stat = new Stat();
        zk.getData("/test", new Watch() ,stat);
        zk.exists()
        System.in.read();
    }
}

class Watch implements  Watcher{
    @Override
    public void process(WatchedEvent watchedEvent) {
        System.out.println("-----"+watchedEvent.getPath()+"----"+watchedEvent.getType());
    }
}
