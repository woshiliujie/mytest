package com.wyj.springboot.im.tools;

public class NET_Session_Body {
  private String sno;
  private String sessionId;
  private String serverip;
  private Long serverport;
public String getServerip() {
	return serverip;
}
public void setServerip(String serverip) {
	this.serverip = serverip;
}
public Long getServerport() {
	return serverport;
}
public void setServerport(Long serverport) {
	this.serverport = serverport;
}
public String getSno() {
	return sno;
}
public void setSno(String sno) {
	this.sno = sno;
}
public String getSessionId() {
	return sessionId;
}
public void setSessionId(String sessionId) {
	this.sessionId = sessionId;
}
}
