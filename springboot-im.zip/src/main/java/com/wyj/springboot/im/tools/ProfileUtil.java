package com.wyj.springboot.im.tools;

import java.util.concurrent.atomic.AtomicInteger;

public class ProfileUtil {

    private static AtomicInteger counter = new AtomicInteger(0);

    /**
     * 长生消息id
     */
    public static long getAtomicCounter() {
        if (counter.get() > 10000000) {
            counter.set(1);
        }
        long time = System.currentTimeMillis();
        String timeStr=String.valueOf(time);
        long returnValue =Long.parseLong(timeStr.substring(timeStr.length()-7, timeStr.length())) ;
        return returnValue;
    }

    private static long incrementAndGet() {
        return counter.incrementAndGet();
    }

    public static void main(String[] args) {
         
        System.out.println(ProfileUtil.getAtomicCounter());
    }
    
     
}