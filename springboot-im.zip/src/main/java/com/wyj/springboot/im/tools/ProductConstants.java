package com.wyj.springboot.im.tools;

public class ProductConstants {
	public static final String IP="123.56.102.186";//服务器ip
	public static final String PORTRAIT_REQUEST="/App/images/portrait/";
	public static final String PORTRAIT_PATH="/static/App/images/portrait/";//用户头像上传保存路径
	
	
	public static final int SUCCESS = 1;
	
	public static final int FAILED = -1;
	
	
}
