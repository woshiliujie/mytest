package com.wyj.springboot.im;

import java.io.IOException;

import org.apache.catalina.Context;
import org.apache.catalina.connector.Connector;
import org.apache.tomcat.util.descriptor.web.SecurityCollection;
import org.apache.tomcat.util.descriptor.web.SecurityConstraint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ImApplication {

	private static Logger logger = LoggerFactory.getLogger(ImApplication.class);
	
	public static void main(String[] args) throws IOException {
		SpringApplication app = new SpringApplication(ImApplication.class);
		app.run(args);
		logger.info("ImApplication 程序启动成功！！");
	}
//	  @Bean
//      public EmbeddedServletContainerFactory servletContainerFactory () {
//          TomcatEmbeddedServletContainerFactory tomcat = new TomcatEmbeddedServletContainerFactory() {
//              @Override
//              protected void postProcessContext(Context context) {
//                  SecurityConstraint securityConstraint = new SecurityConstraint();
//                  securityConstraint.setUserConstraint("CONFIDENTIAL");
//                  SecurityCollection collection = new SecurityCollection();
//                  collection.addPattern("/*");
//                  securityConstraint.addCollection(collection);
//                  context.addConstraint(securityConstraint);
//              }
//          };
//  
//          tomcat.addAdditionalTomcatConnectors(initiateHttpConnector());
//          return tomcat;
//      }
//  
//      private Connector initiateHttpConnector() {
//          Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
//          connector.setScheme("http");
//          connector.setPort(8989);
//          connector.setSecure(false);
//          connector.setRedirectPort(8090);
//  
//          return connector;
//      }

}
