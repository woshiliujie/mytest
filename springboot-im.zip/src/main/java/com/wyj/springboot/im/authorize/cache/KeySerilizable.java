package com.wyj.springboot.im.authorize.cache;

/**
 * 
 * @author 郑龙
 * @date 2017年10月20日
 */

public interface KeySerilizable<K> {
	String serilizableKey(K key);
}
