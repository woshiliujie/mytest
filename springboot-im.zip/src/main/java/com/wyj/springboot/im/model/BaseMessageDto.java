package com.wyj.springboot.im.model;

public class BaseMessageDto {
  public Object getHeader() {
		return header;
	}
	public void setHeader(Object header) {
		this.header = header;
	}
	public Object getBody() {
		return body;
	}
	public void setBody(Object body) {
		this.body = body;
	}
	public BaseResultDto getResult() {
		return result;
	}
	public void setResult(BaseResultDto result) {
		this.result = result;
	}
private Object header;
  private Object body;
  private BaseResultDto result;
}
