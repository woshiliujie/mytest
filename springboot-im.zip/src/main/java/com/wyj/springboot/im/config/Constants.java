package com.wyj.springboot.im.config;

/**
 * 
 * @author 郑龙
 * @date 2017年9月29日
 */

public class Constants {
	/** 用户过期时间 单位 s */
	public static final int HEADER_USER_TOKEN_EXPIRED = 30*60*2*24*365*10;
	
	
	
	public static final int HEADER_USER_TOKEN_NO_EXPIRED = 30*60*2*24*365*10;
	
	/** 开始一把新游戏的初始底子  **/
	public static final int GAME_INIT_BASE_COST = 1000;
	public static final String HEADER_KEY_HEARBEAT_KEY = "heartbeat";
	
	public static final String HEADER_KEY_LINK_KEY = "LINK";//相机的seesionId
	public static final String HEADER_KEY_CONFILICT_KEY = "conflictsno";//冲突的相机sno
	
	public static final String HEADER_KEY_IPNC_KEY = "IPNC";//相机的seesionId
}
