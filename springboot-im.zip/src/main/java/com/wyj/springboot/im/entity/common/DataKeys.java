package com.wyj.springboot.im.entity.common;

/**
 * 
 * @author 郑龙
 * @date 2017年11月14日
 */

public class DataKeys {
	public static final String MSG = "msg";
	
	public static final String CODE = "code";
	
	public static final String CONTENT = "content";
}
