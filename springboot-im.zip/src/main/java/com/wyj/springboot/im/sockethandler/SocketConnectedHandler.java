package com.wyj.springboot.im.sockethandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.corundumstudio.socketio.annotation.OnConnect;
import com.corundumstudio.socketio.annotation.OnDisconnect;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wyj.springboot.im.authorize.cache.RedisCacheManager;
import com.wyj.springboot.im.authorize.cache.keymodel.UserCacheKey;
import com.wyj.springboot.im.authorize.cookie.HeaderFactory;
import com.wyj.springboot.im.authorize.cookie.UserHeaderContainer;
import com.wyj.springboot.im.config.BeanIocConfig;
import com.wyj.springboot.im.config.Constants;
import com.wyj.springboot.im.entity.User;
import com.wyj.springboot.im.exception.ZJHRuntimeException;
import com.wyj.springboot.im.model.NET_Session_Body;
import com.wyj.springboot.im.service.IRedisService;
import com.wyj.springboot.im.sockethandler.entity.UserInCache;
import com.wyj.springboot.im.sockethandler.room.RoomContext;
import com.wyj.springboot.im.sockethandler.utils.GsonUtil;
import com.wyj.springboot.im.socketnio.NettySocketServer;
import com.wyj.springboot.im.tools.StringUtil;

/**
 * 
 * @author 郑龙
 * @date 2017年11月23日
 */

@Component
public class SocketConnectedHandler {

	private static final Logger logger = LoggerFactory.getLogger(SocketConnectedHandler.class);
	
	private final SocketIOServer server;
	private int redistimeout=60*1;
	public static final Map<String, UserInCache> clientMap = Collections.synchronizedMap(new HashMap<>());
	
	@Resource(name=BeanIocConfig.USER_CACHE)
	private RedisCacheManager<UserCacheKey, User> userCache;
	
	
	@Resource(name=BeanIocConfig.USER_NO_CACHE)
	private RedisCacheManager<UserCacheKey, User> userNoCache;
	
	@Autowired
	public SocketConnectedHandler(NettySocketServer socketServer) {
		this.server = socketServer.getServer();
	}
	@Resource
	IRedisService redisService;
	@Autowired
	private StringRedisTemplate template;
	@OnConnect
	public void onConnect(SocketIOClient socketIOClient) {
		String sno = socketIOClient.getHandshakeData().getSingleUrlParam(HeaderFactory.HEADER_KEY_SNO_KEY);
		String connect = socketIOClient.getHandshakeData().getSingleUrlParam(HeaderFactory.COOKIE_KEY_CONNECT_KEY);
		String token = socketIOClient.getHandshakeData().getSingleUrlParam(HeaderFactory.HEADER_KEY_USER_TOKEN);
		
		String serverip = socketIOClient.getHandshakeData().getSingleUrlParam(HeaderFactory.COOKIE_KEY_SERVERIP_KEY);
		
		String serverport = socketIOClient.getHandshakeData().getSingleUrlParam(HeaderFactory.COOKIE_KEY_SERVERPORT_KEY);
		
		if (StringUtil.isEmpty(token)) {
			throw new ZJHRuntimeException("");
		}
		
		UserHeaderContainer container =null;
		User user =null;
		if(connect==null) {//相机
			container = UserHeaderContainer.resolveNoUserCookie(token);
			user=userNoCache.get(new UserCacheKey(container.getUserId(), container.getUuid()));
			//redisService.set(sno, socketIOClient.getSessionId().toString()+"_"+serverip+"_"+serverport);
			//socketIOClient.sendEvent("disconnect", "");
		}else {
			 container = UserHeaderContainer.resolveUserCookie(token,redisService);
			 user = userCache.get(new UserCacheKey(container.getUserId(), container.getUuid()));
			 if(container==null) {
				 socketIOClient.sendEvent("disconnect", "");
			 }
			 
			
		}
		if (user == null) {
			throw new ZJHRuntimeException("");
		}
		if (container == null) {
			socketIOClient.disconnect();
			throw new ZJHRuntimeException("");
		}
		 
		
		String sessionId=socketIOClient.getSessionId().toString();
		UserInCache describe = new UserInCache();
		describe.setUserId(user.getId());
		describe.setSessionId(sessionId);
		describe.setRoomId(sno);
		
		clientMap.put(sessionId, describe);
		//相机的连接，根据mac地址如果冲突会叠加
		//相机连接
		if(connect==null) {
			describe.setTokenUuid("userCache_5_"+container.getUuid());
			
	        template.delete(sno+"_"+Constants.HEADER_KEY_LINK_KEY);
			
			//判断相机是否在线为空代表相机登录
			redisService.set(sno+"_"+sessionId,"0");
			redisService.expire(sno+"_"+sessionId,redistimeout);
			
			NET_Session_Body body=new NET_Session_Body();
			body.setSessionId(sessionId);
			body.setServerip(serverip);
			body.setServerport(Long.valueOf(serverport));
			body.setSno(sno);
	
			List<NET_Session_Body> bodyList=new ArrayList<>();
			bodyList.add(body);
			redisService.set(sno+"_"+Constants.HEADER_KEY_LINK_KEY,GsonUtil.parseToJson(bodyList));


		}else {
			describe.setTokenUuid("userCache_1_"+container.getUuid());
		}
		
		Set<String> set = template.keys("userCache_1*");
		Iterator<String> it1 = set.iterator();
		while(it1.hasNext()){
			String keyStr = it1.next();
			template.delete(keyStr);
		}
        if(connect!=null) {
		   socketIOClient.sendEvent("connectedSocket", redisService.get(sno));
		}
		socketIOClient.sendEvent("connectedSocket", describe.getSessionId());
	}
	//主动断开连接
	@OnDisconnect
	public void onDisConnect(SocketIOClient socketIOClient) {
		String sessionId = socketIOClient.getSessionId().toString();
		UserInCache describe = clientMap.get(sessionId);
		if(describe!=null) {
		  redisService.del(describe.getTokenUuid());
		}
		Map<String, UserInCache> map = new HashMap<String, UserInCache>();
		String sno="";
		ConcurrentMap<String, RoomContext> resultMap=RoomContext.roomMap;
		for (Entry<String, RoomContext> entry : resultMap.entrySet()) {
		    String key= entry.getKey();
		    if(key.contains(key)&&key.contains("_")) {
		    	sno=key.split("_")[0];
		    	break;
		    }
		}
		
		clientMap.remove(sessionId);
		RoomContext.roomMap.remove(sessionId);//注册客户端
		
		clientMap.remove(sno+"_"+sessionId);
		RoomContext.roomMap.remove(sno+"_"+sessionId);//注册客户端
	}
	

}
