package com.wyj.springboot.im.model;

public class Net_SetSnapMode {
	private Integer niSnapMode;

	public Integer getNiSnapMode() {
		return niSnapMode;
	}

	public void setNiSnapMode(Integer niSnapMode) {
		this.niSnapMode = niSnapMode;
	}

}
