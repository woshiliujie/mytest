package com.wyj.springboot.im.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wyj.springboot.im.entity.Room;

/**
 * 
 * @author 郑龙
 * @date 2018年7月12日
 */

public interface RoomRepository extends JpaRepository<Room, Long>{
	
}
