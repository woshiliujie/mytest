package com.wyj.springboot.im.controller;

import java.util.Base64;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wyj.springboot.im.authorize.UserContext;
import com.wyj.springboot.im.authorize.cache.LongRedisCacheManager;
import com.wyj.springboot.im.authorize.cache.RedisCacheManager;
import com.wyj.springboot.im.authorize.cache.keymodel.UserCacheKey;
import com.wyj.springboot.im.authorize.cookie.HeaderFactory;
import com.wyj.springboot.im.authorize.cookie.UserHeaderContainer;
import com.wyj.springboot.im.config.BeanIocConfig;
import com.wyj.springboot.im.entity.User;
import com.wyj.springboot.im.entity.common.ResponseBean;
import com.wyj.springboot.im.entity.common.ZJHProperties;
import com.wyj.springboot.im.service.IRedisService;
import com.wyj.springboot.im.service.UserService;
import com.wyj.springboot.im.socketnio.NettySocketServer;
import com.wyj.springboot.im.tools.RSAUtils;
import com.wyj.springboot.im.tools.StringUtil;
import com.wyj.springboot.im.tools.XXTEA;

/**
 * @author 郑龙
 * @date 2017年9月28日
 */

@RestController
@RequestMapping(produces = "application/json;charset=utf-8")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	UserService userService;
	
	@Resource(name=BeanIocConfig.USER_CACHE)
	RedisCacheManager<UserCacheKey, User> userCache;
	
	@Resource(name=BeanIocConfig.USER_NO_CACHE)
	private RedisCacheManager<UserCacheKey, User> userNoCache;
	
	
	@Resource(name=BeanIocConfig.LOGIN_TIMES_CACHE)
	LongRedisCacheManager<User> loginTimeCache;
	
	@Resource
	IRedisService redisService;
	
	@Autowired
	Environment env;
	@Autowired
	private NettySocketServer server;
	
	private String PRIVATEKEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALeGcVIOSRIv4uVOyXtgoH7+zBywqw2e2WLZwHU94Um4mlC3mFc0q/nY8N4RVhKFrEkHtv4S2rlGX2hUGI3EpGQq10x4w5pcVNfpxgpKI4y0aZPeFavAI0ZldZNhUHbCN/9lmsTo17GwugwrSyPyScsnyw4F9netCeiPJaJJu7SBAgMBAAECgYALkLtfcmsEbGQeE0L7NXGnzyLJxBBjgVkts48/VDD4VlvTLl65UCZuTk+PjwQfkrDywTu08zc5acflaTdK59N8KSyONg98DvjYA/w7SqGn5Kn0khDRlIcbSr50y6pcmNMXHhssZRMZXRIKMjYOUj4T1hnYKFcummnNvIGxG3GeAQJBANvgh8TKcFaByaD87Jo4mHfCF9AY1nFi8ztfrkKCwezGqMOeYd4OBPU1KMobKAByiqHl7VwDHPEN3wfLTZDRazECQQDVrQs0TVVCo2PF22JwA5d8ofQOpTUtfAct8blZ3a6vhum2TJCl6CT5SynHkmJTgVXVwIpGkRxm6kzTYerH3upRAkANRASs+NHCRl5V2iykOVnpj8pEAdueR6wJHwKyfJUapfm0o6+f6BSgfq6RUwYc0MxQbEDf1kg+uumD3N43KIthAkEAxGEtkvwgCAayg/2FEv26FEmkTHF51jvPPWKTvwwGqDuOQIVNy6z3jkaON2VKCQUtJi625vQm7k8YHI45gUhWgQJAfDtR23VirW2iAu8gTi1dsDDTIMAAhZNmSn+nTdAN9kCZuic/jsHrThn06EXByINk07xSBtfN//hJrKO8rrg9UA==";
	
//	private void loginSuccess(HttpServletResponse response, User user) {
//		// 更新cookie
//		String uuid = UUID.randomUUID().toString();
//		response.addCookie(
//				CookieFactory.getUserCookie(new UserCookieContainer(uuid, user, System.currentTimeMillis())));
//		// 添加到cache中
//		userCache.set(new UserCacheKey(user.getId(), uuid), user);
//		loginTimeCache.increment(user);
//
//		response.addCookie(CookieFactory.getUsernameCookie(user.getName()));
//	}

	@GetMapping(value="/user/send/{sno}")
	public String senUser(@PathVariable String sno) {
		server.getServer().getRoomOperations("1000").sendEvent("inRoomWeb");
		return "test success!!";
	}
//相机端登录
    @PostMapping(value = "login")
    public String login(HttpServletRequest request, HttpServletResponse response,
                        @RequestBody Map<String, String> model) {
        if (model == null) {
            return ResponseBean.crtParameterErrorResult();
        }
      //开始解密 
        String username = model.get("username");
        String password = model.get("password");
        String sno=model.get("sno").trim();
        password=RSAUtils.decryptDataOnJava(password, PRIVATEKEY);
        
        if (StringUtil.isEmpty(username) || StringUtil.isEmpty(password)) {
            return ResponseBean.crtParameterErrorResult();
        }

        if (!userService.isExist(username)) {
            return ResponseBean.crtFailureResult("该用户不存在");
        }

        User user = userService.getUser(username);
        if (user.getPassword().equals(password)) {
            HeaderFactory.Header tokenHeader = loginSuccessNoTime(user);
            ResponseBean bean = ResponseBean.crtSuccessBean();
            JSONObject content = new JSONObject();
            content.put("wsServer", ZJHProperties.WEBSOCKET_SERVER_URL);
            content.put(tokenHeader.key, tokenHeader.value);
            content.put("nssserverport", env.getProperty("nss.server.port")); 
            content.put("nssserverhost", env.getProperty("nss.server.host")); 
            redisService.set(sno, env.getProperty("nss.server.port"));
            bean.setContent(content);
            return bean.toString();
        } else {
            return ResponseBean.crtFailureResult("密码错误");
        }


    }
   
    //web端登录
    @PostMapping(value = "weblogin")
    public String weblogin(HttpServletRequest request, HttpServletResponse response,
                        @RequestBody Map<String, String> model) throws NumberFormatException, Exception {
    	response.setHeader("Access-Control-Allow-Origin", "*");
        if (model == null) {
            return ResponseBean.crtParameterErrorResult();
        }
      //开始解密 
        String username = model.get("username");
        String password = model.get("password");
        password=RSAUtils.decryptDataOnJava(password, PRIVATEKEY);
        
        if (StringUtil.isEmpty(username) || StringUtil.isEmpty(password)) {
            return ResponseBean.crtParameterErrorResult();
        }

        if (!userService.isExist(username)) {
            return ResponseBean.crtFailureResult("该用户不存在");
        }

        User user = userService.getUser(username);
        if (user.getPassword().equals(password)) {
            HeaderFactory.Header tokenHeader = loginSuccess(user);
            ResponseBean bean = ResponseBean.crtSuccessBean();
            JSONObject content = new JSONObject();
            content.put("wsServer", ZJHProperties.WEBSOCKET_SERVER_URL);
            content.put(tokenHeader.key, tokenHeader.value);
            String sno=model.get("sno").trim();
            String nssserverport=redisService.get(sno);
            if(nssserverport==null||"".equals(nssserverport)) {
            	return ResponseBean.crtFailureResult("设备离线");
            }
            content.put("nssserverport", redisService.get(sno)); 
            content.put("nssserverhost", env.getProperty("nss.server.host")); 
            bean.setContent(content);
            return bean.toString();
        } else {
            return ResponseBean.crtFailureResult("密码错误");
        }


    }

    @PostMapping("/registe")
    public String registe(HttpServletRequest request, HttpServletResponse response,
                          @RequestBody Map<String, String> model) {
        if (model == null) {
            return ResponseBean.crtParameterErrorResult();
        }

        String username = model.get("username");
        String password = model.get("password");

        if (StringUtil.isEmpty(username) || StringUtil.isEmpty(password)) {
            return ResponseBean.crtParameterErrorResult();
        }

        long userId = userService.addUser(username, password);
        if (userId > 0) {
            logger.info("username:{} 注册成功！！ userId:{}", username, userId);
            return ResponseBean.crtSuccessResult();
        } else {
            logger.error("注册过程出错！！username:{}, password:{}, userId:{}", username, password, userId);
            return ResponseBean.crtFailureResult("注册失败，请稍后再试！");
        }

    }
    
	@GetMapping("/userInfo")
	public String userInfo(HttpServletRequest request, HttpServletResponse response) {
		return JSON.toJSONString(UserContext.getCurrentUser());
	}

	  private HeaderFactory.Header loginSuccessNoTime(User user) {
	        String uuid = UUID.randomUUID().toString();
			// 添加到cache中
	        userNoCache.setNoTime(new UserCacheKey(user.getId(), uuid), user);
			loginTimeCache.incrementNoTime(user);
	        return HeaderFactory.getUserHeader(new UserHeaderContainer(user.getId(), uuid, System.currentTimeMillis()));
	    }
    private HeaderFactory.Header loginSuccess(User user) {
        String uuid = UUID.randomUUID().toString();
		// 添加到cache中
		userCache.set(new UserCacheKey(user.getId(), uuid), user);
		loginTimeCache.increment(user);
        redisService.expire("userCache_5_"+uuid, 30*60);
        return HeaderFactory.getUserHeader(new UserHeaderContainer(user.getId(), uuid, System.currentTimeMillis()));
    }
//    public void deleteByPrex(String prex) {
//    	Set<String> set = redisService.keys(prex +"*");
//		Iterator<String> it = set.iterator();
//		while(it.hasNext()){
//			String keyStr = it.next();
//			System.out.println(keyStr);
//			redisService.del(keyStr);
//		}
//    }
    public static void main(String[] args) {
        String originStr = System.currentTimeMillis() + ":" + "2"
//					+":"+UUID.randomUUID().toString()
                ;

        String encrytStr = XXTEA.encrypt(originStr);
        
        String encryStr2 = "af7e0b8a01a92fa6ee1225228dbab81f2b06cacfa0b974559739bcad78ab87f306e4d1dcae0a5ce29e5fc47e75f82f667e4f3d477193a9f8";

        String base64Str = Base64.getEncoder().encodeToString(originStr.getBytes());
        System.out.println("originStr:" + originStr
                + "\n encrytStr:" + encrytStr
                + "\n base64Str:" + base64Str
                + "\n encryStr2:" + encryStr2
                + "\n baseEncryStr2:"+Base64.getEncoder().encodeToString(encryStr2.getBytes()));
    }

}
