package com.wyj.springboot.im.sockethandler;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.corundumstudio.socketio.AckRequest;
import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.corundumstudio.socketio.annotation.OnEvent;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wyj.springboot.im.config.Constants;
import com.wyj.springboot.im.model.BaseHeaderDto;
import com.wyj.springboot.im.model.BaseResultDto;
import com.wyj.springboot.im.model.CarInfo;
import com.wyj.springboot.im.model.NET_Session_Body;
import com.wyj.springboot.im.model.Net_ConnCameraEx;
import com.wyj.springboot.im.service.IRedisService;
import com.wyj.springboot.im.sockethandler.entity.UserInCache;
import com.wyj.springboot.im.sockethandler.room.RoomContext;
import com.wyj.springboot.im.socketnio.NettySocketServer;
import com.wyj.springboot.im.tools.GsonUtil;
import com.wyj.springboot.im.tools.MD5Util;
import com.wyj.springboot.im.tools.ProfileUtil;

/**
 * 
 * @author 郑龙
 * @date 2018年7月12日
 */

@Component
public class SocketRoomHandler {

	private static final Logger logger = LoggerFactory.getLogger(SocketRoomHandler.class);
	
	private SocketIOServer server;
	public static final Map<String, UserInCache> clientMap = Collections.synchronizedMap(new HashMap<>());
	
	@Resource
	IRedisService redisService;
    
	
	@Autowired
	public SocketRoomHandler(NettySocketServer server) {
		this.server = server.getServer();
	}
	 //相机注册事件
	private void JoinRoom(SocketIOClient client, AckRequest request,String regflag) {
	
			UserInCache userInCache = SocketConnectedHandler.clientMap.get(client.getSessionId().toString());
			
			String roomId="_"+client.getSessionId();
			RoomContext room = new RoomContext(userInCache);
			
			RoomContext.roomMap.put(roomId, room);
			client.joinRoom(roomId);
			room.inRoom(userInCache);
			request.sendAckData(room);
			roomId=null;room=null;userInCache=null;
	}
	

	//web端控制消息注册事件
	private void JoinRoomWeb(SocketIOClient client, AckRequest request) {
	
		String myRoomId=client.getSessionId().toString();
		UserInCache userInCache = SocketConnectedHandler.clientMap.get(client.getSessionId().toString());
		if(userInCache==null) {
			userInCache=new UserInCache();
			userInCache.setUserId(1);
			userInCache.setRoomId(myRoomId);
			userInCache.setSessionId(client.getSessionId().toString());
		}
		RoomContext room = new RoomContext(userInCache);
		
		RoomContext.roomMap.put(myRoomId, room);//注册客户端
		client.joinRoom(myRoomId);
		room.inRoom(userInCache);
		request.sendAckData(room);
		myRoomId=null;room=null;userInCache=null;
	}
	
	//web端上报消息注册事件
	private void JoinRoomSBWeb(String sno,SocketIOClient client, AckRequest request) {

		String myRoomId=sno+"_"+client.getSessionId().toString();
		UserInCache userInCache = SocketConnectedHandler.clientMap.get(client.getSessionId().toString());
		
		RoomContext room = new RoomContext(userInCache);

		RoomContext.roomMap.put(myRoomId, room);//注册客户端
		client.joinRoom(myRoomId);
		room.inRoom(userInCache);
		request.sendAckData(room);
		myRoomId=null;room=null;userInCache=null;
	}
	//实时视频
	private void JoinRoomSSSPSBWeb(String sno,SocketIOClient client, AckRequest request) {
		String myRoomId="video_"+sno+"_"+client.getSessionId().toString();
		UserInCache userInCache = SocketConnectedHandler.clientMap.get(client.getSessionId().toString());
	
		RoomContext room = new RoomContext(userInCache);
		RoomContext.roomMap.put(myRoomId, room);//注册客户端
		client.joinRoom(myRoomId);
		room.inRoom(userInCache);
		request.sendAckData(room);
		myRoomId=null;room=null;userInCache=null;
	}
	
	//device端上报消息注册事件
	private void JoinRoomDeviceWeb(String sno,SocketIOClient client, AckRequest request) {
		String myRoomId="device_"+sno+"_"+client.getSessionId().toString();
		UserInCache userInCache = SocketConnectedHandler.clientMap.get(client.getSessionId().toString());
		RoomContext room = new RoomContext(userInCache);
		RoomContext.roomMap.put(myRoomId, room);//注册客户端
		client.joinRoom(myRoomId);
		room.inRoom(userInCache);
		request.sendAckData(room);
	}
	
	//WEB监听相机登录
	@OnEvent(value="MSG_R_REAL_TIME_LOGINWeb")
	public void MSG_R_REAL_TIME_LOGINWeb(SocketIOClient client, String sno,AckRequest request) {
		JoinRoomSBWeb(sno,client, request);	
		sno=null;
	}
	
	//相机重新登录上报
	@OnEvent(value="MSG_R_REAL_TIME_LOGIN")
	public void MSG_R_REAL_TIME_LOGIN(SocketIOClient client,String sno, AckRequest request) {
		Iterator iter = RoomContext.roomMap.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry<String,RoomContext> entry = (Map.Entry) iter.next();
			String key=entry.getKey();
			if(key.contains(sno+"_")) {
				server.getRoomOperations(key).sendEvent("MSG_R_REAL_TIME_LOGINWeb");//向PC客户端发送数据
			}
			entry=null;key=null;
		}
		sno=null;iter=null;
		
	}
			
			
		
		//实时视频web注册
		@OnEvent(value="MSG_R_REAL_TIME_VIDEOWeb")
		public void MSG_R_REAL_TIME_VIDEOWeb(SocketIOClient client, String sno,AckRequest request) {
			JoinRoomSSSPSBWeb(sno,client, request);	
			sno=null;
		}

		
		//实时视频消息結果上报
		@OnEvent(value="MSG_R_REAL_TIME_VIDEO")
		public void MSG_R_REAL_TIME_VIDEO(SocketIOClient client,String msgNo,String resultInfo, AckRequest request) throws IOException, InterruptedException {
			//JoinRoom(client, request, "");
		
			Iterator iter = RoomContext.roomMap.entrySet().iterator();
			
			while (iter.hasNext()) {
				Map.Entry<String,RoomContext> entry = (Map.Entry) iter.next();
				String key=entry.getKey();
				if(resultInfo==null) {
					break;
				}else if(!resultInfo.contains("@")) {
					break;
				}
				
				String resultInfo1=resultInfo;
				//System.out.println("startstartstartstartstartstartstartstartstartstartstartstartstartstartstartstartstart"+resultInfo1+"endendendendendendendendendendendendendendendendend");
				String sno=resultInfo1.split("@")[1];
				String resultInfo2=resultInfo1.split("@")[2];
				 msgNo=resultInfo1.split("@")[0];
				if(key.contains("video_"+sno+"_")) {
					
					 if("18000200".equals(msgNo)) {//实时视频
						 Integer current=getCurrent(resultInfo2);
						 String imageData=getImageData( resultInfo2);
						 Integer total=getTotal(resultInfo2);
						 String imageType=getImageType(resultInfo2);
							server.getRoomOperations(key).sendEvent("MSG_R_REAL_TIME_VIDEOWeb",msgNo,imageData,total,current+1,imageType,sno);//向PC客户端发送数据
							resultInfo1=null;resultInfo2=null;total=null;msgNo=null;
				       	
					 }
				}
				resultInfo1=null;	
				entry=null;key=null;
			}
		     msgNo=null;resultInfo=null;iter=null;
			
		}
		
		
		private static String myHostNmae="http://work.alfeye.com";
		//web端自动上报
		@OnEvent(value="MSG_R_REAL_TIME_SNAPSHOTWeb")
		public void MSG_R_REAL_TIME_SNAPSHOTWeb(SocketIOClient client,String sno, AckRequest request) {
			JoinRoomSBWeb(sno,client, request);	
			sno=null;
		}
		
		//自动识别上报消息結果
		@OnEvent(value="MSG_R_REAL_TIME_SNAPSHOT")
		public void MSG_R_REAL_TIME_SNAPSHOT(SocketIOClient client,String msgNo,String resultInfo, AckRequest request) throws InterruptedException {
		
			Iterator iter = RoomContext.roomMap.entrySet().iterator();
			
			while (iter.hasNext()) {
				Map.Entry<String,RoomContext> entry = (Map.Entry) iter.next();
				String key=entry.getKey();
				if(resultInfo==null) {
					break;
				}else if(!resultInfo.contains("@")) {
					break;
				}
				
				String resultInfo1=resultInfo;
				//System.out.println("startstartstartstartstartstartstartstartstartstartstartstartstartstartstartstartstart"+resultInfo1+"endendendendendendendendendendendendendendendendend");
				String sno=resultInfo1.split("@")[1];
				String resultInfo2=resultInfo1.split("@")[2];
				 msgNo=resultInfo1.split("@")[0];
				if(key.contains(sno+"_")) {
					if("18000102".equals(msgNo)){//图片信息
						
							 server.getRoomOperations(key).sendEvent("MSG_R_REAL_TIME_SNAPSHOTWeb",msgNo, resultInfo2);//向PC客户端发送数据
	
			       	   
					 }
					 if("18000100".equals(msgNo)) {//自动识别
						 Integer current=getCurrent(resultInfo2);
						 String imageData=getImageData( resultInfo2);
						 Integer total=getTotal(resultInfo2);
						 String imageType=getImageType(resultInfo2);
							server.getRoomOperations(key).sendEvent("MSG_R_REAL_TIME_SNAPSHOTWeb",msgNo,imageData,total,current+1,imageType,sno);//向PC客户端发送数据
				       	
					 }
						}
						
				entry=null;key=null;resultInfo1=null;resultInfo2=null;msgNo=null;
			}
                msgNo=null;resultInfo=null;iter=null;

		}@OnEvent(value="MSG_R_REAL_TIME_LOG")//获取日志
		public void MSG_R_REAL_TIME_LOG(SocketIOClient client,String msgNo,byte[] resultInfo,String reqeustId,String type,Integer total,Integer current, AckRequest request) {
			if(resultInfo!=null) {
				 String clentId=logclentMap.get(reqeustId);
			if(resultInfo.length>1) {
			
              getFile(resultInfo, "d:\\ftplog", reqeustId+""+type);
            //向PC客户端发送数据
 			 server.getRoomOperations(clentId).sendEvent("Net_MESSAGE_SetupWeb",msgNo,"ftp://112.74.124.51:22//"+reqeustId+""+type);
 			 imageclentMap.remove(reqeustId);
			}else {
				server.getRoomOperations(clentId).sendEvent("Net_MESSAGE_SetupWeb",msgNo,0,total,current); 
			}
			
			}else {
				JoinRoom(client, request, "");
			}

		}
	
	

	//web相机登录
	@OnEvent(value="Net_ConnCameraExWeb")
	public void Net_ConnCameraExWeb (SocketIOClient client, String serverId,String serverip,Integer serverport,String sno,Integer type,String msgno,String bodyInfo,AckRequest request) {
		JoinRoomWeb(client, request);
		Net_ConnCameraEx body=GsonUtil.parseJsonWithClass(bodyInfo, Net_ConnCameraEx.class);
		String userKey=redisService.get(sno+"@"+body.getUserKey());
		if(userKey!=null&&!"".equals(userKey)) {//如果缓存没有保存就从页面获取
			if(userKey.split("@").length==2) {
				body.setUsername(userKey.split("@")[0]);
				body.setPasswd(userKey.split("@")[1]);
			}
			
		}else {
			body.setPasswd(MD5Util.MD5_32(body.getPasswd()));
		}
		
		BaseHeaderDto header=new BaseHeaderDto();
		header.setServerip(serverip);//前端传过来的 当相机登录时 会保存到redis里面 然后前端可以通过sno拿到这个值
		header.setServerport(serverport);//前端传过来的 当相机登录时 会保存到redis里面 然后前端可以通过sno拿到这个值
		header.setSno(sno);
		header.setType(type);//是web端还是小程序还是app 1:web 2:app 3:小程序
		header.setMsgno(msgno);//消息号
		String clentIdAttr=client.getSessionId().toString()+"_"+sno+"_"+body.getUsername()+"_"+body.getUserKey()+"_"+body.getPasswd();
		header.setClentid(clentIdAttr);
		Map<String, Object> map=new HashMap<>();
		map.put("header", header);
		
		map.put("body", body);
		server.getRoomOperations(serverId).sendEvent("MSG_R_CONN_CAMERA_SETUP", GsonUtil.parseToJson(map));
		body=null;header=null;map=null;clentIdAttr=null;
		
	}

	
	//登录验证结果
	@OnEvent(value="MSG_R_CONN_CAMERA_SETUP")
	public void MSG_R_CONN_CAMERA_SETUP(SocketIOClient client,String resultInfo, AckRequest request) {
		BaseHeaderDto  header=new BaseHeaderDto();
		BaseResultDto result=new BaseResultDto();
		if(!"".equals(resultInfo)&&resultInfo!=null) {
			Map<String, String> message=GsonUtil.parseJsonWithClass(resultInfo, Map.class);
	        header=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("header")), BaseHeaderDto.class);;
			result=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("result")), BaseResultDto.class);;
		}
		
		if(!"".equals(header.getClentid())&&header.getClentid()!=null) {//相机注册不要向web端发消息
			String clentIdAttr[]=header.getClentid().split("_");
	        String clentId=clentIdAttr[0];//连接Id
	        String sno=clentIdAttr[1];//序列号
			String userName=clentIdAttr[2];//登录相机用户名
			String userRKey=clentIdAttr[3];//用户名
			String password=clentIdAttr[4];//用户密码
		
			Map<String, Object> returnMap=new HashMap<>();
			returnMap.put("result", result);
			String userKey=redisService.get(sno+"@"+userRKey);
			String userVal=userName+"@"+password;
			if(result.getResult()==0) {//如果登录验证成功就存到redis缓存里 下次从缓存里取 免登录
				userKey=sno+"@"+userRKey;
				redisService.set(userKey, userVal);
			}else {//如果登录验证失败
				
				if(userKey!=null&&!"".equals(userKey)) {//删除缓存 从用户输入值获取值
					userKey=sno+"@"+userRKey;
					
				  redisService.del(userKey);
				}
			}
		  server.getRoomOperations(clentId).sendEvent("Net_ConnCameraExWeb", GsonUtil.parseToJson(returnMap));//向PC客户端发送数据
		}else {
			JoinRoom(client, request,resultInfo);
		}
		header=null;result=null;resultInfo=null;
	}

	//网络消息消息
	@OnEvent(value="MSG_R_MESSAGE_SETUP")
	public void MSG_R_NET_SETUP(SocketIOClient client ,String msgNo,String resultInfo,String sno,String serverip,Integer serverport, AckRequest request) {
		
       
		BaseHeaderDto   header=GsonUtil.parseJsonWithClass(resultInfo, BaseHeaderDto.class);
	    if(header!=null) {
				  server.getRoomOperations(header.getClentid()).sendEvent("Net_MESSAGE_SetupWeb",msgNo, resultInfo,sno,serverip,serverport,client.getSessionId().toString());//向PC客户端发送数据

	    }
		
		
	}
	

	 /** 
     * 根据byte数组，生成文件 
     */  
    private   void getFile(byte[] bfile, String filePath,String fileName) {  
        BufferedOutputStream bos = null;  
        FileOutputStream fos = null;  
        File file = null;  
        try {  
            File dir = new File(filePath);  
            if(!dir.exists()&&dir.isDirectory()){//判断文件目录是否存在  
                dir.mkdirs();  
            }  
            file = new File(filePath+"\\"+fileName);  
            fos = new FileOutputStream(file);  
            bos = new BufferedOutputStream(fos);  
            bos.write(bfile);  
        } catch (Exception e) {  
            e.printStackTrace();  
        } finally {  
            if (bos != null) {  
                try {  
                    bos.close();  
                } catch (IOException e1) {  
                    e1.printStackTrace();  
                }  
            }  
            if (fos != null) {  
                try {  
                    fos.close();  
                } catch (IOException e1) {  
                    e1.printStackTrace();  
                }  
            }  
        }  
    } 
	private Map<String,String> imageclentMap=new HashMap<>();
	
	private Map<String,String> logclentMap=new HashMap<>();
	
	//网络消息消息
	@OnEvent(value="MSG_R_UPDATE_DATA")
	public void MSG_R_LOG_DATA(SocketIOClient client ,String msgNo,String resultInfo,String sno, AckRequest request) {
		BaseHeaderDto header=new BaseHeaderDto();
		if(!"".equals(resultInfo)&&resultInfo!=null) {
			if(resultInfo.contains("header")&&header.getClentid()!=null) {
			Map<String, String> message=GsonUtil.parseJsonWithClass(resultInfo, Map.class);
	          header=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("header")), BaseHeaderDto.class);
	          server.getRoomOperations(header.getClentid()).sendEvent("MSG_I_UPDATE_DATA",msgNo, resultInfo,header.getSno());//向PC客户端发送数据
			}
			
		}
		
	}
	@OnEvent(value="MSG_I_UPDATE_DATA")
	public void MSG_I_LOG_DATA(SocketIOClient client, String serverId,String serverip,Integer serverport,String sno,Integer type,String msgno,String filename,String url, AckRequest request) {
		JoinRoomWeb(client, request);
		BaseHeaderDto header=new BaseHeaderDto();
		header.setClentid(client.getSessionId().toString());
		header.setServerip(serverip);//前端传过来的 当相机登录时 会保存到redis里面 然后前端可以通过sno拿到这个值
		header.setServerport(serverport);//前端传过来的 当相机登录时 会保存到redis里面 然后前端可以通过sno拿到这个值
		header.setSno(sno);
		header.setType(type);//是web端还是小程序还是app1web2app3小程序
		header.setMsgno(msgno);
		//bodyInfo查询信息为空 请求有值
		Map<String,Object> resultMap=new HashMap<>();
		Map<String, Object> body=new HashMap<>();
		Random rand = new Random();
		Long requestId=10000000+ProfileUtil.getAtomicCounter()+99+rand.nextInt(10000);
		body.put("requestid", ""+requestId);
		body.put("filename", filename);
		body.put("filetype", "4");
		resultMap.put("body", body);
		resultMap.put("header", header);
		server.getRoomOperations(serverId).sendEvent("MSG_R_UPDATE_DATA",GsonUtil.parseToJson(resultMap),url);
	}
	//网络消息命令
	@OnEvent(value="Net_MESSAGE_SetupWeb")
	public void Net_QUERY_NETSetupWeb(SocketIOClient client, String serverId,String serverip,Integer serverport,String sno,Integer type,String msgno,String bodyInfo, AckRequest request) {
		logger.info("【Net_MESSAGE_SetupWeb】clientSessionId:{}, serverId:{}, serverip:{}, serverport:{}, sno:{}, type:{}, msgno:{}, bodyInfo:{}",
				client.getSessionId().toString(), serverId, serverip, serverport, sno, type, msgno, bodyInfo);
		JoinRoomWeb(client, request);
		BaseHeaderDto header=new BaseHeaderDto();
		header.setClentid(client.getSessionId().toString());
		header.setServerip(serverip);//前端传过来的 当相机登录时 会保存到redis里面 然后前端可以通过sno拿到这个值
		header.setServerport(serverport);//前端传过来的 当相机登录时 会保存到redis里面 然后前端可以通过sno拿到这个值
		header.setSno(sno);
		header.setType(type);//是web端还是小程序还是app1web2app3小程序
		header.setMsgno(msgno);
		//bodyInfo查询信息为空 请求有值
		Map<String,Object> resultMap=new HashMap<>();
		Map<String, Object> body=null;
		resultMap.put("header", header);
		if("08000101".equals(msgno)) {//抓拍控制
			body=new HashMap<>();

			Random rand = new Random();
			Long imageid=10000000+ProfileUtil.getAtomicCounter()+Integer.parseInt(bodyInfo)+rand.nextInt(10000);
			body.put("imageid",imageid+"");
			resultMap.put("body", body);
			imageclentMap.put(imageid+"", client.getSessionId().toString());
		}else if("08000110".equals(msgno)) {
			body=new HashMap<>();

			Random rand = new Random();
			Long imageid=10000000+ProfileUtil.getAtomicCounter()+Integer.parseInt(bodyInfo)+rand.nextInt(10000);
			body.put("imageid",imageid+"");
			resultMap.put("body", body);
			System.err.println("imageid:"+imageid);
			imageclentMap.put(imageid+"", client.getSessionId().toString());
		} else if("08000401".equals(msgno)){
			body=new HashMap<>();
			Random rand = new Random();
			Long requestid=10000000+ProfileUtil.getAtomicCounter()+Integer.parseInt(bodyInfo)+rand.nextInt(10000);
			body.put("requestid",requestid+"");
			resultMap.put("body", body);
			logclentMap.put(requestid+"", client.getSessionId().toString());
		}else if("2050".equals(msgno)) {//抓拍控制
			body=new HashMap<>();
			//Random rand = new Random();
			//Long imageid=10000000+ProfileUtil.getAtomicCounter()+Integer.parseInt(bodyInfo)+rand.nextInt(10000);
			body.put("imageid","imageid");
			resultMap.put("body", body);
			//imageclentMap.put(imageid+"", client.getSessionId().toString());
		} else {
			body=GsonUtil.parseJsonWithClass(bodyInfo, HashMap.class);
			resultMap.put("body", body);
		}
		server.getRoomOperations(serverId).sendEvent("MSG_R_MESSAGE_SETUP",GsonUtil.parseToJson(resultMap));
		header=null;resultMap=null;body=null;
	}
	@OnEvent(value ="MSG_R_HEART_EVENT")
	public void MSG_R_HEART_EVENT(SocketIOClient client,String snoinfo,AckRequest request) {
		heartbeatEvent(snoinfo,client);
	}
	
	private boolean heartbeatEvent (String snoinfo,SocketIOClient client) {
		String snoinfoAttr[]=snoinfo.split("_");
		String sno=snoinfoAttr[0];String serverip=snoinfoAttr[1];Long serverport=Long.valueOf(snoinfoAttr[2]);String sessionId=client.getSessionId().toString();
		if(sno==null||sessionId==null) {
			return true;
		}
		  List<NET_Session_Body> bodyList=null;
		    NET_Session_Body body=null;

    	//redisService.del(sno+"_"+sessionId);
    	redisService.set(sno+"_"+sessionId,"0");
    	redisService.expire(sno+"_"+sessionId,60*2);
			 body=new NET_Session_Body();
			body.setSessionId(sessionId);
			body.setServerip(serverip);
			body.setServerport(Long.valueOf(serverport));
			body.setSno(sno);
	
			 bodyList=new ArrayList<>();
			
			
			  bodyList.add(body);
			
			
			redisService.set(sno+"_"+Constants.HEADER_KEY_LINK_KEY,GsonUtil.parseToJson(bodyList));
			bodyList=null;
			body=null;
			return true;
		
    }	
		
		
		  /**
	   * 二进制转字符串
	   * @param b
	   * @return
	   */
	  public static String byte2hex(byte[] b) // 二进制转字符串
	  {
	      StringBuffer sb = new StringBuffer();
	      String stmp = "";
	      for (int n = 0; n < b.length; n++) {
	          stmp = Integer.toHexString(b[n] & 0XFF);
	          if (stmp.length() == 1) {
	              sb.append("0" + stmp);
	          } else {
	              sb.append(stmp);
	          }

	      }
	      return sb.toString();
	  }

	   private Integer getCurrent(String resultInfo) {
		   Integer current=Integer.valueOf(resultInfo.substring(12, 16),16);
		   return current;
	   }
	   
	   private Integer getTotal(String resultInfo) {
		   Integer total=Integer.parseInt(resultInfo.substring(8,12),16);
		   return total;
	   }
	   
	   private String getImageId(String resultInfo) {
		   String imageid=Integer.parseInt(resultInfo.substring(0, 8),16)+"";
		   return imageid;
	   }
	   
	   private String getImageType(String resultInfo) {
		   String imageType=Integer.valueOf(resultInfo.substring(16, 18))+"";
		   return imageType;
	   }
	   
	   private String getImageData(String resultInfo) {
		   String imageData=resultInfo.substring(18,resultInfo.length());
		   return imageData;
	   }	
}
