package com.wyj.springboot.im.sockethandler.entity;

/**
 * 
 * @author 郑龙
 * @date 2017年11月29日
 */

public class UserInCache {
	private long userId;
	private String sessionId;
	private String roomId;
private String username;
private String tokenUuid;
	public String getTokenUuid() {
	return tokenUuid;
}

public void setTokenUuid(String tokenUuid) {
	this.tokenUuid = tokenUuid;
}

	public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}



	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	
}
