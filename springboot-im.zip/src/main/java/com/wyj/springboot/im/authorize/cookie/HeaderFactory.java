package com.wyj.springboot.im.authorize.cookie;


/**
 * 
 * @author 郑龙
 * @date 2017年7月28日
 */

public class HeaderFactory {
	
	public static final String HEADER_KEY_USER_TOKEN = "user_token";
	public static final String HEADER_KEY_SNO_KEY = "sno";
	public static final String COOKIE_KEY_USER_NAME = "_un";
	public static final String COOKIE_KEY_USER_ICON = "_icon";
	
	public static final String COOKIE_KEY_CONNECT_KEY= "connect";
	
	public static final String COOKIE_KEY_SERVERIP_KEY= "serverip";
	
	public static final String COOKIE_KEY_SERVERPORT_KEY= "serverport";
	
	public static Header getUserHeader(UserHeaderContainer container) {
		return new Header(HEADER_KEY_USER_TOKEN, UserHeaderContainer.generatorKey(container));
	}

	public static class Header {
		public String key;
		public String value;

		public Header() {}

		public Header(String key, String value) {
			this.key = key;
			this.value = value;
		}
	}
}
