package com.linkedkeeper.tcp.model;

import java.util.Map;

public class DeviceControlData {
  private Map<String, Object> param;
  private Long updateTime;

public Map<String, Object> getParam() {
	return param;
}
public void setParam(Map<String, Object> param) {
	this.param = param;
}
public Long getUpdateTime() {
	return updateTime;
}
public void setUpdateTime(Long updateTime) {
	this.updateTime = updateTime;
}
}
