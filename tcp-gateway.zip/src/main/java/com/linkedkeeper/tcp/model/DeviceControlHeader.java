package com.linkedkeeper.tcp.model;

public class DeviceControlHeader {
	private Integer bizType;
  private String deviceId;
  private Integer status;
  private Integer ver;
  private DeviceControlData data;
  private String sessionId;
public String getSessionId() {
	return sessionId;
}
public void setSessionId(String sessionId) {
	this.sessionId = sessionId;
}
public Integer getBizType() {
	return bizType;
}
public void setBizType(Integer bizType) {
	this.bizType = bizType;
}
public String getDeviceId() {
	return deviceId;
}
public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
}
public Integer getStatus() {
	return status;
}
public void setStatus(Integer status) {
	this.status = status;
}
public Integer getVer() {
	return ver;
}
public void setVer(Integer ver) {
	this.ver = ver;
}
public DeviceControlData getData() {
	return data;
}
public void setData(DeviceControlData data) {
	this.data = data;
}
}
