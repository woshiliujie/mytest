package com.linkedkeeper.tcp.model;

public class Param {
  private Integer infoType;

public Integer getInfoType() {
	return infoType;
}

public void setInfoType(Integer infoType) {
	this.infoType = infoType;
}
 
}
