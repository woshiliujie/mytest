package com.linkedkeeper.tcp.model;

public class Data {
  private Param param;
  private Long updateTime;
public Param getParam() {
	return param;
}
public void setParam(Param param) {
	this.param = param;
}
public Long getUpdateTime() {
	return updateTime;
}
public void setUpdateTime(Long updateTime) {
	this.updateTime = updateTime;
}
}
