package com.linkedkeeper.tcp.utils;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class ProfileUtil {

    private static AtomicInteger counter = new AtomicInteger(0);

    /**
     * 长生消息id
     */
    public static long getAtomicCounter() {
        if (counter.get() > 999999) {
            counter.set(1);
        }
        long time = System.currentTimeMillis();
        String timeStr=String.valueOf(time);
        Random rand = new Random();
        long returnValue =Long.parseLong(timeStr.substring(timeStr.length()-6, timeStr.length()));
        return returnValue;
    }

    private static long incrementAndGet() {
        return counter.incrementAndGet();
    }

    public static void main(String[] args) {
         String msg="0000000011111111";
        System.out.println(msg.substring(8,16));
    }
    
     
}