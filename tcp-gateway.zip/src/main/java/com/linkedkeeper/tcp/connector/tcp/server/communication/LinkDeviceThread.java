package com.linkedkeeper.tcp.connector.tcp.server.communication;

import com.camera.im.utils.HttpUtil;

public class LinkDeviceThread extends Thread {
	
	private String sno;
	public LinkDeviceThread(String sno) {
		this.sno=sno;
	}
	public void run() {
		HttpUtil.doGet(CommunicationConfig.myHostNmae+":8080/zuul/api-d/userdevice-anon/savedevice/"+sno+"?password=copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k="); 
		sno=null;
		
		
			Thread.currentThread();
		Thread.yield();
		
			
	}
}
