package com.linkedkeeper.tcp.connector.tcp.server.communication;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.camera.im.utils.ByteConvert;

public class CommunicationUtils {
	
	  public static byte[] changeBytes(byte[] fourBytes){
	    	int j = ByteBuffer.wrap(fourBytes).order(ByteOrder.LITTLE_ENDIAN).getInt();
	    	return ByteConvert.toLH(j);
	    }
	   private static byte[] byte_3 =null;
	    public static byte[] byteMerger(byte[] byte_1, byte[] byte_2){  
	        byte_3 = new byte[byte_1.length+byte_2.length];  
	        System.arraycopy(byte_1, 0, byte_3, 0, byte_1.length);  
	        System.arraycopy(byte_2, 0, byte_3, byte_1.length, byte_2.length);  
	        return byte_3;  
	    } 
	    
	    private static byte[] b =null;
	    public static byte[] hex2byte(String str) { 
		    if (str == null){ return null; }
		       str = str.trim(); int len = str.length(); 
		    if (len == 0 || len % 2 == 1)
		    { 
		    	return null; 
		    } 
		    b = new byte[len / 2]; 
		    try {
				    for (int i = 0; i < str.length(); i += 2) 
				    { 
				    		b[i / 2] = (byte) Integer.decode("0X" + str.substring(i, i + 2)).intValue(); 
				    } 
			    	return b; 
		     } 
		    catch (Exception e) { return null; }
	    }
	    public static byte[] toByteArray(String filePath) throws IOException {		
	    	InputStream in = new FileInputStream(filePath);
	        byte[] data = toByteArray(in);
	        in.close();
	     
	        return data;
	    }
	    private static byte[] toByteArray(InputStream in) throws IOException {
	    	 
	        ByteArrayOutputStream out = new ByteArrayOutputStream();
	        byte[] buffer = new byte[1024 * 30];
	        int n = 0;
	        while ((n = in.read(buffer)) != -1) {
	            out.write(buffer, 0, n);
	        }
	        return out.toByteArray();
	    }

	    /**
   	  * 将short转为高字节在前，低字节在后的byte数组
   	  * @param n short
   	  * @return byte[]
   	  */
   	public static byte[] toHH(short n) {
   	  byte[] b = new byte[2];
   	  b[1] = (byte) (n & 0xff);
   	  b[0] = (byte) (n >> 8 & 0xff);
   	  return b;
   	} 
   	 /**
   	  * 将int转为高字节在前，低字节在后的byte数组
   	  * @param n int
   	  * @return byte[]
   	  */
   	public static byte[] toHH(int n) {
   	  byte[] b = new byte[4];
   	  b[3] = (byte) (n & 0xff);
   	  b[2] = (byte) (n >> 8 & 0xff);
   	  b[1] = (byte) (n >> 16 & 0xff);
   	  b[0] = (byte) (n >> 24 & 0xff);
   	  return b;
   	} 
}
