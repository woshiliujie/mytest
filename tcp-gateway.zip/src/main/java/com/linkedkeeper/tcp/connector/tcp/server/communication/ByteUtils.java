/*
 * Copyright (c) 2016, LinkedKeeper
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * - Neither the name of LinkedKeeper nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.linkedkeeper.tcp.connector.tcp.server.communication;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import com.linkedkeeper.tcp.common.CarInfo;
import com.linkedkeeper.tcp.common.SdkSnapshot;

import sun.misc.BASE64Encoder;

/**
 * Created by frank@linkedkeeper.com on 17/1/10.
 */
public class ByteUtils {

    /**
     * byte数组转换成16进制字符串
     *
     * @param src
     * @return
     */

    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder();
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }
    private static  String[] strNow = new SimpleDateFormat("yyyy-MM-dd").format(new Date()).toString().split("-");
    private static Integer year = Integer.parseInt(strNow[0]);
    private static  Integer month = Integer.parseInt(strNow[1]);
    private static  Integer day = Integer.parseInt(strNow[2]);
    public static String getImageId(String resultInfo) {
  	   String imageid=Integer.parseInt(resultInfo.substring(0, 8),16)+"";
  	   return imageid;
     }
     
     public  String getImageType(String resultInfo) {
  	   String imageType=Integer.valueOf(resultInfo.substring(16, 18))+"";
  	   return imageType;
     }
     public static  Integer getCurrent(String resultInfo) {
  	   Integer current=Integer.valueOf(resultInfo.substring(12, 16),16);
  	   return current;
     }
     public  String getImageData(String resultInfo) {
  	   String imageData=resultInfo.substring(18,resultInfo.length());
  	   return imageData;
     }
     public static Integer getTotal(String resultInfo) {
  	   Integer total=Integer.parseInt(resultInfo.substring(8,12),16);
  	   return total;
     }
     public static byte[] byteMerger(byte[] byte_1, byte[] byte_2){  
         byte[] byte_3 = new byte[byte_1.length+byte_2.length];  
         System.arraycopy(byte_1, 0, byte_3, 0, byte_1.length);  
         System.arraycopy(byte_2, 0, byte_3, byte_1.length, byte_2.length);  
         return byte_3;  
     } 

     private static Map<String,byte[]>   imgSHTotalMap=new HashMap();
     private static Map<String,byte[]>   imgZJZPTotalMap=new HashMap();//自动识别
     private static   byte[] imgTotal=new byte[0];
     private static byte[] logTotal=new byte[0];
      String mysno;
     public  String bytesSHTPSJToHexString(byte[] src,String headerInfo, String sno) {//实时视频
     	mysno=sno;
         if (src == null || src.length <= 0) {
             return null;
         }
         byte[] msgReulst=new byte[src.length-8];
         for (int i = 8; i < src.length; i++) {
         	msgReulst[i-8]=src[i];
         } ;
        src=null;
         Integer total=getTotal(headerInfo);
         Integer current=getCurrent(headerInfo).intValue();
         if(current==0) {
        	 imgSHTotalMap.put(sno, msgReulst);
         }else {
        	 imgSHTotalMap.put(sno, byteMerger(imgSHTotalMap.get(sno), msgReulst));;
         }
         msgReulst=null;headerInfo=null;
         if(total.intValue()==current.intValue()+1) {
        	 total=null;current=null;
         	return GetImageStr(imgSHTotalMap.get(sno));
         }
         return "noimagemsg";
     }
     private static boolean ifimagex=true;
     
     public  String bytesZDSBSJToHexString(byte[] src,String headerInfo, String sno) {//自动识别
     	mysno=sno;
         if (src == null || src.length <= 0) {
             return null;
         }
         byte[] msgReulst=new byte[src.length-9];
         for (int i = 9; i < src.length; i++) {
         	msgReulst[i-9]=src[i];
         } ;
        src=null;
         Integer total=getTotal(headerInfo);
         Integer current=getCurrent(headerInfo).intValue();
         final String imageType=getImageType(headerInfo);
         final String imageId=getImageId(headerInfo);
         if(current==0) {
        	 imgZJZPTotalMap.put(sno,msgReulst);
         }else {
        	 imgZJZPTotalMap.put(sno,byteMerger( imgZJZPTotalMap.get(sno), msgReulst));
         }
         msgReulst=null;headerInfo=null;
         if(total.intValue()==current.intValue()+1) {
         	total=null;current=null;
         	if("0".equals(imageType)) {
         		String imgPath="d:\\mycam\\"+sno+"\\"+imageType+"\\"+year+"\\"+month+"\\"+day;
             	final mySaveToImage my=new ByteUtils().new mySaveToImage(imgZJZPTotalMap.get(sno), imgPath, imageId+".jpg");
             	
 	           		 imgPath="d:\\mycam\\"+sno;
 	               	 mySaveToImage my1=new ByteUtils().new mySaveToImage(imgZJZPTotalMap.get(sno), imgPath, imageType+".jpg");
 	               	 my1.start();
 	           		 ifimagex=false;
             	
 	        	Timer timer=new Timer();//实例化Timer类
 				   timer.schedule(new TimerTask(){
 				      public void run(){
 				    		
 	      				my.start();
 	      				
 				   this.cancel();
 				   }},6000);//五百毫秒
 				   timer=null;
         	}
         	return GetImageStr(imgZJZPTotalMap.get(sno));
         }
         return "noimagemsg";
     }
     
    public  String bytesTPSJToHexString(byte[] src,String headerInfo, String sno) {//抓拍
    	mysno=sno;
        if (src == null || src.length <= 0) {
            return null;
        }
        byte[] msgReulst=new byte[src.length-9];
        for (int i = 9; i < src.length; i++) {
        	msgReulst[i-9]=src[i];
        } ;
       src=null;
        Integer total=getTotal(headerInfo);
        Integer current=getCurrent(headerInfo).intValue();
        final String imageType=getImageType(headerInfo);
        final String imageId=getImageId(headerInfo);
        if(current==0) {
        	imgTotal=msgReulst;
        }else {
           imgTotal=byteMerger(imgTotal, msgReulst);
        }
        msgReulst=null;headerInfo=null;
        if(total.intValue()==current.intValue()+1) {
        	total=null;current=null;
        	if("0".equals(imageType)) {
        		String imgPath="d:\\mycam\\"+sno+"\\"+imageType+"\\"+year+"\\"+month+"\\"+day;
            	final mySaveToImage my=new ByteUtils().new mySaveToImage(imgTotal, imgPath, imageId+".jpg");
            	
	           		 imgPath="d:\\mycam\\"+sno;
	               	 mySaveToImage my1=new ByteUtils().new mySaveToImage(imgTotal, imgPath, imageType+".jpg");
	               	 my1.start();
	           		 ifimagex=false;
            	
	        	Timer timer=new Timer();//实例化Timer类
				   timer.schedule(new TimerTask(){
				      public void run(){
				    		
	      				my.start();
	      				
				   this.cancel();
				   }},6000);//五百毫秒
				   timer=null;
        	}
        	return GetImageStr(imgTotal);
        }
        return "noimagemsg";
    }
    //int i=0;
    public static byte[] bytesLogSJToHexString(byte[] src,String headerInfo,int reqlength) {
        if (src == null || src.length <= 0) {
            return null;
        }
        byte[] msgReulst=new byte[src.length-9];
        for (int i = 9; i < src.length; i++) {
        	msgReulst[i-9]=src[i];
        } ;
        src=null;
        
        Integer total=getTotal(headerInfo);
        reqlength=reqlength-total*9;
        Integer current=getCurrent(headerInfo).intValue();
       // System.out.println("current:"+current+"count:"+i+"total:"+total);
        if(current==0) {
        	logTotal=msgReulst;
        	msgReulst=null;
        }else {
        	logTotal=byteMerger(logTotal, msgReulst);
        	msgReulst=null;
        }
        if(total.intValue()==current.intValue()+1) {
        	
        	return logTotal;
        }
       // i++;
        return null;
    }
  private static BASE64Encoder encoder = new BASE64Encoder();
    public static String GetImageStr(byte[] imgByte) {// 将图片文件转化为字节数组字符串，并对其进行Base64编码处理
        byte[] data = null;
        
        // 读取图片字节数组
        try {
            InputStream in = new ByteArrayInputStream(imgByte);
            data = new byte[in.available()];
            in.read(data);
            in.close();
            imgByte=null;
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        // 对字节数组Base64编码
      
        return encoder.encode(data);// 返回Base64编码过的字节数组字符串
    }
    
    private class mySaveToImage extends Thread{
    	byte[] imgByte;String imgPath;String imgName;
    	public mySaveToImage(byte[] imgByte,String imgPath,String imgName) {
    		this.imgByte=imgByte;
    		this.imgPath=imgPath;
    		this.imgName=imgName;
    	}
    	public void run() {
    		try {
				//writeBytesToFile(imgByte);
				// 将字符串转换成二进制，用于显示图片  
				// 将上面生成的图片格式字符串 imgStr，还原成图片显示  ;  
    			
				InputStream in = new ByteArrayInputStream(imgByte);
	            File dirFile=new File(imgPath);
	            if (!dirFile.exists() && !dirFile.isDirectory()) {
	            	dirFile.mkdirs();
	            }
				File file=new File(imgPath+"\\"+imgName);//可以是任何图片格式.jpg,.png等
				if(!file.exists())    
	        	{    
	        	    try {    
	        	        file.createNewFile();    
	        	    } catch (IOException e) {    
	        	        // TODO Auto-generated catch block    
	        	        e.printStackTrace();    
	        	    }    
	        	}  
				FileOutputStream fos=new FileOutputStream(file);
				  
				byte[] b = new byte[1400];
				int nRead = 0;
				while ((nRead = in.read(b)) != -1) {
					fos.write(b, 0, nRead);
				}
			
				fos.flush();
				fos.close();
				in.close();
				b=null;
				imgByte=null;
				dirFile=null;
				file=null;
				Thread.currentThread().interrupt();
       			Thread.currentThread();
				Thread.yield();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
			}
		   
    	}
    }
  
    public static byte[] hexStringToBytes(String hexString) {  
    	     if (hexString == null || hexString.equals("")) {  
    	         return null;  
    	     }  
    	     hexString = hexString.toUpperCase();  
    	     int length = hexString.length() / 2;  
    	     char[] hexChars = hexString.toCharArray();  
    	     byte[] d = new byte[length];  
    	     for (int i = 0; i < length; i++) {  
    	         int pos = i * 2;  
    	         d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));  
    	     }  
    	     return d;  
    	 }  
    
    private static byte charToByte(char c) {  
    	     return (byte) "0123456789ABCDEF".indexOf(c);  
    	 }  
}
