/*
 * Copyright (c) 2016, LinkedKeeper
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * - Neither the name of LinkedKeeper nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.linkedkeeper.tcp.connector.tcp.server._6789;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.camera.im.utils.ByteConvert;
import com.camera.im.utils.GsonUtil;
import com.linkedkeeper.tcp.connector.tcp.TcpConnector;
import com.linkedkeeper.tcp.connector.tcp.config.ServerTransportConfig;
import com.linkedkeeper.tcp.connector.tcp.server.communication.ByteUtils;
import com.linkedkeeper.tcp.constant.Constants;
import com.linkedkeeper.tcp.message.MessageWrapper;
import com.linkedkeeper.tcp.message.SystemMessage;
import com.linkedkeeper.tcp.notify.NotifyProxy;
import com.linkedkeeper.tcp.utils.NetUtils;
import com.linkedkeeper.tcp.utils.ProfileUtil;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

//public class TcpServerHandler extends ChannelHandlerAdapter {
@ChannelHandler.Sharable
public class TcpServerHandler extends ChannelInboundHandlerAdapter {

    private final static Logger logger = LoggerFactory.getLogger(TcpServerHandler.class);
    private TcpConnector tcpConnector = null;
    private NotifyProxy notify = null;
    private Map<String, String> snoMap=new HashMap();
    public TcpServerHandler(ServerTransportConfig config) {
        this.tcpConnector = config.getTcpConnector();
        this.notify = config.getNotify();
    }
    
    private static   byte [] headebyte=new byte[24];
    
    private Map<String, Integer> serverMap=new HashMap();
   private final String[] tcpServerIpPort=new String[]{"112.74.124.51_6790"};
    public void channelRead(ChannelHandlerContext channelContext, Object o) throws Exception {
    	InetSocketAddress  insocket = (InetSocketAddress) channelContext.channel().remoteAddress();
  		String serverip=insocket.getAddress().getHostAddress();
  		Integer serverport=insocket.getPort();
  		Random ran=new Random();
  		
  		ByteBuf buf = (ByteBuf) o; 
  	    byte[] req = new byte[buf.readableBytes()];
	    buf.readBytes(req);
	    for(int i=0;i<24;i++) {
	        	headebyte[i]=req[i];
	    }
	    String headerMsg=ByteUtils.bytesToHexString(headebyte);
	    String msgNo=headerMsg.substring(32, 40);//消息号
	    if("08000001".equals(msgNo)) {//相机分发
		  	int serverindex=ran.nextInt(tcpServerIpPort.length-1);
		  	serverMap.put(serverip+"_"+serverport, serverindex);
		    Map<String,Object>	resultInfoMap=new HashMap();
     		resultInfoMap.put("result", "0");
     		resultInfoMap.put("cause", "success");
     		Map<String,Object> resultMapInfo=new HashMap();
     		
     		String sendserverip=tcpServerIpPort[serverindex].split("_")[0];
     	    Integer sendserverport=Integer.valueOf(tcpServerIpPort[serverindex].split("_")[1]);
     	    Map<String,Object>	bodyInfoMap=new HashMap();
     	    bodyInfoMap.put("serverip", sendserverip);
     	    bodyInfoMap.put("serverport", sendserverport);
     	    resultMapInfo.put("result", resultInfoMap);
     	    resultMapInfo.put("body", bodyInfoMap);
		  	sendServer(GsonUtil.parseToJson(resultMapInfo),msgNo, channelContext);
	    }
	   

	    buf=null;
	    insocket=null;
	    serverip=null;
	    ran=null;
	    serverport=null;
    }
    private void sendServer(String resultInfo,String msgNo, ChannelHandlerContext  channelContext) {//心跳 相机过来的登录
    	Map<String, String> message=GsonUtil.parseJsonWithClass(resultInfo, Map.class);
    	Map<String, String> headerMap=new HashMap();
     
     	//json控制数据：0 
     	//二进制图片数据：1
     	//二进制日志数据：2
     	//二进制升级文件：3 
     	//二进制mjpeg：4  
     	//二进制H264：5
     	//二进制语音：6
     	Integer fileType=0;
     	Integer type=4;//1web2app3小程序
     	Integer reqtype=3;//请求类型
     	Integer msgLengthInt=resultInfo.getBytes().length;
    	String  msgLength="";
     	for(int i=0;i<8-msgLengthInt.toHexString(msgLengthInt).length();i++) {
     		msgLength+="0";
     	}
     	String appId="0"+type+ProfileUtil.getAtomicCounter();//appId
     	int xhCount=8-appId.length();
     	for(int i=0;i<xhCount;i++) {
     		appId+="0";
     	}
     	byte[] msgProperty=hex2byte("0"+type+"010"+reqtype+"0"+fileType);//消息属性
     	
     	byte[]  msgLengthStr=hex2byte(msgLength+msgLengthInt.toHexString(msgLengthInt));//消息长度
     
     	byte[]  msgNobyte=changeBytes(hex2byte(msgNo));
     	if(msgProperty==null||msgLengthStr==null||msgNobyte==null||hex2byte(appId)==null) {
     		System.out.println("");
     	}
     	byte[]  tcpHeader=byteMerger(byteMerger(byteMerger(hex2byte("abababab"),hex2byte("00000001")),byteMerger(hex2byte(appId),msgProperty)),byteMerger(msgNobyte,msgLengthStr));
     	byte[]  bytesWrite = byteMerger(byteMerger(tcpHeader,resultInfo.getBytes()),hex2byte("cdcdcdcd"));
     	
     	ByteBuf buf = channelContext.alloc().buffer(bytesWrite.length); 
	
	
     	 buf.writeBytes(bytesWrite); 
		
		channelContext.channel().writeAndFlush(buf);
		buf=null;
		tcpHeader=null;
		bytesWrite=null;
		msgNobyte=null;
		msgLengthStr=null;
		msgProperty=null;
		appId=null;
		msgLengthInt=null;
		message=null;
		headerMap=null;
		 fileType=null;
     	 type=null;//1web2app3小程序
     	 reqtype=null;//请求类型
     	 msgLengthInt=null;
    	  msgLength=null;
	}
    
    public static byte[] changeBytes(byte[] fourBytes){
    	int j = ByteBuffer.wrap(fourBytes).order(ByteOrder.LITTLE_ENDIAN).getInt();
    	return ByteConvert.toLH(j);
    }
   private static byte[] byte_3 =null;
    public static byte[] byteMerger(byte[] byte_1, byte[] byte_2){  
        byte_3 = new byte[byte_1.length+byte_2.length];  
        System.arraycopy(byte_1, 0, byte_3, 0, byte_1.length);  
        System.arraycopy(byte_2, 0, byte_3, byte_1.length, byte_2.length);  
        return byte_3;  
    } 
    
    private static byte[] b =null;
    public static byte[] hex2byte(String str) { 
	    if (str == null){ return null; }
	       str = str.trim(); int len = str.length(); 
	    if (len == 0 || len % 2 == 1)
	    { 
	    	return null; 
	    } 
	    b = new byte[len / 2]; 
	    try {
			    for (int i = 0; i < str.length(); i += 2) 
			    { 
			    		b[i / 2] = (byte) Integer.decode("0X" + str.substring(i, i + 2)).intValue(); 
			    } 
		    	return b; 
	     } 
	    catch (Exception e) { return null; }
    }
    public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
        logger.debug("TcpServerHandler Connected from {" +
                NetUtils.channelToString(ctx.channel().remoteAddress(), ctx.channel().localAddress()) + "}");
    }

    public void channelUnregistered(ChannelHandlerContext ctx) throws Exception {
        logger.debug("TcpServerHandler Disconnected from {" +
                NetUtils.channelToString(ctx.channel().remoteAddress(), ctx.channel().localAddress()) + "}");
    }

    public void channelActive(ChannelHandlerContext ctx) throws Exception {
    	logger.debug("TcpServerHandler Connected1 from {" +
                NetUtils.channelToString(ctx.channel().remoteAddress(), ctx.channel().localAddress()) + "}");
}

    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        super.channelInactive(ctx);
        logger.debug("TcpServerHandler channelInactive from (" + getRemoteAddress(ctx) + ")");
        String sessionId0 = getChannelSessionHook(ctx);
        if (StringUtils.isNotBlank(sessionId0)) {
            tcpConnector.close(new MessageWrapper(sessionId0, null));
            logger.warn("TcpServerHandler channelInactive, close channel sessionId0 -> " + sessionId0 + ", ctx -> " + ctx.toString());
        }
    }

    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.warn("TcpServerHandler (" + getRemoteAddress(ctx) + ") -> Unexpected exception from downstream." + cause);
        String sessionId0 = getChannelSessionHook(ctx);
        if (StringUtils.isNotBlank(sessionId0)) {
            logger.error("TcpServerHandler exceptionCaught (sessionId0 -> " + sessionId0 + ", ctx -> " + ctx.toString() + ") -> Unexpected exception from downstream." + cause);
        }
    }

    private String getChannelSessionHook(ChannelHandlerContext ctx) {
        return ctx.channel().attr(Constants.SERVER_SESSION_HOOK).get();
    }

    private void setChannelSessionHook(ChannelHandlerContext ctx, String sessionId) {
        ctx.channel().attr(Constants.SERVER_SESSION_HOOK).set(sessionId);
    }

    final int SEND = 1;
    final int RECEIVE = 2;
    final int NOTIFY = 3;
    final int REPLY = 4;



    private void isConnect0(ChannelHandlerContext ctx, MessageWrapper wrapper) {
        String sessionId = wrapper.getSessionId();
        String sessionId0 = getChannelSessionHook(ctx);
        if (sessionId.equals(sessionId0)) {
          
            tcpConnector.responseSendMessage(wrapper);
        } else {
           
            tcpConnector.connect(ctx, wrapper);
            setChannelSessionHook(ctx, sessionId);
          
        }
    }

    private SystemMessage generateSystemMessage(ChannelHandlerContext ctx) {
        SystemMessage systemMessage = new SystemMessage();
        systemMessage.setRemoteAddress(getRemoteAddress(ctx));
        systemMessage.setLocalAddress(getLocalAddress(ctx));

        return systemMessage;
    }

    private String getRemoteAddress(ChannelHandlerContext ctx) {
        SocketAddress remote1 = ctx.channel().remoteAddress();
        InetSocketAddress remote = (InetSocketAddress) remote1;
        return NetUtils.toAddressString(remote);
    }

    private String getLocalAddress(ChannelHandlerContext ctx) {
        SocketAddress local1 = ctx.channel().localAddress();
        InetSocketAddress local = (InetSocketAddress) local1;
        return NetUtils.toAddressString(local);
    }
}
