package com.linkedkeeper.tcp.connector.tcp.server.communication;

import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;

import com.camera.im.model.BaseHeaderDto;
import com.camera.im.utils.AESUtil;
import com.camera.im.utils.AESUtils;
import com.camera.im.utils.GsonUtil;
import com.linkedkeeper.tcp.common.Encryption;
import com.linkedkeeper.tcp.utils.ProfileUtil;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SendMessageServerThread extends Thread {
	private static Logger logger = LoggerFactory.getLogger(SendMessageServerThread.class);
	private  Map<String,Object> resultMap=new HashMap();
    private  Map<String, Object> resultInfoMap=new HashMap();
    private  Map<String, Object> resultMapInfo=new HashMap();
    private  Map<String, String>	headerMap=null;	
  	public void sendServerHeartLogin(String msgNo,ChannelHandlerContext  channelContext,String serverip,Long serverport) {//心跳 相机过来的登录
    	resultInfoMap=new HashMap();
 		resultInfoMap.put("result", "0");
 		resultInfoMap.put("cause", "success");
 		resultMapInfo=new HashMap();
 		resultMapInfo.put("result", resultInfoMap);
  		String resultInfo=GsonUtil.parseToJson(resultMapInfo);
     	//json控制数据：0 
     	//二进制图片数据：1
     	//二进制日志数据：2
     	//二进制升级文件：3 
     	//二进制mjpeg：4  
     	//二进制H264：5
     	//二进制语音：6
     	Integer fileType=0;
     	Integer type=4;//1web2app3小程序
     	Integer reqtype=3;//请求类型
     	Integer msgLengthInt=resultInfo.getBytes().length;
    	String  msgLength="";
     	for(int i=0;i<8-msgLengthInt.toHexString(msgLengthInt).length();i++) {
     		msgLength+="0";
     	}
     	String appId="0"+type+ProfileUtil.getAtomicCounter();//appId
     	int xhCount=8-appId.length();
     	for(int i=0;i<xhCount;i++) {
     		appId+="0";
     	}
     	byte[] msgProperty=CommunicationUtils.hex2byte("0"+type+"010"+reqtype+"0"+fileType);//消息属性
     	
     	byte[]  msgLengthStr=CommunicationUtils.hex2byte(msgLength+msgLengthInt.toHexString(msgLengthInt));//消息长度
     	byte[]	msgNobyte={(byte) 0x08,(byte) 0x00,(byte) 0x00,(byte) 0x02};
	    byte[] headertmp = {(byte) 0xab,(byte) 0xab,(byte) 0xab,(byte) 0xab};
	    byte[] tmpb = {(byte) 0xcd,(byte) 0xcd,(byte) 0xcd,(byte) 0xcd};
     	if(msgProperty==null||msgLengthStr==null||msgNobyte==null||CommunicationUtils.hex2byte(appId)==null) {
     		return;
     	}
     	byte[] tcpHeader=CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(headertmp,CommunicationUtils.hex2byte("00000001")),CommunicationUtils.byteMerger(CommunicationUtils.hex2byte(appId),msgProperty)),CommunicationUtils.byteMerger(msgNobyte,msgLengthStr));
     	if("08000001".equals(msgNo)) {
     		byte[]	msgNobyte1={(byte) 0x08,(byte) 0x00,(byte) 0x00,(byte) 0x01};
     		tcpHeader=CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(headertmp,CommunicationUtils.hex2byte("00000001")),CommunicationUtils.byteMerger(CommunicationUtils.hex2byte(appId),msgProperty)),CommunicationUtils.byteMerger(msgNobyte1,msgLengthStr));
     	}
     	byte[]  bytesWrite = CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(tcpHeader,resultInfo.getBytes()),tmpb);
     	channelContext.channel().bind(new InetSocketAddress(serverip, serverport.intValue()));
     	ByteBuf buf = channelContext.alloc().buffer(bytesWrite.length); 
     	buf.writeBytes(bytesWrite); 
		channelContext.channel().writeAndFlush(buf);
		buf=null;
		tcpHeader=null;
		bytesWrite=null;
		msgNobyte=null;
		msgLengthStr=null;
		msgProperty=null;
		appId=null;
		msgLengthInt=null;
		fileType=null;
     	type=null;//1web2app3小程序
     	reqtype=null;//请求类型
     	msgLengthInt=null;
    	 msgLength=null;
	}	
  	
  	public void sendServer(String resultInfo, ChannelHandlerContext  channelContext,Integer fileType,int versionInt) throws Exception {
         int resultInfolength=0;
    	Integer msgLengthInt=0;
    	if(fileType.intValue()==7) {
    		resultInfolength=AESUtils.Encrypt(resultInfo, Encryption.encryptionMap.get(versionInt+"")).getBytes().length;
    	   try {
			msgLengthInt=resultInfolength+16;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	String msgLength="";
     	for(int i=0;i<8-Integer.toHexString(msgLengthInt).length();i++) {
     		msgLength+="0";
     	}
     	
     	
     	
     	
     
     	Integer msgLengthInt1=0;
     	
     	String msgLength1="";
      	for(int i=0;i<8-Integer.toHexString(resultInfolength).length();i++) {
      		msgLength1+="0";
      	}
      	msgLength1=msgLength1+Integer.toHexString(Integer.valueOf(resultInfolength).intValue());
     	
     	
     	msgLength=msgLength+Integer.toHexString(Integer.valueOf(msgLengthInt).intValue());
     	
     	byte[] versionzipencrypt= {(byte) 0x01};//消息属性
        byte[] format= {(byte) 0x00};
        byte[] headertmp = {(byte) 0xaf,(byte) 0xfb};
	     	byte[] tmpb = {(byte) 0x00,(byte) 0x00,(byte) 0xaf,(byte) 0xfe};	
     	if(versionzipencrypt==null) {
     		System.out.println("");
     	}else {
 	     	
     	    byte[] tcpHeader=CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(headertmp,CommunicationUtils.byteMerger(versionzipencrypt,format)),CommunicationUtils.hex2byte(msgLength));
     	    byte[] bytesWrite = null;
     	if(fileType.intValue()==7) {
     		try {
				bytesWrite = CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(tcpHeader,CommunicationUtils.byteMerger(CommunicationUtils.hex2byte(msgLength1),AESUtils.Encrypt(resultInfo, Encryption.encryptionMap.get(versionInt+"")).getBytes())),tmpb);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
     	}else {
     		 bytesWrite = CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(tcpHeader,resultInfo.getBytes()),tmpb);
     	}
     	ByteBuf	buf = channelContext.alloc().buffer(bytesWrite.length); 
		buf.writeBytes(bytesWrite); 
		channelContext.writeAndFlush(buf);
		buf=null;
		tcpHeader=null;
		bytesWrite=null;
		msgLengthInt=null;
		headerMap=null;
		fileType=null;
    	msgLengthInt=null;
   	    msgLength=null;
       	resultInfo=null;
     	}
    	
	}
  }
    public void sendServer(String resultInfo,String resultHeaderInfo, ChannelHandlerContext  channelContext,Integer fileType,int versionInt) throws Exception {
  		logger.info("【发送tcp消息】开始：resultInfo:{}, resultHeaderInfo:{}, fileType:{}, versionInt:{}", resultInfo, resultHeaderInfo, fileType, versionInt);
    	String msgNo="";
    	Map<String,Object> body=null;
    	Map<String, String> message=GsonUtil.parseJsonWithClass(resultHeaderInfo, Map.class);
    	BaseHeaderDto header=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("header")), BaseHeaderDto.class);;
 
     	headerMap=new HashMap();
     	headerMap.put("clentid", header.getClentid());
         int resultInfolength=0;
    	Integer msgLengthInt=0;
    	if(fileType.intValue()==7) {
    		resultInfolength=AESUtils.Encrypt(resultInfo,Encryption.encryptionMap.get(versionInt+"")).getBytes().length;
    	   try {
			msgLengthInt=resultInfolength+16;
		} catch (Exception e) {
			   logger.error("【发送tcp消息】异常resultInfolength：resultInfo:{}", resultInfo);
			e.printStackTrace();
		}
    	
    	String msgLength="";
     	for(int i=0;i<8-Integer.toHexString(msgLengthInt).length();i++) {
     		msgLength+="0";
     	}
     	
     	
     	
     	
     
     	Integer msgLengthInt1=0;
     	
     	String msgLength1="";
      	for(int i=0;i<8-Integer.toHexString(resultInfolength).length();i++) {
      		msgLength1+="0";
      	}
      	msgLength1=msgLength1+Integer.toHexString(Integer.valueOf(resultInfolength).intValue());
     	
     	
     	msgLength=msgLength+Integer.toHexString(Integer.valueOf(msgLengthInt).intValue());
     	
     	byte[] versionzipencrypt= {(byte) 0x01};//消息属性
        byte[] format= {(byte) 0x00};
        byte[] headertmp = {(byte) 0xaf,(byte) 0xfb};
	     	byte[] tmpb = {(byte) 0x00,(byte) 0x00,(byte) 0xaf,(byte) 0xfe};	
     	if(versionzipencrypt==null) {
			logger.info("【发送tcp消息】resultInfo:{}, versionzipencrypt是否为空:{}", resultInfo, versionzipencrypt==null?"true":"false");
     	}else {
 	     	
     	    byte[] tcpHeader=CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(headertmp,CommunicationUtils.byteMerger(versionzipencrypt,format)),CommunicationUtils.hex2byte(msgLength));
     	    byte[] bytesWrite = null;
     	if(fileType.intValue()==7) {
     		try {
				bytesWrite = CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(tcpHeader,CommunicationUtils.byteMerger(CommunicationUtils.hex2byte(msgLength1),AESUtils.Encrypt(resultInfo, Encryption.encryptionMap.get(versionInt+"")).getBytes())),tmpb);
			} catch (Exception e) {
				logger.error("【发送tcp消息】异常bytesWrite：resultInfo:{}", resultInfo);
				e.printStackTrace();
			}
     	}else {
     		 bytesWrite = CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(tcpHeader,resultInfo.getBytes()),tmpb);
     	}
     	ByteBuf	buf = channelContext.alloc().buffer(bytesWrite.length);
			logger.info("【发送tcp消息】发送的数据bytesWrite:{}, resultInfo:{}", bytesWrite, resultInfo);
		channelContext.channel().bind(new InetSocketAddress(header.getServerip(), header.getServerport().intValue()));
		buf.writeBytes(bytesWrite); 
		channelContext.writeAndFlush(buf);
		buf=null;
		tcpHeader=null;
		bytesWrite=null;
		msgLengthInt=null;
		message=null;
		headerMap=null;
		fileType=null;
    	msgLengthInt=null;
   	    msgLength=null;
       	resultInfo=null;
   	    body=null;msgNo=null;
			logger.info("【发送tcp消息】正常结束：resultInfo:{}, resultHeaderInfo:{}, fileType:{}, versionInt:{}", resultInfo, resultHeaderInfo, fileType, versionInt);
     	}
    	
	}
  }
}
