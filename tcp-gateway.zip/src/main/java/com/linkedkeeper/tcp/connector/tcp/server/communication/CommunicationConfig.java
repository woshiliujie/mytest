package com.linkedkeeper.tcp.connector.tcp.server.communication;

public class CommunicationConfig {
  public final static    String myHostNmae="http://work.alfeye.com";
}
