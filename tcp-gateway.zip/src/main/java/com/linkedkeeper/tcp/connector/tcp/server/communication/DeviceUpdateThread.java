package com.linkedkeeper.tcp.connector.tcp.server.communication;

import java.util.HashMap;
import java.util.Map;

import com.camera.im.model.BaseHeaderDto;
import com.camera.im.utils.GsonUtil;
import com.linkedkeeper.tcp.utils.ProfileUtil;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;

public class DeviceUpdateThread extends Thread {
	Map<String, String>	headerMap=null;

	    	private String fileurl;private String requestId;private String resultInfo;private ChannelHandlerContext  channelContext;//升级需要传入的参数
	    	public DeviceUpdateThread(String fileurl,String requestId,String resultInfo,ChannelHandlerContext  channelContext) {
	    		this.fileurl=fileurl;//文件url
	    		this.requestId=requestId;//唯一标识id
	    		this.resultInfo=resultInfo;//头信息
	    		this.channelContext=channelContext;//通道s
	    	}
	    	public void run() {
	     	     try {
	     	     int sendlength=1392;//包长度
				 byte[] updateInfo= CommunicationUtils.toByteArray(fileurl);//读取升级文件 转化成字节包
				 int total=(updateInfo.length + sendlength - 1) / sendlength;//计算出总包
				 for(int current=0;current<total;current++) {//一个一个包下发给设备 
					 byte[] udatedata=new byte[sendlength];
					 if(current==(total-1)) {//最后一个包处理
						 udatedata=new byte[updateInfo.length-(sendlength*(total-1))];//计算最后一个包的长度
						 for(int j=updateInfo.length-(updateInfo.length-(sendlength*(total-1)));j<updateInfo.length;j++) {//把填充数据
							 if(j>updateInfo.length) {//大于长度最后退出
								 break;
							 }
							 udatedata[j-(updateInfo.length-(updateInfo.length-(sendlength*(total-1))))]=updateInfo[j];//填充数据
						 }
					 }else {//不是最后一个包
						 for(int j=sendlength*current;j<sendlength*current+sendlength;j++) {//计算除最后一个包外还有多少包
							 udatedata[j-sendlength*current]=updateInfo[j];//填充数据
						 }
					 }
					 sendUpdateServer(resultInfo, channelContext , udatedata, (short)total, (short)current,requestId,"18000500");//发送给设备

				 }
				 updateInfo=null;//清除内存
	       		 Thread.currentThread().interrupt();;Thread.yield();//退出线程释放
				 
				} catch (Exception e) {
					e.printStackTrace();
				} 
	    	}
	    	
	    	//设备升级
	    	 private  void sendUpdateServer(String resultInfo, ChannelHandlerContext  channelContext,byte[] updatedata,short total,short current,String requestId,String msgNo) throws Exception {
	    		    Thread.currentThread();Thread.sleep(15);//因为设备升级的数据包很大 避免通道只被升级包占用 给其他的控制消息也能执行下去 所以当前线程休眠一下
	    	    	Map<String, String> message=GsonUtil.parseJsonWithClass(resultInfo, Map.class);
	    	    	BaseHeaderDto header=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("header")), BaseHeaderDto.class);;
	    	     	headerMap=new HashMap();
	    	     	headerMap.put("clentid", header.getClentid());
	    	     	//json控制数据：0 
	    	     	//二进制图片数据：1
	    	     	//二进制日志数据：2
	    	     	//二进制升级文件：3 
	    	     	//二进制mjpeg：4  
	    	     	//二进制H264：5
	    	     	//二进制语音：6
	    	     	Integer fileType=3;
	    	     	Integer  reqtype=1;//请求类型
	    	        Integer type=1;//1web2app3小程序
	    	    	Integer msgLengthInt=0;//数据长度
	    	    	byte[] totaldata = CommunicationUtils.toHH(total);//字节序高低位
	    	    	byte[] currentdata =CommunicationUtils.toHH( current);//字节序高低位
	    	    	byte[] requestIddata=CommunicationUtils.toHH(Integer.valueOf(requestId));
	    	    	if(currentdata==null||requestIddata==null||totaldata==null) {
	    	    		System.err.println("22");
	    	    	}else {

	    	    	}
	    	    	byte[] updateheaderdata=CommunicationUtils.byteMerger(requestIddata,CommunicationUtils.byteMerger(totaldata,currentdata));//设备升级包头的信息
	    	    	byte[] sendData=CommunicationUtils.byteMerger(updateheaderdata,updatedata);//设备升级包数据
	    	    	if(total!=current) {//包总数和当前包 如果总数与当前不匹配的包的信息长度为1400 最后一个不不一样  前面的包都是一样大小
	    	    		msgLengthInt=1400;
	    	    	}else {
	    	    		msgLengthInt=sendData.length;
	    	    	}
	    	    	String msgLength="";//当前包长度 加入1400要凑够8位数
	    	     	for(int i=0;i<8-msgLengthInt.toHexString(msgLengthInt).length();i++) {
	    	     		msgLength+="0";
	    	     	}
	    	     	//appId凑够8位数
	    	     	String appId="0"+type+ProfileUtil.getAtomicCounter();//取时间搓后面6位  确定唯一性
	    	     	int xhCount=8-appId.length();
	    	     	for( int i=0;i<xhCount;i++) {
	    	     		appId+="0";
	    	     	}
	    	     	//发消息给设备 组装头信息 数据 尾信息
	    	     	byte[] msgProperty=CommunicationUtils.hex2byte("0"+type+"010"+reqtype+"0"+fileType);//消息属性
	    	     	byte[] msgLengthStr=CommunicationUtils.hex2byte(msgLength+msgLengthInt.toHexString(msgLengthInt));//消息长度
	    	        byte[]	msgNobyte={(byte) 0x18,(byte) 0x00,(byte) 0x05,(byte) 0x00};//消息号
	    	     	if(msgProperty==null||msgLengthStr==null||msgNobyte==null||CommunicationUtils.hex2byte(appId)==null) {
	    	     		System.out.println("");
	    	     	}else {
	    	     		byte[] headertmp = {(byte) 0xab,(byte) 0xab,(byte) 0xab,(byte) 0xab};//头信息
	    	     	    byte[] tcpHeader=CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(headertmp,CommunicationUtils.hex2byte("00000001")),CommunicationUtils.byteMerger(CommunicationUtils.hex2byte(appId),msgProperty)),CommunicationUtils.byteMerger(msgNobyte,msgLengthStr));
	    	     	    byte[] bytesWrite = null;
	    	     	    byte[] tmpb = {(byte) 0xcd,(byte) 0xcd,(byte) 0xcd,(byte) 0xcd};
	    	     	    bytesWrite = CommunicationUtils.byteMerger(CommunicationUtils.byteMerger(tcpHeader,sendData),tmpb);
	    	     	    ByteBuf	buf = channelContext.alloc().buffer(bytesWrite.length); 
	    			    buf.writeBytes(bytesWrite); //写入到bytesWrite
	    			    channelContext.writeAndFlush(buf);//发送消息到设备
	    			    Thread.currentThread();Thread.sleep(10);//因为设备升级的数据包很大 避免通道只被升级包占用 给其他的控制消息也能执行下去 所以当前线程休眠一下
		    			buf=null;
		    			tcpHeader=null;
		    			bytesWrite=null;
		    			msgNobyte=null;
		    			msgLengthStr=null;
		    			msgProperty=null;
		    			appId=null;
		    			msgLengthInt=null;
		    			message=null;
		    			headerMap=null;
		    			fileType=null;
		    	    	type=null;//1web2app3小程序
		    	    	reqtype=null;//请求类型
		    	    	msgLengthInt=null;
		    	   	    msgLength=null;
		    	       	resultInfo=null;
		    	   	    msgNo=null;
		    	   	    updatedata=null;
	    	   
	    	      }
	    	    	
	    		}
	    
}
