package com.linkedkeeper.tcp.connector.tcp.server.communication;

import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import com.camera.im.utils.GsonUtil;
import com.linkedkeeper.tcp.common.SdkSnapshot;

public class RealTimeSnapshotDataThread extends Thread{
	private SdkSnapshot body;
	public RealTimeSnapshotDataThread(SdkSnapshot body ) {
		this.body=body;
	}
	public void run() {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost post =null;
		 ContentType strContent=null;
   			try{
   		         post = new HttpPost(CommunicationConfig.myHostNmae+":8080/api-dl/logs-anon/save");
   		        strContent=ContentType.create("text/plain",Charset.forName("UTF-8"));
   		        post.setEntity(MultipartEntityBuilder.create()
   		        		.addTextBody("var",GsonUtil.parseToJson(body))  
   				        .addTextBody("data", body.getPlateresult(),strContent)
   				        .build());  
   		         httpclient.execute(post);  
   		     
   			}catch(Exception e){
   				e.printStackTrace();
   			}finally {
   				try {
					httpclient.close();
					post=null;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
   			httpclient=null;
   			post=null;
   			this.body=null;
   			
   			Thread.currentThread();
			Thread.yield();	
	}
	
}