/*
 * Copyright (c) 2016, LinkedKeeper
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * - Neither the name of LinkedKeeper nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.linkedkeeper.tcp.connector.tcp.server._6790;

import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.camera.im.model.BaseHeaderDto;
import com.camera.im.model.UpdateDto;
import com.camera.im.utils.GsonUtil;
import com.camera.im.utils.HttpUtil;
import com.google.gson.internal.LinkedTreeMap;
import com.linkedkeeper.tcp.common.Encryption;
import com.linkedkeeper.tcp.common.SdkSnapshot;
import com.linkedkeeper.tcp.connector.tcp.TcpConnector;
import com.linkedkeeper.tcp.connector.tcp.config.ServerTransportConfig;
import com.linkedkeeper.tcp.connector.tcp.server.communication.ByteUtils;
import com.linkedkeeper.tcp.connector.tcp.server.communication.CommunicationUtils;
import com.linkedkeeper.tcp.connector.tcp.server.communication.DeviceUpdateThread;
import com.linkedkeeper.tcp.connector.tcp.server.communication.LinkDeviceThread;
import com.linkedkeeper.tcp.connector.tcp.server.communication.SendMessageServerThread;
import com.linkedkeeper.tcp.constant.Constants;
import com.linkedkeeper.tcp.message.MessageWrapper;
import com.linkedkeeper.tcp.message.SystemMessage;
import com.linkedkeeper.tcp.model.Data;
import com.linkedkeeper.tcp.model.DeviceControlData;
import com.linkedkeeper.tcp.model.DeviceControlHeader;
import com.linkedkeeper.tcp.model.Header;
import com.linkedkeeper.tcp.model.Param;
import com.linkedkeeper.tcp.notify.NotifyProxy;
import com.linkedkeeper.tcp.utils.AESUtils;
import com.linkedkeeper.tcp.utils.NetUtils;

import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.util.ResourceLeakDetector;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
@ChannelHandler.Sharable
public class TcpServerHandler extends ChannelInboundHandlerAdapter {
	 private final static Logger logger = LoggerFactory.getLogger(TcpServerHandler.class);
	    private TcpConnector tcpConnector = null;
	    private SendMessageServerThread sendMessageServer=null;//向设备发送信息类
	    private NotifyProxy notify = null;
	    public static  Map<String, String> snoMap=new HashMap();
	    
	    public TcpServerHandler(ServerTransportConfig config) {
	        this.tcpConnector = config.getTcpConnector();
	        this.notify = config.getNotify();
	        this.sendMessageServer=new SendMessageServerThread();
	    }
	    private static String jwStr="affe";//结尾
	    public static Map<String, String> serverIpPortMap=new HashMap();
	    static Map<String, byte[]>   req2Map=new HashMap();
	    static Map<String,Integer> conutMap=new HashMap();//粘包拆包标识
	   public static Map<String, ChannelHandlerContext> channelHandlerContextMap=new HashMap();
	    public static Map<String,Socket> socketMap=new HashMap();//通信map
	    private byte[] req2byte=new byte[0];//粘包拆包数据
	    SdkSnapshot carInofbody=null;//出入记录类
	  	BaseHeaderDto   headerjson=null;//头信息
	  	byte[] jwFlag=new byte[2];//结尾标识
	  	byte [] headebyte=new byte[8];//头
	  	byte[] msgHeader=new byte[5];//图片头
	  	byte[] jw=new byte[4];//结尾
	  	byte[] msgImageId=new byte[4];//图片数据id
	    byte [] startByte=new byte[2];//开始标识
    public void channelRead( ChannelHandlerContext channelContext, Object o) throws Exception {
     	 byte[] json=null;
    	 ByteBuf buf=null;
     	 String endFlag=null;
   	     ResourceLeakDetector.setLevel(ResourceLeakDetector.Level.ADVANCED);
	     byte[]  req =null;
    	 InetSocketAddress  insocket = (InetSocketAddress) channelContext.channel().remoteAddress();
    	 String serverip=insocket.getAddress().getHostAddress();
    	 Long serverport=Long.valueOf(insocket.getPort());
    	 String headerStr=null;
       	 String headerMsg=null;
  		 String msgNo=null;
  		 channelHandlerContextMap.put(serverip+"_"+serverport, channelContext);
  		 if(!conutMap.containsKey(serverip+"_"+serverport)) {
  			conutMap.put(serverip+"_"+serverport, 0);
  		 }
  		 if(!req2Map.containsKey(serverip+"_"+serverport)) {
  			req2Map.put(serverip+"_"+serverport, req2byte);
  		}
        try {
        	 buf = (ByteBuf) o; 
        	 req = new byte[buf.readableBytes()];
		     buf.readBytes(req);
		     //处理粘包 拆包
		     if(req.length>8) {
 		        for(int i=req.length-2;i<req.length;i++) {
 		        	jwFlag[i-(req.length-2)]=req[i];
 		        }
 		        endFlag=ByteUtils.bytesToHexString(jwFlag);
 		        if(conutMap.get(serverip+"_"+serverport)>0) {
 		          try {
	 		        req=CommunicationUtils.byteMerger(req2Map.get(serverip+"_"+serverport),req);
 		            }catch (Exception e) {
					}
	 		    }
	 		    if(!"affe".equals(endFlag)) {//如果没有结尾继续读取下一个包 直到结尾了
	 		       req2Map.put(serverip+"_"+serverport, req);
	 		       conutMap.put(serverip+"_"+serverport, 1);
	 		    }else {
	 		        conutMap.put(serverip+"_"+serverport, 0);
	 		    }
			    for(int i=0;i<2;i++) {
			        startByte[i]=req[i];//开始字节
	 		    }
		   }
	        buf.release();
	        o=null;
        	buf=null;
	        if(startByte==null) {
	        	return ;
	        }
	        String startStr=ByteUtils.bytesToHexString(startByte);
	        if(jwStr.equals(endFlag)&&"affb".equals(startStr)) {
	        	 String msg="";
	        	 ByteUtils byteUtils=new ByteUtils();
	        	conutMap.put(serverip+"_"+serverport, 0);
	        	req2Map.put(serverip+"_"+serverport, req2byte);
	        	
 		    	//登录时保存每个通道的sno
	            String channelKey=serverip+"_"+serverport;
	            String reqString= ByteUtils.bytesToHexString(req);
	            
	            String reqStringAttr[]=reqString.split("affe");
	            for(String datastr:reqStringAttr) {
	            	if(datastr==null||"".equals(datastr)) {
	            		continue;
	            	}
		        headerStr=datastr.substring(0, 16);
		        headerMsg=headerStr;
		        json=datastr.substring(16,datastr.length()).getBytes();
		        logger.info("headerMsg:{}", headerMsg);
		       //获取版本号
		       int version=Integer.valueOf(headerMsg.substring(4,6));
		       
		       int versionInt=  (version&0xFC)>>2;
					logger.info("versionInt:{}", versionInt);
		       msg =  headerMsg+AESUtils.Decrypt(ByteUtils.hexStringToBytes(datastr.substring(24,datastr.length()-4)), Encryption.encryptionMap.get(versionInt+""))+ByteUtils.bytesToHexString(jw);//解密
		       String    msgjson=AESUtils.Decrypt(ByteUtils.hexStringToBytes(datastr.substring(24,datastr.length()-4)),Encryption.encryptionMap.get(versionInt+""));
		       
		     
		       Header headerInfo=(Header)com.alibaba.fastjson.JSONObject.parseObject(msgjson, Header.class);
		       
		    	 msgNo=headerInfo.getBizType()+"";
		
		    	 BaseHeaderDto headerjson=new BaseHeaderDto();
		    	 headerjson.setSno(headerInfo.getDeviceId());
		    	 headerjson.setServerip(serverip);
		    	 headerjson.setServerport(serverport);
		    	 headerjson.setClentid(headerInfo.getSessionId());
		    	 headerjson.setMsgno(msgNo);
             	msgjson=JSONObject.toJSONString(headerjson);
	               if("1999".equals(msgNo)) {//心跳
	             		String sno= snoMap.get(serverip+"_"+serverport);
	             		Socket socket1=socketMap.get(channelKey);

	             		if(socket1==null||!socket1.connected()) {
	             			System.err.println("socket1"+socket1);
	             			new linkSockeIo(serverip, serverport, sno, channelKey,versionInt).start();
	             		}
	             		
	             		
	             		socket1.emit("MSG_R_HEART_EVENT",sno+"_"+serverip+"_"+serverport+"_"+socket1.id());//
	             		
	             		Header headerInfo1=new Header();
             	     	headerInfo1.setBizType(Integer.valueOf(msgNo));
             	     	headerInfo1.setDeviceId(headerInfo.getDeviceId());
             	     	headerInfo1.setSessionId(headerInfo.getSessionId());
             	     	headerInfo1.setStatus(200);
             	     	headerInfo1.setVer(1);
             	     	Data data=new Data();
             	     	data.setUpdateTime(System.currentTimeMillis());
             	     	Param param=new Param();
             	     	headerInfo1.setData(data);
             	     	data.setParam(param);
             	     	logger.info("headerInfo1:{}", JSONObject.toJSONString(headerInfo1));
             	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo1),channelContext,7,versionInt);
	             		
	             	}else if("1000".equals(msgNo)) {//相机登录
	                    String sno=headerInfo.getDeviceId();//设备序列号
	                    String deviceConfig=HttpUtil.doGet(com.camera.im.utils.Constants.DOMIAN_NAME+":8081/api-d/deviceconfig/userdevice-anon/info/"+sno);
	                    Map<String,Object> body=GsonUtil.parseJsonWithClass(deviceConfig, Map.class);//包信息
	                
	                    
	                    if(body.containsKey("authority")) {//运行模式
         	     			Integer msgNo1=Constants.deviceControlMap.get("authority");
         	     			DeviceControlHeader deviceControlHeader=new DeviceControlHeader();
         	     			deviceControlHeader.setBizType(msgNo1);
         	     			deviceControlHeader.setDeviceId(sno);
         	     			deviceControlHeader.setSessionId("");
         	     			deviceControlHeader.setStatus(0);
         	     			deviceControlHeader.setVer(1);
                 	     	DeviceControlData data=new DeviceControlData();
                 	     	data.setUpdateTime(System.currentTimeMillis());
                 	     	Map<String, Object> param=new HashMap();
                 	     	param.put("authority","1,2,10");
                 	     	param.put("modeName", body.get("modename"));
                 	     	param.put("workMode", body.get("workmode"));
                 	     	deviceControlHeader.setData(data);
                 	     	data.setParam(param);
                 	     	System.err.println(JSONObject.toJSONString(deviceControlHeader));
                 	     	sendMessageServer.sendServer(JSONObject.toJSONString(deviceControlHeader),channelContext,7,versionInt);
         	     		}
	                    
	                    if(body.containsKey("companystatus")) {//公司状态
         	     			Integer msgNo1=Constants.deviceControlMap.get("companystatus");
         	     			DeviceControlHeader deviceControlHeader=new DeviceControlHeader();
         	     			deviceControlHeader.setBizType(msgNo1);
         	     			deviceControlHeader.setDeviceId(sno);
         	     			deviceControlHeader.setSessionId("");
         	     			deviceControlHeader.setStatus(0);
         	     			deviceControlHeader.setVer(1);
                 	     	DeviceControlData data=new DeviceControlData();
                 	     	data.setUpdateTime(System.currentTimeMillis());
                 	     	Map<String, Object> param=new HashMap();
                 	     	param.put("status", body.get("companystatus"));
                 	     	param.put("companyId", body.get("companyId"));
                 	     	deviceControlHeader.setData(data);
                 	     	data.setParam(param);
                 	     	System.err.println(JSONObject.toJSONString(headerInfo));
                 	     	sendMessageServer.sendServer(JSONObject.toJSONString(deviceControlHeader),channelContext,7,versionInt);
         	     		}
         	     		
         	     		if(body.containsKey("startTime")) {//重启时间
         	     			Integer msgNo1=Constants.deviceControlMap.get("startTime");
         	     			DeviceControlHeader deviceControlHeader=new DeviceControlHeader();
         	     			deviceControlHeader.setBizType(msgNo1);
         	     			deviceControlHeader.setDeviceId(sno);
         	     			deviceControlHeader.setSessionId("");
         	     			deviceControlHeader.setStatus(0);
         	     			deviceControlHeader.setVer(1);
                 	     	DeviceControlData data=new DeviceControlData();
                 	     	data.setUpdateTime(System.currentTimeMillis());
                 	     	Map<String, Object> param=new HashMap();
                 	     	param.put("startTime", body.get("startTime"));
                 	     	param.put("endTime", body.get("endTime"));
                 	     	param.put("devRebootTime", body.get("devRebootTime"));
                 	     	param.put("weeks", "0,1,2,3,4,5,6");
                 	     	deviceControlHeader.setData(data);
                 	     	
                 	     	data.setParam(param);
                 	     	System.err.println(JSONObject.toJSONString(headerInfo));
                 	     	sendMessageServer.sendServer(JSONObject.toJSONString(deviceControlHeader),channelContext,7,versionInt);
         	     		}
         	     		if(body.containsKey("livingSwitch")) {//设备重启时间 
       	     		     
         	     			DeviceControlHeader deviceControlHeader=new DeviceControlHeader();
         	     			deviceControlHeader.setBizType(503);
         	     			deviceControlHeader.setDeviceId(sno);
                	     	deviceControlHeader.setSessionId("");
                	     	deviceControlHeader.setStatus(0);
                	     	deviceControlHeader.setVer(1);
                	     	DeviceControlData data=new DeviceControlData();
                	     	data.setUpdateTime(System.currentTimeMillis());
                	     	Map<String, Object> param=new HashMap();
                	     	param.put("livingSwitch", body.get("livingSwitch"));
                	     	deviceControlHeader.setData(data);
                	     	
                	     	data.setParam(param);
                	     	System.err.println("zhenglong"+JSONObject.toJSONString(headerInfo));
                	     	sendMessageServer.sendServer(JSONObject.toJSONString(deviceControlHeader),channelContext,7,versionInt);
        	     		}
         	     		for(String key : body.keySet()){
         	     			if(key.contains("companystatus")) {
         	     				continue;
         	     			}
         	     			if(key.contains("startTime")) {
         	     				continue;
         	     			}
         	     			if(key.contains("id")) {
         	     				continue;
         	     			}
         	     			if(key.contains("authority")||key.contains("modeName")||key.contains("workMode")) {
         	     				continue;
         	     			}
         	     			if(body.get(key)==null) {
         	     				continue;
         	     			}
         	     			Integer msgNo1=Constants.deviceControlMap.get(key);
         	     			DeviceControlHeader deviceControlHeader=new DeviceControlHeader();
         	     			deviceControlHeader.setBizType(msgNo1);
         	     			deviceControlHeader.setDeviceId(sno);
         	     			deviceControlHeader.setSessionId("");
         	     			deviceControlHeader.setStatus(0);
         	     			deviceControlHeader.setVer(1);
                 	     	DeviceControlData data=new DeviceControlData();
                 	     	data.setUpdateTime(System.currentTimeMillis());
                 	     	Map<String, Object> param=new HashMap();
                 	     	param.put(key.replace("threshold1", "threshold").replace("thresholdn", "threshold").replace("thresholdnn", "threshold").replace("1", "").replace("workstatus", "status"), body.get(key));
                 	     	deviceControlHeader.setData(data);
                 	     	data.setParam(param);
                 	     	sendMessageServer.sendServer(JSONObject.toJSONString(deviceControlHeader),channelContext,7,versionInt);
         	     		}
             	     	
         	     		
         	     		Integer msgNo1=1001;
     	     			DeviceControlHeader deviceControlHeader=new DeviceControlHeader();
     	     			deviceControlHeader.setBizType(msgNo1);
     	     			deviceControlHeader.setDeviceId(sno);
     	     			deviceControlHeader.setSessionId("");
     	     			deviceControlHeader.setStatus(0);
     	     			deviceControlHeader.setVer(1);
             	     	DeviceControlData data=new DeviceControlData();
             	     	data.setUpdateTime(System.currentTimeMillis());
             	     	
             	     	Map<String, Object> param=new HashMap();
             	     	deviceControlHeader.setData(data);
             	     	data.setParam(param);
             	     	sendMessageServer.sendServer(JSONObject.toJSONString(deviceControlHeader),channelContext,7,versionInt);
	                    Object deviceExits=	tcpConnector.getRedisTemplate().boundHashOps(sno+"_LINK");//判断设备是否绑定过一次
	                    if(socketMap.get(channelKey)!=null) {//如果已经连接了就不需要再次连接
	                    }else {
	                    	new linkSockeIo(serverip, serverport, sno, channelKey,versionInt).start();
	                    	
	                    }		
	             	}else {//相机给云端的消息
	             		Socket socket=socketMap.get(channelKey);
	             		String sno= snoMap.get(serverip+"_"+serverport);
	             		if("1004".equals(msgNo)) {//设备注销
	             		  String result=	HttpUtil.doPost(com.camera.im.utils.Constants.DOMIAN_NAME+":8081/api-d/userdevice-anon/updatedeviceconfig/"+sno, new HashMap<String,Object>());
	             		  if(result!=null) {
	             		
	         	     			DeviceControlHeader deviceControlHeader=new DeviceControlHeader();
	         	     			deviceControlHeader.setBizType(1004);
	         	     			deviceControlHeader.setDeviceId(sno);
	         	     			deviceControlHeader.setSessionId("");
	         	     			deviceControlHeader.setStatus(200);
	         	     			deviceControlHeader.setVer(1);
	                 	     	DeviceControlData data=new DeviceControlData();
	                 	     	data.setUpdateTime(System.currentTimeMillis());
	                 	     	Map<String, Object> param=new HashMap();
	                 	     	data.setParam(param);
	                 	     	deviceControlHeader.setData(data);
	                 	     	logger.info("zhenglong versionInt:{}, deviceControlHeader:{}", versionInt, JSONObject.toJSONString(deviceControlHeader));
	                 	     	sendMessageServer.sendServer(JSONObject.toJSONString(deviceControlHeader),channelContext,7,versionInt);
	             		  }
	             		}
	             		logger.info("msgjson:{},========sno:{}", msgjson, sno);
	             		 socket.emit("MSG_R_MESSAGE_SETUP",msgNo, msgjson,sno,serverip,serverport);
	             	 }
	            }
	    	byteUtils=null;
        }
        //释放内存
        insocket=null;
        headerjson=null;
        buf=null;
        o=null;
	    json=null;
	    endFlag=null;
	    headerStr=null;
	    headerMsg=null;     
    } catch (Exception e) {
        logger.error("TcpServerHandler TcpServerHandler handler error.", e);
        throw e;
    }   
   }
    
    private class linkSockeIo extends Thread{
    	
    	private String serverip;private Long serverport;private String sno;private String channelKey;private int versionInt;
    	public linkSockeIo(String serverip,Long serverport,String sno,String channelKey,int versionInt) throws Exception {
    		this.serverip=serverip;
    		this.serverport=serverport;
    		this.sno=sno;
    		this.channelKey=channelKey;
    		this.versionInt=versionInt;
    	}
    	public void run() {
    	//云端给相机的消息
		 snoMap.put(serverip+"_"+serverport, sno);
        Map<String, Object> params=new HashMap();
        params.put("username", "qianyi2018");
        params.put("password", "copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k=");
        params.put("sno", sno);
        String token=null;
		try {
			token = HttpUtil.doPost("http://127.0.0.1:8090/login",JSONObject.toJSONString(params));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        Map<String, LinkedTreeMap<String,String>> resultMap= GsonUtil.parseJsonWithClass(token, Map.class);
        Socket socket=null;
		try {
			 IO.Options options = new IO.Options();
             options.transports = new String[]{"websocket"};
             options.reconnectionAttempts = 2;
             options.reconnectionDelay = 1000;//失败重连的时间间隔
             options.timeout = 500;//连接超时时间(ms)
          final   Socket socket1 = IO.socket("http://127.0.0.1:"+resultMap.get("content").get("nssserverport")+"?sno="+sno+"&user_token="+resultMap.get("content").get("user_token")+"&serverip="+serverip+"&serverport="+serverport, options);
          socket=socket1;
          
		} catch (URISyntaxException e1) {
			e1.printStackTrace();
		}
        socket.open();
        socket.connect();
        int count=0;
        while(!socket.connected()&&count<10) {
        	
        	 params=new HashMap();
             params.put("username", "qianyi2018");
             params.put("password", "copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k=");
             params.put("sno", sno);
        	
              token=null;
     		try {
     			token = HttpUtil.doPost("http://127.0.0.1:8090/login",JSONObject.toJSONString(params));
     		} catch (Exception e1) {
     			// TODO Auto-generated catch block
     			e1.printStackTrace();
     		}

     		 resultMap= GsonUtil.parseJsonWithClass(token, Map.class);
        	 
        	 IO.Options options = new IO.Options();
             options.transports = new String[]{"websocket"};
             options.reconnectionAttempts = 2;
             options.reconnectionDelay = 1000;//失败重连的时间间隔
             options.timeout = 500;//连接超时时间(ms)

             Socket socket2=null;
			try {
				final	Socket socket1 = IO.socket("http://127.0.0.1:"+resultMap.get("content").get("nssserverport")+"?sno="+sno+"&user_token="+resultMap.get("content").get("user_token")+"&serverip="+serverip+"&serverport="+serverport, options);
				socket1.connect();
				socket2=socket1;
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
             
            socket=socket2;
            count++;
        }
        socket.on("MSG_R_MESSAGE_SETUP", new Emitter.Listener() {//控制消息
            @Override
            public synchronized void call(Object... args) {    
        	        String resultInfo = (String)args[0];
        	       try {
        	    	Map<String, String> message=GsonUtil.parseJsonWithClass(resultInfo, Map.class);//包头信息
					   logger.info("MSG_R_MESSAGE_SETUP message:{}", JSON.toJSONString(message));
        	     	BaseHeaderDto header=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("header")), BaseHeaderDto.class);//包信息
					   logger.info("MSG_R_MESSAGE_SETUP header:{}", JSON.toJSONString(header));
        	     	if(header.getMsgno().equals("1002")) {
            	     	Header headerInfo=new Header();
            	     	headerInfo.setBizType(Integer.valueOf(header.getMsgno()));
            	     	headerInfo.setDeviceId(header.getSno());
            	     	headerInfo.setSessionId(header.getClentid());
            	     	headerInfo.setStatus(0);
            	     	headerInfo.setVer(1);
            	     	Data data=new Data();
            	     	data.setUpdateTime(System.currentTimeMillis());
            	     	Param param=new Param();
            	     	param.setInfoType(2001);
            	     	headerInfo.setData(data);
            	     	data.setParam(param);
            	     	System.err.println("收到更新人脸"+JSONObject.toJSONString(headerInfo));
            	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     	}
					   if(header.getMsgno().equals("2050")) {
						   Header headerInfo=new Header();
						   headerInfo.setBizType(1002);
						   headerInfo.setDeviceId(header.getSno());
						   headerInfo.setSessionId(header.getClentid());
						   headerInfo.setStatus(0);
						   headerInfo.setVer(1);
						   Data data=new Data();
						   data.setUpdateTime(System.currentTimeMillis());
						   Param param=new Param();
						   param.setInfoType(2050);
						   headerInfo.setData(data);
						   data.setParam(param);
						   logger.info("MSG_R_MESSAGE_SETUP 广告轮播图:{}", JSON.toJSONString(headerInfo));
						   sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
					   }
        	    	if(header.getMsgno().equals("2099")) {
            	     	Header headerInfo=new Header();
            	     	headerInfo.setBizType(1002);
            	     	headerInfo.setDeviceId(header.getSno());
            	     	headerInfo.setSessionId(header.getClentid());
            	     	headerInfo.setStatus(0);
            	     	headerInfo.setVer(1);
            	     	Data data=new Data();
            	     	data.setUpdateTime(System.currentTimeMillis());
            	     	Param param=new Param();
            	     	param.setInfoType(2099);
            	     	headerInfo.setData(data);
            	     	data.setParam(param);
            	     	System.err.println("升级Apk包"+JSONObject.toJSONString(headerInfo));
            	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     	}
        	     	if(header.getMsgno().equals("2005")) {
            	     	Header headerInfo=new Header();
            	     	headerInfo.setBizType(1002);
            	     	headerInfo.setDeviceId(header.getSno());
            	     	headerInfo.setSessionId(header.getClentid());
            	     	headerInfo.setStatus(0);
            	     	headerInfo.setVer(1);
            	     	Data data=new Data();
            	     	data.setUpdateTime(System.currentTimeMillis());
            	     	Param param=new Param();
            	     	param.setInfoType(2005);
            	     	headerInfo.setData(data);
            	     	data.setParam(param);
            	     	System.err.println("更新班次信息啦"+JSONObject.toJSONString(headerInfo));
            	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     	}
        	     	if(header.getMsgno().equals("1003")) {
        	     		Map<String,Object> body=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("body")), Map.class);//包信息
        	     		if(body.containsKey("companystatus")) {//公司状态
        	     			Integer msgNo=Constants.deviceControlMap.get("companystatus");
        	     			DeviceControlHeader headerInfo=new DeviceControlHeader();
                	     	headerInfo.setBizType(msgNo);
                	     	headerInfo.setDeviceId(header.getSno());
                	     	headerInfo.setSessionId(header.getClentid());
                	     	headerInfo.setStatus(0);
                	     	headerInfo.setVer(1);
                	     	DeviceControlData data=new DeviceControlData();
                	     	data.setUpdateTime(System.currentTimeMillis());
                	     	Map<String, Object> param=new HashMap();
                	     	param.put("status", body.get("companystatus"));
                	     	param.put("companyId", body.get("companyId"));
                	     	headerInfo.setData(data);
                	     	data.setParam(param);
                	     	System.err.println("设备控制"+JSONObject.toJSONString(headerInfo));
                	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     		}
        	     		
        	     		if(body.containsKey("authority")) {//运行模式
        	     			Integer msgNo=Constants.deviceControlMap.get("authority");
        	     			DeviceControlHeader headerInfo=new DeviceControlHeader();
                	     	headerInfo.setBizType(msgNo);
                	     	headerInfo.setDeviceId(header.getSno());
                	     	headerInfo.setSessionId(header.getClentid());
                	     	headerInfo.setStatus(0);
                	     	headerInfo.setVer(1);
                	     	DeviceControlData data=new DeviceControlData();
                	     	data.setUpdateTime(System.currentTimeMillis());
                	     	Map<String, Object> param=new HashMap();
                	     	param.put("authority", body.get("authority"));
                	     	param.put("modeName", body.get("modeName"));
                	     	param.put("workMode", body.get("workMode"));
                	     	headerInfo.setData(data);
                	     	data.setParam(param);
                	     	System.err.println("设备控制"+JSONObject.toJSONString(headerInfo));
                	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     		}
        	     		
        	     		
        	     		if(body.containsKey("picFlag")) {//图片是否上传开关
        	     			DeviceControlHeader headerInfo=new DeviceControlHeader();
                	     	headerInfo.setBizType(502);
                	     	headerInfo.setDeviceId(header.getSno());
                	     	headerInfo.setSessionId(header.getClentid());
                	     	headerInfo.setStatus(0);
                	     	headerInfo.setVer(1);
                	     	DeviceControlData data=new DeviceControlData();
                	     	data.setUpdateTime(System.currentTimeMillis());
                	     	Map<String, Object> param=new HashMap();
                	     	param.put("picFlag", body.get("picFlag"));
                	     	headerInfo.setData(data);
                	     	data.setParam(param);
                	     	System.err.println("设备控制"+JSONObject.toJSONString(headerInfo));
                	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     		}
        	     		
        	     		
        	     		if(body.containsKey("startTime")) {//设备重启时间 
     
        	     			DeviceControlHeader headerInfo=new DeviceControlHeader();
                	     	headerInfo.setBizType(2);
                	     	headerInfo.setDeviceId(header.getSno());
                	     	headerInfo.setSessionId(header.getClentid());
                	     	headerInfo.setStatus(0);
                	     	headerInfo.setVer(1);
                	     	DeviceControlData data=new DeviceControlData();
                	     	data.setUpdateTime(System.currentTimeMillis());
                	     	Map<String, Object> param=new HashMap();
                	     	param.put("startTime", body.get("startTime"));
                	     	param.put("endTime", body.get("endTime"));
                	     	param.put("devRebootTime", body.get("devRebootTime"));
                	     	param.put("weeks", "0,1,2,3,4,5,6");
                	     	headerInfo.setData(data);
                	     	
                	     	data.setParam(param);
                	     	System.err.println("设备控制"+JSONObject.toJSONString(headerInfo));
                	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     		}
        	     		if(body.containsKey("livingSwitch")) {//设备重启时间 
        	     		     
        	     			DeviceControlHeader headerInfo=new DeviceControlHeader();
                	     	headerInfo.setBizType(503);
                	     	headerInfo.setDeviceId(header.getSno());
                	     	headerInfo.setSessionId(header.getClentid());
                	     	headerInfo.setStatus(0);
                	     	headerInfo.setVer(1);
                	     	DeviceControlData data=new DeviceControlData();
                	     	data.setUpdateTime(System.currentTimeMillis());
                	     	Map<String, Object> param=new HashMap();
                	     	param.put("livingSwitch", body.get("livingSwitch"));
                	     	headerInfo.setData(data);
                	     	
                	     	data.setParam(param);
                	     	System.err.println("设备控制"+JSONObject.toJSONString(headerInfo));
                	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     		}
        	     		for(String key : body.keySet()){
        	     			if(key.contains("companystatus")) {
        	     				continue;
        	     			}
        	     			if(key.contains("startTime")) {
        	     				continue;
        	     			}
        	     			if(key.contains("authority")) {
        	     				continue;
        	     			}
        	     			if(key.contains("picFlag")) {
        	     				continue;
        	     			}
        	     			Integer msgNo=Constants.deviceControlMap.get(key);
        	     			DeviceControlHeader headerInfo=new DeviceControlHeader();
                	     	headerInfo.setBizType(msgNo);
                	     	headerInfo.setDeviceId(header.getSno());
                	     	headerInfo.setSessionId(header.getClentid());
                	     	headerInfo.setStatus(0);
                	     	headerInfo.setVer(1);
                	     	DeviceControlData data=new DeviceControlData();
                	     	data.setUpdateTime(System.currentTimeMillis());
                	     	Map<String, Object> param=new HashMap();
                	     	param.put(key.replace("threshold1", "threshold").replace("thresholdn", "threshold").replace("thresholdnn", "threshold").replace("1", "").replace("workstatus", "status"), body.get(key));
                	     	headerInfo.setData(data);
                	     	data.setParam(param);
                	     	
                	     	sendMessageServer.sendServer(JSONObject.toJSONString(headerInfo), resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
        	     		}
            	     	
        	     	}
				} catch (Exception e) {
					e.printStackTrace();
				}
        	     resultInfo=null;
        	     args=null;
            }
        }).on("MSG_R_CONN_CAMERA_SETUP", new Emitter.Listener() {//验证登录登录
            @Override
            public synchronized void call(Object... args) {      
              String resultInfo = (String)args[0];
         			try {
         				Map<String, String> message=GsonUtil.parseJsonWithClass(resultInfo, Map.class);//包头信息
            	     	BaseHeaderDto header=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("header")), BaseHeaderDto.class);//包信息
            	     	sendMessageServer.sendServer(resultInfo,resultInfo, channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);//发消息给设备
					} catch (Exception e) {
						e.printStackTrace();
					}
        	     resultInfo=null;
        	     args=null;
            }
          
        }).on("MSG_R_UPDATE_DATA", new Emitter.Listener() {//升级消息
            @Override
            public synchronized void call(Object... args) {      
              String resultInfo = (String)args[0];
         			try {
         				Map<String, String> message=GsonUtil.parseJsonWithClass(resultInfo, Map.class);
            	     	BaseHeaderDto header=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("header")), BaseHeaderDto.class);//升级包头信息
            	     	UpdateDto UpdateDto=GsonUtil.parseJsonWithClass(GsonUtil.parseToJson(message.get("body")), UpdateDto.class);//升级包信息
            	     	sendMessageServer.sendServer(resultInfo, resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport()),7,versionInt);
						new DeviceUpdateThread((String)args[1],UpdateDto.getRequestid(),resultInfo,channelHandlerContextMap.get(header.getServerip()+"_"+header.getServerport())).start();//发消息给设备
					} catch (Exception e) {
						e.printStackTrace();
					}
        	      resultInfo=null;
        	      args=null;
            }
          
        });
       BaseHeaderDto header=new BaseHeaderDto();
   	header.setSno(sno);
   	header.setServerip(serverip);
   	header.setServerport(serverport);
   	snoMap.put(channelKey, sno);//登录时绑定ip+port设备号 知道到通道代表那个设备
   	Map<String, Object> map=new HashMap();
   	map.put("header", header);	
		socket.emit("MSG_R_MESSAGE_SETUP", GsonUtil.parseToJson(map));//绑定事件	             		
		socket.emit("MSG_R_UPDATE_DATA","18000500", GsonUtil.parseToJson(map));//升级绑定事件		             		
		socket.emit("MSG_R_REAL_TIME_LOG", GsonUtil.parseToJson(map));//绑定事件		             		
		socket.emit("MSG_R_REAL_TIME_VIDEO", GsonUtil.parseToJson(map));//绑定事件		             	
		socket.emit("MSG_R_CONN_CAMERA_SETUP", GsonUtil.parseToJson(map));//绑定事件验证登录		             		
		socket.emit("MSG_R_REAL_TIME_LOGIN",sno);//相机重新登录
		//sendMessageServer.sendServerHeartLogin("08000001",channelContext,serverip,serverport);//发生连接成功命令  表示与服务器连接成功了 
		socketMap.put(channelKey, socket);

    }
    }
   public void channelRegistered(ChannelHandlerContext ctx) throws Exception {
        logger.debug("TcpServerHandler Connected from {" +
        NetUtils.channelToString(ctx.channel().remoteAddress(), ctx.channel().localAddress()) + "}");
   }
   public void channelUnregistered(ChannelHandlerContext ctx) throws Exception {
        logger.debug("TcpServerHandler Disconnected from {" +
                NetUtils.channelToString(ctx.channel().remoteAddress(), ctx.channel().localAddress()) + "}");
   }
   public void channelActive(ChannelHandlerContext ctx) throws Exception {
    	logger.debug("TcpServerHandler Connected1 from {" +
         NetUtils.channelToString(ctx.channel().remoteAddress(), ctx.channel().localAddress()) + "}");
   }
   public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        super.channelInactive(ctx);
        logger.debug("TcpServerHandler channelInactive from (" + getRemoteAddress(ctx) + ")");
        String sessionId0 = getChannelSessionHook(ctx);
        if (StringUtils.isNotBlank(sessionId0)) {
            tcpConnector.close(new MessageWrapper(sessionId0, null));
            logger.warn("TcpServerHandler channelInactive, close channel sessionId0 -> " + sessionId0 + ", ctx -> " + ctx.toString());
        }
    }
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.warn("TcpServerHandler (" + getRemoteAddress(ctx) + ") -> Unexpected exception from downstream." + cause);
        String sessionId0 = getChannelSessionHook(ctx);
        if (StringUtils.isNotBlank(sessionId0)) {
            logger.error("TcpServerHandler exceptionCaught (sessionId0 -> " + sessionId0 + ", ctx -> " + ctx.toString() + ") -> Unexpected exception from downstream." + cause);
        }
    }
    private String getChannelSessionHook(ChannelHandlerContext ctx) {
        return ctx.channel().attr(Constants.SERVER_SESSION_HOOK).get();
    }
    private void setChannelSessionHook(ChannelHandlerContext ctx, String sessionId) {
        ctx.channel().attr(Constants.SERVER_SESSION_HOOK).set(sessionId);
    }
    private void isConnect0(ChannelHandlerContext ctx, MessageWrapper wrapper) {
        String sessionId = wrapper.getSessionId();
        String sessionId0 = getChannelSessionHook(ctx);
        if (sessionId.equals(sessionId0)) {
            tcpConnector.responseSendMessage(wrapper);
        } else {
            tcpConnector.connect(ctx, wrapper);
            setChannelSessionHook(ctx, sessionId);
        }
    }
    private SystemMessage generateSystemMessage(ChannelHandlerContext ctx) {
        SystemMessage systemMessage = new SystemMessage();
        systemMessage.setRemoteAddress(getRemoteAddress(ctx));
        systemMessage.setLocalAddress(getLocalAddress(ctx));
        return systemMessage;
    }

    private String getRemoteAddress(ChannelHandlerContext ctx) {
        SocketAddress remote1 = ctx.channel().remoteAddress();
        InetSocketAddress remote = (InetSocketAddress) remote1;
        return NetUtils.toAddressString(remote);
    }

    private String getLocalAddress(ChannelHandlerContext ctx) {
        SocketAddress local1 = ctx.channel().localAddress();
        InetSocketAddress local = (InetSocketAddress) local1;
        return NetUtils.toAddressString(local);
    }
}
