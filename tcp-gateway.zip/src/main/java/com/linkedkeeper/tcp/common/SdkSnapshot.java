package com.linkedkeeper.tcp.common;

public class SdkSnapshot {
	private String imageid;
	private String plateresult;
	private String platecolor;
	private String platetype;
	private String score;
	private String direction;
	private String platex0;
	public String getPlatex0() {
		return platex0;
	}
	public void setPlatex0(String platex0) {
		this.platex0 = platex0;
	}
	private String platey0;
	private String platex1;
	private String platey1;
	private String snapsec;
	private String snapusec;
	private String triggertype;
	private String sno;
	public String getSno() {
		return sno;
	}
	public String getImageid() {
		return imageid;
	}
	public void setImageid(String imageid) {
		this.imageid = imageid;
	}
	public String getPlateresult() {
		return plateresult;
	}
	public void setPlateresult(String plateresult) {
		this.plateresult = plateresult;
	}
	public String getPlatecolor() {
		return platecolor;
	}
	public void setPlatecolor(String platecolor) {
		this.platecolor = platecolor;
	}
	public String getPlatetype() {
		return platetype;
	}
	public void setPlatetype(String platetype) {
		this.platetype = platetype;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getPlatey0() {
		return platey0;
	}
	public void setPlatey0(String platey0) {
		this.platey0 = platey0;
	}
	public String getPlatex1() {
		return platex1;
	}
	public void setPlatex1(String platex1) {
		this.platex1 = platex1;
	}
	public String getPlatey1() {
		return platey1;
	}
	public void setPlatey1(String platey1) {
		this.platey1 = platey1;
	}
	public String getSnapsec() {
		return snapsec;
	}
	public void setSnapsec(String snapsec) {
		this.snapsec = snapsec;
	}
	public String getSnapusec() {
		return snapusec;
	}
	public void setSnapusec(String snapusec) {
		this.snapusec = snapusec;
	}
	public String getTriggertype() {
		return triggertype;
	}
	public void setTriggertype(String triggertype) {
		this.triggertype = triggertype;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}

}
