package com.linkedkeeper.tcp.common;

import java.util.HashMap;
import java.util.Map;

public class Encryption {
  public static Map<String,String> encryptionMap=new HashMap<String, String>();
   static {
	   encryptionMap.put("0", "Alf_platform_rel");
	   encryptionMap.put("1", "0d77a5de145b536d");
   }
}
