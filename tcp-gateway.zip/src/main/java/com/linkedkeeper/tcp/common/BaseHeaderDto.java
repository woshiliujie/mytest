package com.linkedkeeper.tcp.common;

public class BaseHeaderDto {
	private String sno;
	private String serverip;
	private Integer serverport;
	private Integer type;//来源 web app
	public String getMsgno() {
		return msgno;
	}

	public void setMsgno(String msgno) {
		this.msgno = msgno;
	}

	private String msgno;//消息号
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getServerip() {
		return serverip;
	}

	public void setServerip(String serverip) {
		this.serverip = serverip;
	}

	public Integer getServerport() {
		return serverport;
	}

	public void setServerport(Integer serverport) {
		this.serverport = serverport;
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	private String clentid;
	public String getClentid() {
		return clentid;
	}

	public void setClentid(String clentid) {
		this.clentid = clentid;
	}






}
