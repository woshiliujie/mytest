package com;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.support.FileSystemXmlApplicationContext;

@SpringBootApplication
@ImportResource("classpath:spring-config-6790.xml")
public class TcpApplication {

	private static Logger logger = LoggerFactory.getLogger(TcpApplication.class);
	
	public static void main(String[] args) throws Exception {
		 //ApplicationContext context = new FileSystemXmlApplicationContext(new String[]{"classpath:spring-config-6790.xml"});
		SpringApplication.run(TcpApplication.class, args);
		logger.info("TcpApplication 程序启动成功！！");
	}

}
