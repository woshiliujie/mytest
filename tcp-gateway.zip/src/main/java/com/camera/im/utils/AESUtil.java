package com.camera.im.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
 
public class AESUtil {
     private static String sKey="qianyi2018000000";
     private static String ivParameter="b5r1i2lL6iA0nt8s";
     // 加密
  

     public static byte[] encrypt(String sSrc) throws Exception {
    	 byte[] sSrcVal=null;
    	 if(sSrc.length()%16!=0) {
    		 int zjsize=16-(sSrc.length()%16);
    		 for(int i=0;i<zjsize;i++) {
    			 sSrc+=" ";
    		 }
    		 sSrcVal=new byte[sSrc.length()];
    	 }else {
    		 sSrcVal=new byte[sSrc.length()];
    	 }
    	 byte[] sSrcByte=sSrc.getBytes("utf-8");
    	 for (int i=0;i<sSrcByte.length;i++) {
    		 if(i>=sSrcVal.length) {
    			 continue;
    		 }
    		 sSrcVal[i]=sSrcByte[i];
		}
 
    	 Cipher   cipher = Cipher.getInstance("AES/CBC/NoPadding");
         byte[] raw = sKey.getBytes();
          SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
         IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());//使用CBC模式，需要一个向量iv，可增加加密算法的强度
         cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
         byte[] encrypted = cipher.doFinal(sSrcVal);
         sSrcVal=null;
         cipher=null;
         iv=null;
         skeySpec=null;
         return encrypted;//此处使用BASE64做转码。
 }
     // 解密
     public static String decrypt(byte[] sSrc) throws Exception {
         try {
        	 byte[]  raw = sKey.getBytes("ASCII");
        	 
            
        	 Cipher   cipher = Cipher.getInstance("AES/CBC/NoPadding");
              IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());
              SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
             cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] encrypted = sSrc;//先用base64解密
            byte[]  original = cipher.doFinal(encrypted);
             original=toNewBuf(original);
             String originalString = new String(original,"utf-8");
             encrypted=null;
             original=null;
             cipher=null;
             skeySpec=null;
             iv=null;
             return originalString;
         } catch (Exception ex) {
             return null;
         }
         
        
 }
     private static byte[] toNewBuf(byte[] buffer) {
    	
    	 int length=0;
    	 for (int i = 0; i < buffer.length; ++i) {
    	    if (buffer[i] == 0) {
        	 length ++;
        	}
    	 }
    	 byte[]  newbuf=new byte[buffer.length-length];
    	 for (int i = 0; i < buffer.length-length; ++i) {
     	   
         		newbuf[i]=buffer[i];
     	 }
    	 return newbuf;
    	
  }
 
}