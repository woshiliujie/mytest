package com.camera.im.model;

public class UpdateDto {
  private String requestid;
  private String filename;
  private String filetype;
public String getRequestid() {
	return requestid;
}
public void setRequestid(String requestid) {
	this.requestid = requestid;
}
public String getFilename() {
	return filename;
}
public void setFilename(String filename) {
	this.filename = filename;
}
public String getFiletype() {
	return filetype;
}
public void setFiletype(String filetype) {
	this.filetype = filetype;
}
}
