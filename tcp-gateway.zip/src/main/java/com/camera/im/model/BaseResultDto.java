package com.camera.im.model;

public class BaseResultDto {
	private Integer result;
     public Integer getResult() {
		return result;
	}

	public void setResult(Integer result) {
		this.result = result;
	}
	public String getCause() {
		return cause;
	}

	public void setCause(String cause) {
		this.cause = cause;
	}
	private String cause;





}
