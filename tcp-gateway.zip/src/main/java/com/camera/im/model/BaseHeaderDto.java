package com.camera.im.model;

public class BaseHeaderDto {
	private String sno;
	private String serverip;
	private Long serverport;
	private String msgno;
	private Integer msgtype;
	private Integer type;//来源 web app
	private Integer index=0;
	
	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getMsgno() {
		return msgno;
	}

	public void setMsgno(String msgno) {
		this.msgno = msgno;
	}

	public Integer getMsgtype() {
		return msgtype;
	}

	public void setMsgtype(Integer msgtype) {
		this.msgtype = msgtype;
	}

	public String getServerip() {
		return serverip;
	}

	public void setServerip(String serverip) {
		this.serverip = serverip;
	}

	public Long getServerport() {
		return serverport;
	}

	public void setServerport(Long serverport) {
		this.serverport = serverport;
	}

	public String getSno() {
		return sno;
	}

	public void setSno(String sno) {
		this.sno = sno;
	}

	private String clentid;

	public String getClentid() {
		return clentid;
	}

	public void setClentid(String clentid) {
		this.clentid = clentid;
	}







}
