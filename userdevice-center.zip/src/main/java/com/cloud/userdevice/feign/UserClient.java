package com.cloud.userdevice.feign;

import java.util.Set;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.cloud.model.user.AppUser;
import com.cloud.model.user.LoginAppUser;
import com.cloud.model.user.SysRole;

@FeignClient("user-center")
public interface UserClient {

    
    @GetMapping(value = "/users-anon/rolesByuserId", params = "userId")
	public Set<SysRole> findByUserId(@RequestParam("userId") Long userId) ;
    
    @GetMapping(value="/users-anon/current", params = "userId")
    public AppUser getLoginAppUserAnon(@RequestParam("userId") Long userId);
}
