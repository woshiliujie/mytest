package com.cloud.userdevice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;

/**
 * Created by Administrator on 2019/5/11.
 */
@RestController
public class UserDeviceController2 {
    private final static Logger log = LoggerFactory.getLogger(UserDeviceController2.class);

    @RequestMapping(value = "/batchInsert2", method = RequestMethod.POST)
    public Map<String, Object> batchInsert(MultipartFile file){
        log.info("=== ---批量导入设备--- === {}", file);
        log.info("=== ---批量导入设备--- === [{}]", file);
        log.info("=== ---批量导入设备--- === [{}]", file);
        log.info("=== ---批量导入设备--- === [{}]", file);
        return null;

    }
}
