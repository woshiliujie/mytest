package com.cloud.userdevice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.userdevice.dao.SysDoorDeptDao;
import com.cloud.userdevice.entity.SysDoorDeptEntity;
import com.cloud.userdevice.service.SysDoorDeptService;
import com.suke.czx.common.utils.PageUtils;
import com.suke.czx.common.utils.Query;
import com.suke.czx.common.utils.R;




/**
 * 门部门表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-18 14:16:55
 */
@RestController
@RequestMapping("/dooruser/sysdoordept")
public class SysDoorDeptController {
    @Autowired
    private SysDoorDeptService sysDoorDeptService;
@Autowired
SysDoorDeptDao sysDoorDeptDao;
    /**
     * 列表
     */
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params){
        //查询列表数据
        Query query = new Query(params);

        List<SysDoorDeptEntity> sysDoorDeptList = sysDoorDeptService.queryList(query);
        int total = sysDoorDeptService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(sysDoorDeptList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }

    
    @RequestMapping("/deptlist/{doorid}")
    public R deptlist(@PathVariable("doorid") Integer doorid){
    	Map<String, Object> params=new HashMap<>();
    	params.put("doorid", doorid);
    	params.put("fdelflag", 0);
        List<SysDoorDeptEntity> sysDoorDeptList = sysDoorDeptDao.queryListFlag(params);
        return R.ok().put("list", sysDoorDeptList);
    }

    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Integer id){
			SysDoorDeptEntity sysDoorDept = sysDoorDeptService.queryObject(id);

        return R.ok().put("sysDoorDept", sysDoorDept);
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    public R save(@RequestBody SysDoorDeptEntity sysDoorDept){
		sysDoorDeptService.save(sysDoorDept);
        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    public R update(@RequestBody SysDoorDeptEntity sysDoorDept){
			sysDoorDeptService.update(sysDoorDept);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Integer[] ids){
			sysDoorDeptService.deleteBatch(ids);

        return R.ok();
    }
	
}
