package com.cloud.userdevice.controller;

import com.alibaba.fastjson.JSON;
import com.cloud.common.constants.Encryption;
import com.cloud.common.utils.AppUserUtil;
import com.cloud.model.common.Page;
import com.cloud.model.common.ResultData;
import com.cloud.model.device.Device;
import com.cloud.model.device.NET_Session_Body;
import com.cloud.model.device.UserDevice;
import com.cloud.model.log.Log;
import com.cloud.model.log.LogAnnotation;
import com.cloud.model.oauth.ExternalRoleInfo;
import com.cloud.model.user.AppUser;
import com.cloud.model.user.SysRole;
import com.cloud.userdevice.config.common.Constant.RedisConst;
import com.cloud.userdevice.dao.DeviceDoorDao;
import com.cloud.userdevice.dao.SysDoorDeptDao;
import com.cloud.userdevice.dao.SysDoorUserDao;
import com.cloud.userdevice.dao.UserDeviceDao;
import com.cloud.userdevice.entity.DeviceDoorEntity;
import com.cloud.userdevice.entity.SysDoorDeptEntity;
import com.cloud.userdevice.feign.LogClient;
import com.cloud.userdevice.feign.SmsClient;
import com.cloud.userdevice.feign.UserClient;
import com.cloud.userdevice.model.*;
import com.cloud.userdevice.service.UserDeviceService;
import com.cloud.userdevice.service.impl.DeviceConfigService;
import com.cloud.userdevice.utils.AESUtils;
import com.cloud.userdevice.utils.RSAUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.suke.czx.common.utils.JWTService;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@RestController
public class UserDeviceController {

    private final static Logger log = LoggerFactory.getLogger(UserDeviceController.class);

	@Autowired
	private UserDeviceService deviceService;
	@Autowired
	private UserDeviceDao userDeviceDao;
	private String PRIVATEKEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBALeGcVIOSRIv4uVOyXtgoH7+zBywqw2e2WLZwHU94Um4mlC3mFc0q/nY8N4RVhKFrEkHtv4S2rlGX2hUGI3EpGQq10x4w5pcVNfpxgpKI4y0aZPeFavAI0ZldZNhUHbCN/9lmsTo17GwugwrSyPyScsnyw4F9netCeiPJaJJu7SBAgMBAAECgYALkLtfcmsEbGQeE0L7NXGnzyLJxBBjgVkts48/VDD4VlvTLl65UCZuTk+PjwQfkrDywTu08zc5acflaTdK59N8KSyONg98DvjYA/w7SqGn5Kn0khDRlIcbSr50y6pcmNMXHhssZRMZXRIKMjYOUj4T1hnYKFcummnNvIGxG3GeAQJBANvgh8TKcFaByaD87Jo4mHfCF9AY1nFi8ztfrkKCwezGqMOeYd4OBPU1KMobKAByiqHl7VwDHPEN3wfLTZDRazECQQDVrQs0TVVCo2PF22JwA5d8ofQOpTUtfAct8blZ3a6vhum2TJCl6CT5SynHkmJTgVXVwIpGkRxm6kzTYerH3upRAkANRASs+NHCRl5V2iykOVnpj8pEAdueR6wJHwKyfJUapfm0o6+f6BSgfq6RUwYc0MxQbEDf1kg+uumD3N43KIthAkEAxGEtkvwgCAayg/2FEv26FEmkTHF51jvPPWKTvwwGqDuOQIVNy6z3jkaON2VKCQUtJi625vQm7k8YHI45gUhWgQJAfDtR23VirW2iAu8gTi1dsDDTIMAAhZNmSn+nTdAN9kCZuic/jsHrThn06EXByINk07xSBtfN//hJrKO8rrg9UA==";
//手动添加设备
	@PreAuthorize("hasAuthority('device:save')")
	@PostMapping("/savedevice")
	 @LogAnnotation(module ="添加设备")
	public void save(@RequestBody Device device) {
		AppUser user = AppUserUtil.getLoginAppUser();
		user=userClient.getLoginAppUserAnon(user.getId());
		Device deviceVo=new Device();
		deviceVo.setMacAddres(device.getMacAddres());
		deviceVo.setSno(device.getMacAddres());
		deviceVo.setUserId(user.getId());

		device.setUserId(user.getId());

		Device userdevice=deviceService.findByUserSno(device);

		//自己创建
		if(userdevice==null) {
			device.setCompanyid(user.getCompanysId()==null?user.getUserCompanysId():user.getCompanysId());//如果为空就是小区
			userDeviceDao.saveDevice(device);
			UserDevice log=new UserDevice();
			log.setDevicename(device.getDeviceName());
			log.setDeviceid(device.getId());
			log.setUserid(user.getId());

			deviceService.saveUserDevice(log);
		//如果有自己连接上来的
		}else {
		    log.info("此设备序列号已绑定了[{}] ===> ", userdevice.getMacAddres());
			throw new IllegalArgumentException("此设备序列号已绑定了");
		}
	}

	//自己连接上来的设备

	/**
	 *  批量导入设备
	 * @param file
	 * @param
	 * @return
	 */
   /* @PreAuthorize("hasAuthority('device:save')")*/
	@RequestMapping(value = "/batchInsert", method = RequestMethod.POST)
	public Map<String, Object> batchInsert(MultipartFile file) {

        log.info("=== ---批量导入设备--- === {}", file);
        Map map = new LinkedHashMap();
        List<Device> list = new ArrayList<>();
        Map resultMap = new LinkedHashMap();
        List resultList = new ArrayList();
        if (file == null) {
            map.put("code", "1111");
            map.put("msg", "文件不能为空");
            log.info("批量导入的Excel文件不能为空，{}", file);
            return map;
        }
        AppUser appUser = AppUserUtil.getLoginAppUser();
        appUser = userClient.getLoginAppUserAnon(appUser.getId());
        Long companysId = appUser.getCompanysId()== null ? appUser.getUserCompanysId() : appUser.getCompanysId();//如果为空就是小区
        Long userId = appUser.getId();
        Workbook workbook = null;
        CommonsMultipartFile cmf = null;

        try {
            boolean isExcel2003 = true;
            cmf = (CommonsMultipartFile) file;
            DiskFileItem dfi = (DiskFileItem) cmf.getFileItem();

            String fileName = dfi.getName();
             if (!fileName.matches("^.+\\.(?i)(xls)$") && !fileName.matches("^.+\\.(?i)(xlsx)$")) {
                map.put("code", "1111");
                map.put("msg", "上传文件格式不正确");
                log.info("=== 上传文件格式不正确 ===");
                return map;
            }

            if (fileName.matches("^.+\\.(?i)(xlsx)$")) {
                isExcel2003 = false;
            }

            if (isExcel2003) {
                workbook = new HSSFWorkbook(dfi.getInputStream()); // dfi.getInputStream()
            }else {
                workbook = new XSSFWorkbook(dfi.getInputStream()); // FileUtils.openInputStream(fo)
            }
            //获取第一个工作表
            Sheet sheet = workbook.getSheetAt(0);

            //获取sheet中第一行行号
            int firstRowNum = sheet.getFirstRowNum();
            //获取sheet中最后一行行号

            int lastRowNum = sheet.getLastRowNum();
            if (lastRowNum > 1000) {
                map.put("code", "1111");
                map.put("msg", "最多上传1000行");
                log.info("=== 最多上传1000行 ===");
                return map;
            }

            //循环插入数据
            for(int j = 1; j <= lastRowNum; j++) {
                Device device = new Device();
                Row row = sheet.getRow(j);
                String deviceName = row.getCell(0).getStringCellValue().trim(); // 获取设备名称

                String macAddress = row.getCell(1).getStringCellValue().trim(); //获取设备号

                if (StringUtils.isEmpty(deviceName)) {
                    device.setDeviceName("A1单目闸机式");
                }else {
                    device.setDeviceName(deviceName);
                }

                 // 设备号为空，
                 // a、16位数字类型判断
                 // b、跟数据库是否重复判断
                if (StringUtils.isEmpty(macAddress)) {
                    ResultData resultData = new ResultData();
                    resultData.setDeviceName(deviceName);
                    resultData.setMacAddres(macAddress);
                    resultData.setMsg("SN设备号为空");

                    resultList.add(resultData);
//                    resultMap.put(i, resultData);
                    log.info("SN设备号为空[{}], [{}]", deviceName, macAddress);
                    continue;

                    // 设备号不为空时
                    // a、16位数字类型判断
                    // b、跟数据库是否重复判断
                }else {
                    if (macAddress.length() != 16 || !isNumeric(macAddress)) {
                        ResultData resultData = new ResultData();
                        resultData.setDeviceName(deviceName);
                        resultData.setMacAddres(macAddress);
                        resultData.setMsg("SN设备号必须是16位长度数字类型");
                        resultList.add(resultData);

//                        resultMap.put(i, resultData);
                        log.info("SN设备号必须是16位数字类型，{}", macAddress);
                        continue;
                    }

                    device.setUserId(appUser.getId());
                    device.setMacAddres(macAddress);// 通过MacAddress去查现有的设备号
                    Device resultDevice = deviceService.findByUserSno(device);
                    if (resultDevice != null) {
                        ResultData resultData = new ResultData();
                        resultData.setDeviceName(deviceName);
                        resultData.setMacAddres(macAddress);
                        resultData.setMsg("跟现有SN设备号重复");
                        resultList.add(resultData);

                        log.info("跟现有SN设备号重复，{}", macAddress);
                        continue;
                    }
                    // 加入到List中做批量添加
                    device.setCompanyid(companysId);
                    device.setUserId(userId);
                    list.add(device);
                }
            } // 循环结束

            // SN设备号重复 ==== Excel中，填写的设备号存在重复
            List<String> macAddressList = new ArrayList<>();
            List<Device> deviceList = list.stream().filter(v -> {
                boolean flag = macAddressList.contains(v.getMacAddres());
                if (!flag) {
                    macAddressList.add(v.getMacAddres());
                }
                return flag;
            }).collect(Collectors.toList());

            // Excel 中的重复设备号
            List excelList = new ArrayList();
            if (deviceList.size() > 0) {
                for (Device env : deviceList) {
                    ResultData resultData = new ResultData();
                    resultData.setDeviceName(env.getDeviceName());
                    resultData.setMacAddres(env.getMacAddres());
                    resultData.setMsg("SN设备号重复");
                    excelList.add(resultData);// 打印日志， 导入Excel中的重复数据
                    resultList.add(resultData);
                }
                log.info("Excel 中的重复设备号 {}", excelList);
            }

            // 返回Excel中存在的重复设备号macAddress
            if (resultList.size() > 0) {
                map.put("code", "1111");
                map.put("data", resultList);
                return  map;
            }

            deviceService.batchInsert(list);


            map.put("code", "0000");
            map.put("msg", "SUCCESS");
            return map;

            } catch (Exception e) {
            log.error("Exception [{}]", e);
        }finally {
            try {
                if (workbook != null) {
                    workbook.close();
                }

            } catch (IOException e) {
                log.error("Exception [{}]", e);
            }
        }
        return null;
	}


    public static void main(String[] args) {


	    String str = "777777a789012345啊6";
	    String str2 = "7777777890123456";
	    String str3 = "8888888890123456    ";



	    boolean flag2 = org.apache.commons.lang3.StringUtils.isNumeric(str2);
	    boolean flag3 = org.apache.commons.lang3.StringUtils.isNumeric(str3.trim());
        boolean k = new UserDeviceController().isNumeric(str3.trim());

        System.out.println( flag2);
        System.out.println(flag3);
        System.out.println(k);


       /* List<String> list = new ArrayList();
        list.add("dfd");
        list.add("汉兰达");
        list.add("23");
        list.add("23");
        list.add("23");
        list.add("23");
        list.add("  123  ");




        List resultList = new ArrayList();
        for ( String string : list) {
            if (StringUtils.isEmpty(string)) {
                resultList.add(string);
                continue;
            }
            if (string.length() == 2) {
                resultList.add(string);
                continue;
            }
        }


        List<ResultData> list1 = new ArrayList<>();
        List<String> list2 = new ArrayList<>();

        ResultData resultData = new ResultData("A1单目闸机", "11", "SN设备为空");
        ResultData resultData1 = new ResultData("A1单目闸机", "22", "SN设备号必须是16位数字类型");
        ResultData resultData2 = new ResultData("A1单目闸机", "33", "SN设备重复");
        ResultData resultData3 = new ResultData("A1单目闸机", "11", "SN设备为空");
        ResultData resultData4 = new ResultData("A1单目闸机", "11", "SN设备为空");
        list1.add(resultData);
        list1.add(resultData1);
        list1.add(resultData2);
        list1.add(resultData3);
        list1.add(resultData4);

        List<ResultData> resultList1 = list1.stream().filter(
                v -> {
                    boolean flag = list2.contains(v.getMacAddres());
                    if (!flag) {
                        list2.add(v.getMacAddres());

                    }
                    return flag;
                }
        ).collect(Collectors.toList());

        System.out.println(resultList1);
        System.out.println(list2);*/


        /*
         Map map = new LinkedHashMap();
        Map dataMap = new LinkedHashMap();
        map.put("code", "1111");
        dataMap.put("1", resultData);
        dataMap.put("2", resultData1);
        dataMap.put("3", resultData2);
        map.put("data", dataMap);

        String result = JSONArray.toJSONString(map);
        System.out.println(result);*/

    }




/*    private boolean isNumberic(String str) {
	    for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }

        return true;
    }*/

    private boolean isNumeric(String str){
        Pattern pattern = Pattern.compile("[0-9]*");
        Matcher isNum = pattern.matcher(str);
        if( !isNum.matches() ){
            return false;
        }
        return true;
    }

    //方法四：
    /*public final static boolean isNumeric(String s) {
        if (s != null && !"".equals(s.trim()))
            return s.matches("^[0-9]*$");
        else
            return false;
    }
*/
    //方法五：用ascii码
    public static boolean isNumeric2(String str){
        for(int i=str.length();--i>=0;){
            int chr=str.charAt(i);
            if(chr<48 || chr>57)
                return false;
        }
        return true;
    }


    /**
     * 根据id删除离线状态的设备
     * @param id
     * @return
     */
    /*@PreAuthorize("hasAuthority('device:delete')")*/
    @RequestMapping(value = "/deleteById", method = RequestMethod.GET)
    public Map<String, Object> deleteById(@RequestParam Integer id) {
        log.info("根据id删除设备[{}]", id);
        Map<String, Object> resultMap = new LinkedHashMap();
        if (id == null) {
	        resultMap.put("code", "1111");
	        resultMap.put("id", "id不允许为空");
	        return resultMap;
        }

        boolean flag = deviceService.deleteById(id);
        if (flag) {
            resultMap.put("code", "0000");
            resultMap.put("msg", "success");
            return resultMap;
        }else {
            resultMap.put("code", "1111");
            resultMap.put("msg", "failed");
            return resultMap;
        }

    }





    //自己连接上来的设备
		@PostMapping("/userdevice-anon/updatedeviceconfig/{sno}")
		public Map<String, Object> updateDeviceStatus(@PathVariable String sno) {
			DeviceConfigEntity deviceConfig=	deviceConfigService.queryObject(sno);
			if(deviceConfig==null) {
				deviceConfig=new DeviceConfigEntity();
				deviceConfig.setDeviceId(sno);
				deviceConfig.setThresholdn(0.75f);
				deviceConfig.setThreshold1(0.75f);
				deviceConfig.setWorkstatus(1);
				deviceConfig.setCompanystatus(1);
				deviceConfig.setDelaytime(4);
				deviceConfig.setThresholdnn(0.75f);
				deviceConfig.setVoiceinterval(3000);
				deviceConfigService.save(deviceConfig);
			}
			deviceConfig.setWorkstatus(3);
			deviceConfigService.update(deviceConfig);
			Map<String,Object> dataInfo=new  HashMap<>();
			dataInfo.put("code", "1");
			dataInfo.put("description", "成功");
			return dataInfo;
		}
	//自己连接上来的设备
	@GetMapping("/userdevice-anon/savedevice/{macAddres}")
	 @LogAnnotation(module ="自连设备")
	public String saveanon(@PathVariable String macAddres,String password) {
		Device device=new Device();
		//相机自己连接上来的
		device.setUserId(0l);
		device.setMacAddres(macAddres);
		device.setSno(macAddres);
		device.setDeviceName("自连设备");
		password=password==null?"":password.replace(" ", "+");
		String returnString="成功";
		//如果已经连接一次或者用户自己创建了 就不用创建了
		password=RSAUtils.decryptDataOnJava(password, PRIVATEKEY);
		 if("xyz471939146!@".equals(password)) {
			 Device userdevice=deviceService.findByUserSno(device);
			if(userdevice==null) {
				userDeviceDao.saveDevice(device);
				Long deviceId=device.getId().longValue();
				String databaseName="cloud_devicelog"+(deviceId/2000)+"";
				String tableName="t_device_image_"+(deviceId%2000);
			    	Map<String, String> sql=new HashMap<>();
					sql.put("databaseName", databaseName);
					sql.put("tableName", tableName);
					userDeviceDao.createdatabasetable(sql);


				UserDevice log=new UserDevice();
				log.setDevicename("自己连接");
				log.setDeviceid(deviceId);
				log.setUserid(0l);
				deviceService.saveUserDevice(log);
			}
		 }else {
			 returnString="你大爷没有秘钥都想访问";
		 }
		return returnString;
	}

	/**
	 * 设备查询
	 *
	 * @param params
	 * @return
	 */
	@Autowired
	UserClient userClient;

	@PreAuthorize("hasAuthority('device:query')")
	@GetMapping("/devices")
	public Page<Device> findDevices(@RequestParam Map<String, Object> params) {
		AppUser user = AppUserUtil.getLoginAppUser();
		params.put("userId", user.getId());
		Page<Device> result= deviceService.findDevices(params);
		return result;
	}
	@Value("${file.local.path}")
	private  String basepath;
	@Value("${file.local.picServerUrl}")
	private  String picServerUrl;
	@Value("${file.local.url}")
	private  String baseurl;

	//app升级登录
		@PostMapping("/userdevice-anon/apkLogin")
		public Map<String,String> apkLogin(String data,String ver) throws Exception {
			ApkLogin deviceUserInoData=(ApkLogin)com.alibaba.fastjson.JSONObject.parseObject(AESUtils.Decrypt(data, Encryption.encryptionMap.get(ver)), ApkLogin.class);
			Device result= userDeviceDao.findBySno(deviceUserInoData.getDeviceId());
			if(result==null) {
				Map<String,String> returnMap=new HashMap<>();
				Map<String,Object> dataInfo=new  HashMap<>();
				dataInfo.put("code", "1");
				dataInfo.put("description", "没有设备号");
				dataInfo.put("updateUrl", null);
				String jsonString = JSON.toJSONString(dataInfo);
				returnMap.put("data", AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
				return returnMap;
			}
			Map<String,String> returnMap=new HashMap<>();
			Map<String,Object> dataInfo=new  HashMap<>();
			dataInfo.put("code", "0");
			dataInfo.put("description", "成功");
			ApkLoginUrl url=new ApkLoginUrl();
			url.setUpdateUrl(baseurl);
			dataInfo.put("result", url);
			String jsonString = JSON.toJSONString(dataInfo);
			returnMap.put("data", AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
			return returnMap;
		}
		  @Autowired
		    private DeviceConfigService deviceConfigService;
		  @Autowired
		    SmsClient smsClient;
    @PostMapping("/userdevice-anon/updatePas")
    public Map<String, Object> updatePas(String data,String ver) throws Exception {

    	Map<String,Object> adminPhoneMap=(Map<String,Object>)com.alibaba.fastjson.JSONObject.parseObject(AESUtils.Decrypt(data, Encryption.encryptionMap.get(ver)), Map.class);
    	String adminPhone=adminPhoneMap.get("adminPhone").toString(); String key=adminPhoneMap.get("key").toString(); String code=adminPhoneMap.get("verCode").toString();

    	 String deviceId=adminPhoneMap.get("deviceId").toString();
    	 String password=adminPhoneMap.get("password").toString();

    	Device device=userDeviceDao.findBySno(deviceId);

    	String phone=smsClient.matcheCodeAndGetPhone(key, code, true, 5*60);
    	  Map<String,Object> returnMap=new HashMap<>();
  		Map<String,Object> dataInfo=new  HashMap<>();

        if(adminPhone.equals(phone+"")) {
        	dataInfo.put("code", "0");
    		dataInfo.put("description", "成功");
    		device.setPassword(password);//设备密码
    		userDeviceDao.updatePassword(device);//修改密码
        }else {
        	dataInfo.put("code", "500");
    		dataInfo.put("description", "验证码错误");

        }

        String jsonString = JSON.toJSONString(dataInfo);
		returnMap.put("data", AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
		return returnMap;
    }

    @Autowired
    SysDoorDeptDao sysDoorDeptDao;

    @Autowired
    SysDoorUserDao sysDoorUserSDao;
    @PostMapping("/userdevice-anon/tokenRefresh")
	public Map<String,String> tokenRefresh(String data,String ver) throws Exception {
    	Map<String,String> returnMap=new HashMap<>();
		Map<String,Object> dataInfo=new  HashMap<>();


		dataInfo.put("code", "0");
		dataInfo.put("description", "成功");
        String token  = JWTService.createJWT();

      	Map<String,Object> result=new  HashMap<>();
		result.put("refreshTokenTime", 30);//tonken 时效
		result.put("token", token);
		dataInfo.put("result", result);

		String jsonString = JSON.toJSONString(dataInfo);
		System.err.println(jsonString);
		returnMap.put("data", AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
		return returnMap;
    }
	//设备登录
	@PostMapping("/userdevice-anon/deviceLogin")
	public Map<String,String> deviceLogin(String data,String ver) throws Exception {
		DeviceLoginParams deviceUserInoData=(DeviceLoginParams)com.alibaba.fastjson.JSONObject.parseObject(AESUtils.Decrypt(data, Encryption.encryptionMap.get(ver)), DeviceLoginParams.class);
		DeviceLoginVo result= userDeviceDao.deviceLogin(deviceUserInoData.getDeviceId());
		if(result==null) {
			Map<String,String> returnMap=new HashMap<>();
			Map<String,Object> dataInfo=new  HashMap<>();
			dataInfo.put("code", "1");
			dataInfo.put("description", "设备号没有绑定公司");
			dataInfo.put("result", result);
			String jsonString = JSON.toJSONString(dataInfo);
			returnMap.put("data", AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
			return returnMap;
		}
		Device device=userDeviceDao.findBySno(deviceUserInoData.getDeviceId());

		AppUser appUser=userClient.getLoginAppUserAnon(device.getUserId());
		device.setDoorId(Long.valueOf(deviceUserInoData.getDoorId()));

		String description="成功";
		String code="0";
		DeviceConfigEntity configEntity=deviceConfigService.queryObject(deviceUserInoData.getDeviceId());
		if(configEntity!=null) {
			if(configEntity.getWorkstatus().intValue()==2) {
				description="设备暂停";
				code="500";
			}else if(configEntity.getWorkstatus().intValue()==3) {
				description="设备注销";
				code="500";
			}else if(configEntity.getCompanystatus().intValue()==2) {
				description="公司暂停";
				code="500";
			}
		}
		//切换大门
		if(Long.valueOf(deviceUserInoData.getDoorId())!=device.getDoorId()) {
			List<SysDoorDeptEntity> doorDeptList= sysDoorDeptDao.queryListDoorDept(Long.valueOf(deviceUserInoData.getDoorId()).intValue());
			Integer fdeptNos[]=new Integer[doorDeptList.size()];
			if(doorDeptList.size()==0) {
				fdeptNos=new Integer[1];
				fdeptNos[0]=-1;
			}
			int count=0;
			for (SysDoorDeptEntity sysDoorDeptEntity : doorDeptList) {
				fdeptNos[count]=sysDoorDeptEntity.getFdeptno();
				count++;
			}

			Map<String, Object> queryUserByDept=new HashMap<>();
			queryUserByDept.put("funionNo", appUser.getCompanysId());
			queryUserByDept.put("fdeptNos", fdeptNos);
			List<Long> userList=sysDoorDeptDao.findBasicUserList(queryUserByDept);

			for (Long fuserId : userList) {
				sysDoorUserSDao.updateUserDateTime(Long.valueOf(fuserId));
			}
		}

		device.setPassword(deviceUserInoData.getPassword());//设备密码
		device.setWifiMac(deviceUserInoData.getWifiMac());
		userDeviceDao.updatePassword(device);//修改密码
		device.setAlgorithmSupplier(deviceUserInoData.getAlgorithmSupplier());
		device.setAlgorithmVersion(deviceUserInoData.getAlgorithmVersion());
		deviceService.update(device);//绑定大门
		result.setTcpHost(basepath);//tcp地址
		result.setTcpPort(7890);//tcp端口
		result.setCompanyLogo(result.getCompanyLogo());//公司logo
		result.setPicServerUrl(picServerUrl);
		result.setServerApkVer("");
		result.setAdminPhone(appUser.getPhone());
		result.setUpdateUrl(baseurl);//app升级地址

		String token  = JWTService.createJWT();

		result.setToken(token);

		Map<String,String> returnMap=new HashMap<>();
		Map<String,Object> dataInfo=new  HashMap<>();
		dataInfo.put("code", code);
		dataInfo.put("description", description);
		dataInfo.put("result", result);
		String jsonString = JSON.toJSONString(dataInfo);
		returnMap.put("data", AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
		return returnMap;
	}

	@Autowired
    private DeviceDoorDao deviceDoorDao;
	//获取大门信息
	@PostMapping("/userdevice-anon/doorList")
	public Map<String,String> deviceDoorLogin(String data,String ver) throws Exception {
		DeviceLoginParams deviceUserInoData=(DeviceLoginParams)com.alibaba.fastjson.JSONObject.parseObject(AESUtils.Decrypt(data, Encryption.encryptionMap.get(ver)), DeviceLoginParams.class);
		Device result= userDeviceDao.findBySno(deviceUserInoData.getDeviceId());
		if(result==null) {
			Map<String,String> returnMap=new HashMap<>();
			Map<String,Object> dataInfo=new  HashMap<>();
			dataInfo.put("code", "1");
			dataInfo.put("description", "没有设备号");
			dataInfo.put("result", result);
			String jsonString = JSON.toJSONString(dataInfo);
			returnMap.put("data", AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
			return returnMap;
		}
		Map<String, Object> map=new HashMap<>();
		AppUser appUser=userClient.getLoginAppUserAnon(result.getUserId());
		map.put("companysId", appUser.getCompanysId()==null?appUser.getUserCompanysId():appUser.getCompanysId());
		List<DeviceDoorEntity> doorDeviceList=deviceDoorDao.queryList(map);


		List<Map<String, Object>> doorList=new ArrayList<>();

        for (DeviceDoorEntity deviceDoorEntity : doorDeviceList) {
			Map<String, Object> doorInfo=new HashMap<>();
			doorInfo.put("doorId", deviceDoorEntity.getId());
			doorInfo.put("doorName", deviceDoorEntity.getName());
			doorList.add(doorInfo);
		}

		Map<String,String> returnMap=new HashMap<>();
		Map<String,Object> dataInfo=new  HashMap<>();
		dataInfo.put("code", "0");
		dataInfo.put("description", "成功");
		dataInfo.put("result", doorList);
		String jsonString = JSON.toJSONString(dataInfo);
		System.out.println(jsonString);
		returnMap.put("data",  AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
		return returnMap;
	}


	//获取大门密码信息
	@PostMapping("/userdevice-anon/doorPassWord")
	public Map<String,String> doorPassWord(String data,String ver) throws Exception {
		DeviceLoginParams deviceUserInoData=(DeviceLoginParams)com.alibaba.fastjson.JSONObject.parseObject(AESUtils.Decrypt(data, Encryption.encryptionMap.get(ver)), DeviceLoginParams.class);
		Device result= userDeviceDao.findBySno(deviceUserInoData.getDeviceId());
		if(result==null) {
			Map<String,String> returnMap=new HashMap<>();
			Map<String,Object> dataInfo=new  HashMap<>();
			dataInfo.put("code", "1");
			dataInfo.put("description", "没有设备号");
			dataInfo.put("result", result);
			String jsonString = JSON.toJSONString(dataInfo);
			returnMap.put("data", AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
			return returnMap;
		}
		Map<String,String> returnMap=new HashMap<>();
		Map<String,Object> dataInfo=new  HashMap<>();

		Map<String,Object> dataDoor=new  HashMap<>();
		dataDoor.put("passWord", result.getPassword().trim());

		dataInfo.put("code", "0");
		dataInfo.put("description", "成功");
		dataInfo.put("result", dataDoor);
		String jsonString = JSON.toJSONString(dataInfo);
		System.out.println(jsonString);
		returnMap.put("data",  AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
		return returnMap;
	}


	@GetMapping("/onlinedevices")
	public List<NET_Session_Body> findOnLinDevices(@RequestParam Map<String, Object> params) {

		AppUser user = AppUserUtil.getLoginAppUser();
		user=userClient.getLoginAppUserAnon(user.getId());
		Device device=new Device();
		device.setCompanyid(user.getCompanysId()==null?user.getUserCompanysId():user.getCompanysId());
		List<Device> deviceList=userDeviceDao.findByCompanyDeviceData(device);


		 List<NET_Session_Body> bodyList=null;
		    List<NET_Session_Body> linkSnoList=null;
		Set<String> set = template.keys("*_LINK");
		Iterator<String> it1 = set.iterator();
		 bodyList=new ArrayList<>();
		while(it1.hasNext()){
			String keyStr = it1.next();
			String sno=keyStr.split("_")[0];
			boolean flag=true;
			for (Device device2 : deviceList) {
				if(device2.getMacAddres().equals(sno)) {
					flag=false;
					break;
				}
			}
			if(flag) {
				continue;
			}
			Gson gson = new Gson();
			try {
		       linkSnoList=gson.fromJson(template.boundValueOps(sno+"_LINK").get(), new TypeToken<List<NET_Session_Body>>() {
	        }.getType());
			}catch (Exception e) {
				linkSnoList=null;
			}
			if(linkSnoList==null) {
				linkSnoList=new ArrayList<>();
			}


			for (NET_Session_Body net_Session_Body : linkSnoList) {

				if(sno.equals(net_Session_Body.getSno())&&(template.boundValueOps(sno+"_"+net_Session_Body.getSessionId()).get()==null)) {//过滤掉以前的sessionID

				}else {
					bodyList.add(net_Session_Body);
				}
			}
		}
		return bodyList;
	}

	@GetMapping("/onlinedevices/{companId}")
	public List<NET_Session_Body> findOnLinDevicesByCompanId(@PathVariable Long companId) {
		Device device=new Device();
		device.setCompanyid(companId);
		List<Device> deviceList=userDeviceDao.findByCompanyDeviceData(device);

		 List<NET_Session_Body> bodyList=null;
		    List<NET_Session_Body> linkSnoList=null;
		Set<String> set = template.keys("*_LINK");
		Iterator<String> it1 = set.iterator();
		 bodyList=new ArrayList<>();
		while(it1.hasNext()){
			String keyStr = it1.next();
			String sno=keyStr.split("_")[0];
			boolean flag=true;
			for (Device device2 : deviceList) {
				if(device2.getMacAddres().equals(sno)) {
					flag=false;
					break;
				}
			}
			if(flag) {
				continue;
			}
			Gson gson = new Gson();
			try {
		       linkSnoList=gson.fromJson(template.boundValueOps(sno+"_LINK").get(), new TypeToken<List<NET_Session_Body>>() {
	        }.getType());
			}catch (Exception e) {
				linkSnoList=null;
			}
			if(linkSnoList==null) {
				linkSnoList=new ArrayList<>();
			}


			for (NET_Session_Body net_Session_Body : linkSnoList) {

				if(sno.equals(net_Session_Body.getSno())&&(template.boundValueOps(sno+"_"+net_Session_Body.getSessionId()).get()==null)) {//过滤掉以前的sessionID

				}else {
					bodyList.add(net_Session_Body);
				}
			}
		}
		return bodyList;
	}
	@PreAuthorize("hasAuthority('device:query')")
	@GetMapping("/devicelist")
	public List<Device> findDeviceList(String searcherName) {
		AppUser user = AppUserUtil.getLoginAppUser();

			Device device=new Device();
			device.setSearcherName(searcherName);
		Set<SysRole> roleSet=userClient.findByUserId(user.getId());
		Iterator<SysRole> it = roleSet.iterator();
		boolean roleFlag=true;
		while(it.hasNext()){
		  String code=((SysRole)it.next()).getCode();
		  if(ExternalRoleInfo.externalRole.containsKey(code)) {//普通用户角色
			  roleFlag=false;
		  }
		}
		//如果是手机注册用户需要按userId过滤设备
		if(!roleFlag) {
			device.setUserId(user.getId());
		}else {//芊熠管理员
			device.setUserId(0l);
		}


		return deviceService.findByDeviceData(device);
	}




	@RequestMapping(value="/userdevice-anon/getDeviceIdBySno", method={RequestMethod.POST, RequestMethod.GET},params="macAddres")
	public Device findBySno(@RequestParam("macAddres") String macAddres) {
		return deviceService.findBySno(macAddres);
	}
	@Autowired
	private StringRedisTemplate template;
	@PreAuthorize("hasAuthority('device:control')")
	@GetMapping("/devicecontrol/{sno}")
	public List<NET_Session_Body> devicecontrol(@PathVariable String sno) {//点击设备进行设备控制的时候判断设备是否在线 或者冲突了
		Gson gson = new Gson();
		List<NET_Session_Body> linkSnoList=gson.fromJson(template.boundValueOps(sno+"_"+RedisConst.HEADER_KEY_LINK_KEY).get(), new TypeToken<List<NET_Session_Body>>() {
        }.getType());
		if(linkSnoList==null) {
			linkSnoList=new ArrayList<>();
		}
		List<NET_Session_Body> returnSnoList=new ArrayList<>();
		for (NET_Session_Body net_Session_Body : linkSnoList) {
			String status=template.boundValueOps(sno+"_"+net_Session_Body.getSessionId()).get();
			if(status==null||"".equals(status)) {
				net_Session_Body.setStatus(false);
			}else {
				returnSnoList.add(net_Session_Body);
			}
		}
		return returnSnoList;

	}




	/**
	 * 根据设备id查询
	 *
	 * @param params
	 *
	 * @param
	 * @return
	 */
	  @PreAuthorize("hasAuthority('device:query')")
	    @GetMapping("/devices/{id}")
	    public Device findDeviceById(@PathVariable Long id) {
		  Device device=new Device();
		  AppUser user = AppUserUtil.getLoginAppUser();
				user.setId(user.getId());

		  device.setId(id);
		  device.setUserId(user.getId());
	        return deviceService.findById(id);
	    }
	//编辑设备
	  @LogAnnotation(module ="编辑设备")
		@PreAuthorize("hasAuthority('device:update')")
		@PostMapping("/updatedevice")
		public void update(@RequestBody Device device) {
				deviceService.update(device);

				UserDevice log=new UserDevice();
				log.setDevicename(device.getDeviceName());
				log.setDeviceid(device.getId());
				AppUser user = AppUserUtil.getLoginAppUser();
			    log.setUserid(user.getId());
			    log.setDoorId(device.getDoorId());
				deviceService.updateUserDevice(log);

		}
	  @PreAuthorize("hasAuthority('device:control')")
			@PostMapping("/deviceOperLog")
			public void deviceOperLog(@RequestBody  DeviceOperLog DeviceOperLog) {
				 AppUser user = AppUserUtil.getLoginAppUser();
				 String val=DeviceOperLog.getVal();
				 String params1=DeviceOperLog.getParams();
				 String type=DeviceOperLog.getType().equals("0")?"设置":"查询";
				 Integer operFlag=val.contains("a")?10:Integer.valueOf(val.substring(val.length()-3, val.length()));
				 val=val.substring(val.length()-1, val.length());
				 String ylparams= DeviceOperLog.getYlparams();
				 if(operFlag<100) {
					 if("3".equals(val)) {
						 saveLoginLog(user.getUsername(), type+"时间",params1,ylparams);
					 }

					 if("7".equals(val)) {
						 saveLoginLog(user.getUsername(), type+"识别区",params1,ylparams);
					 }
					 if("6".equals(val)) {
						 saveLoginLog(user.getUsername(), type+"智能分析",params1,ylparams);
					 }
					 if("5".equals(val)) {
						 saveLoginLog(user.getUsername(), type+"检测方式",params1,ylparams);
					 }
					 if("a".equals(val)) {
						 saveLoginLog(user.getUsername(), type+"智能开关",params1,ylparams);
					 }

					 if("9".equals(val)) {
						 saveLoginLog(user.getUsername(), "平台用户登录相机","我登录的时候相机的 配置是:"+params1,ylparams);
					 }
					 if("8".equals(val)) {
						 saveLoginLog(user.getUsername(), "查询版本",params1,ylparams);
					 }
					 if("4".equals(val)) {
						 saveLoginLog(user.getUsername(), type+"网络",params1,ylparams);
					 }
				 }else if(operFlag>100&&operFlag<200) {
					 if("1".equals(val)) {
						 saveLoginLog(user.getUsername(), "强制抓拍",params1,"");
					 }

				 }else if(operFlag>200&&operFlag<300) {
					 if("1".equals(val)) {
						 saveLoginLog(user.getUsername(), "开始视频",params1,"");
					 }else {
						 saveLoginLog(user.getUsername(), "停止视频",params1,"");
					 }

				 }else if(operFlag>300&&operFlag<400) {
					 if("1".equals(val)) {
						 saveLoginLog(user.getUsername(), "下载音频数据",params1,"");
					 }
					 if("2".equals(val)) {
						 saveLoginLog(user.getUsername(), "开始语音",params1,"");
					 }
					 if("3".equals(val)) {
						 saveLoginLog(user.getUsername(), "停止语音",params1,"");
					 }

				 }else if(operFlag>400&&operFlag<500) {

						 saveLoginLog(user.getUsername(), "获取日志",params1,"");

				 }else {
					 saveLoginLog(user.getUsername(), "升级版本",params1,"");
				 }


			}
	  @Autowired
	    private LogClient logClient;
	    /**
	     * 登陆日志
	     *
	     * @param username
	     */
	    private void saveLoginLog(String username, String modelName,String params,String ylparams) {
	    	if(!modelName.contains("查询")) {


	        // 异步
	        CompletableFuture.runAsync(() -> {
	            try {
	                Log log = Log.builder().username(username).module(modelName).remark(ylparams).createTime(new Date())
	                        .build();
	                log.setModule(modelName);
	                log.setParams(params);
	                logClient.save(log);
	            } catch (Exception e) {
	                // do nothing
	            }

	        });
	    	}
	    }
}
