package com.cloud.userdevice.controller;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.cloud.common.utils.AppUserUtil;
import com.cloud.model.device.Device;
import com.cloud.model.device.NET_Session_Body;
import com.cloud.model.log.LogAnnotation;
import com.cloud.model.user.AppUser;
import com.cloud.userdevice.dao.UserDeviceDao;
import com.cloud.userdevice.feign.UserClient;
import com.cloud.userdevice.model.DeviceConfigEntity;
import com.cloud.userdevice.service.impl.DeviceConfigService;
import com.cloud.userdevice.utils.SocketClient;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.suke.czx.common.utils.PageUtils;
import com.suke.czx.common.utils.Query;
import com.suke.czx.common.utils.R;




/**
 * 设备配置表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-16 09:21:49
 */
@RestController
@RequestMapping("/deviceconfig")
public class DeviceConfigController {  
    @Autowired
    private DeviceConfigService deviceConfigService;
    @Autowired
    private UserDeviceDao userDeviceDao;

    /**
     * 列表
     */
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params){
        //查询列表数据
        Query query = new Query(params);

        List<DeviceConfigEntity> deviceConfigList = deviceConfigService.queryList(query);
        int total = deviceConfigService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(deviceConfigList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }


    /**
     * 信息
     */
    
    @GetMapping("/userdevice-anon/info/{macAddres}")
    @LogAnnotation(module ="自连设备")
	public DeviceConfigEntity saveanon(@PathVariable String macAddres) {
    	DeviceConfigEntity deviceConfig = new DeviceConfigEntity();
    	Device device=userDeviceDao.findBySno(macAddres);
    	Integer workmode=0;
    	if(device.getCompanytype().intValue()==3) {
    		workmode=2;  
    	}
    	deviceConfig.setWorkmode(workmode);
    	deviceConfig.setAuthority("1,2,10");
    	deviceConfig.setModename("门禁");
    	return deviceConfig;
    }
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") String id){
			DeviceConfigEntity deviceConfig = deviceConfigService.queryObject(id);
             if(deviceConfig==null) {
            	 deviceConfig=new DeviceConfigEntity();
             }
        return R.ok().put("deviceConfig", deviceConfig);
    }

    /**
     * 保存
     */
    @Autowired
	private UserClient userClient;
    @RequestMapping("/save")
    public R save(@RequestBody DeviceConfigEntity deviceConfig) throws URISyntaxException, Exception{
			deviceConfigService.save(deviceConfig);
			Map<String, Object> sendMessageMap=new HashMap<>();
			sendMessageMap.put("workstatus", deviceConfig.getWorkstatus());
			//sendMessageMap.put("companyId", appUser.getCompanysId());
			//sendMessageMap.put("companystatus", deviceConfig.getCompanystatus());
			sendMessageMap.put("voiceinterval", deviceConfig.getVoiceinterval());
			sendMessageMap.put("threshold1", deviceConfig.getThreshold1());
			sendMessageMap.put("thresholdn", deviceConfig.getThresholdn());
			sendMessageMap.put("thresholdnn", deviceConfig.getThresholdnn());
			sendMessageMap.put("delaytime", deviceConfig.getDelaytime());
			sendMessageMap.put("startTime", "00:00");
			sendMessageMap.put("endTime", "23:59");
			sendMessageMap.put("devRebootTime", deviceConfig.getDevRebootTime());
			sendMessageMap.put("weeks", "0,1,2,3,4,5,6");
			sendMessageMap.put("livingSwitch", deviceConfig.getLivingSwitch());
			sendMessageDevice(deviceConfig.getDeviceId(), JSONObject.toJSONString(sendMessageMap));
        return R.ok();
    }
    @Autowired
 	private StringRedisTemplate template;
    private void sendMessageDevice(String deviceId,String sendMessage) throws URISyntaxException, Exception {
  
	    List<NET_Session_Body> bodyList=new ArrayList<>();
	   
	    List<NET_Session_Body> linkSnoList=null;
		Set<String> set = template.keys("*_LINK");
		Iterator<String> it1 = set.iterator();
		 
		while(it1.hasNext()){
			String keyStr = it1.next();
			String sno=keyStr.split("_")[0];
			if(!deviceId.equals(sno)) {
				continue;
			}
	
		
			Gson gson = new Gson();
			try {
		       linkSnoList=gson.fromJson(template.boundValueOps(sno+"_LINK").get(), new TypeToken<List<NET_Session_Body>>() {
	        }.getType()); 
			}catch (Exception e) {
				linkSnoList=null;
			}
			if(linkSnoList==null) {
				linkSnoList=new ArrayList<>();
			}

			
			for (NET_Session_Body net_Session_Body : linkSnoList) {
				
				if(sno.equals(net_Session_Body.getSno())&&(template.boundValueOps(sno+"_"+net_Session_Body.getSessionId()).get()==null)) {//过滤掉以前的sessionID
					template.delete(sno+"_"+net_Session_Body.getSessionId());
				}else {
					bodyList.add(net_Session_Body);
				}
			}
		}
		
		 for (NET_Session_Body net_Session_Body : bodyList) {
			SocketClient.sendUserDeviceConfigInfo("http://127.0.0.1:8090",net_Session_Body.getSno(), net_Session_Body.getSessionId(), net_Session_Body.getServerip(), net_Session_Body.getServerport(),sendMessage);
		}
	}
    /**
     * 修改
     * @throws Exception 
     * @throws URISyntaxException 
     */
    @RequestMapping("/update")
    public R update(@RequestBody DeviceConfigEntity deviceConfig) throws URISyntaxException, Exception{
			deviceConfigService.update(deviceConfig);
			Map<String, Object> sendMessageMap=new HashMap<>();
			sendMessageMap.put("workstatus", deviceConfig.getWorkstatus());
			//sendMessageMap.put("companyId", appUser.getCompanysId());
			//sendMessageMap.put("companystatus", deviceConfig.getCompanystatus());
			sendMessageMap.put("voiceinterval", deviceConfig.getVoiceinterval());
			sendMessageMap.put("threshold1", deviceConfig.getThreshold1());
			sendMessageMap.put("thresholdn", deviceConfig.getThresholdn());
			sendMessageMap.put("thresholdnn", deviceConfig.getThresholdnn());
			sendMessageMap.put("delaytime", deviceConfig.getDelaytime());
			sendMessageMap.put("startTime", "00:00");
			sendMessageMap.put("endTime", "23:59");
			sendMessageMap.put("devRebootTime", deviceConfig.getDevRebootTime());
			sendMessageMap.put("weeks", "0,1,2,3,4,5,6");
			sendMessageMap.put("livingSwitch", deviceConfig.getLivingSwitch());
			sendMessageDevice(deviceConfig.getDeviceId(), JSONObject.toJSONString(sendMessageMap));
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Integer[] ids){
			deviceConfigService.deleteBatch(ids);

        return R.ok();
    }
	
}
