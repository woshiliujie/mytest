package com.cloud.userdevice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.userdevice.dao.SysDoorUserDao;
import com.cloud.userdevice.entity.SysDoorUserEntity;
import com.cloud.userdevice.service.SysDoorUserService;
import com.suke.czx.common.utils.PageUtils;
import com.suke.czx.common.utils.Query;
import com.suke.czx.common.utils.R;




/**
 * 门用户表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-18 09:11:55
 */
@RestController
@RequestMapping("/dooruser/sysdooruser")
public class SysDoorUserController {
    @Autowired
    private SysDoorUserService sysDoorUserService;

    /**
     * 列表
     */
    @RequestMapping("/list")
    public R list(@RequestParam Map<String, Object> params){
        //查询列表数据
        Query query = new Query(params);

        List<SysDoorUserEntity> sysDoorUserList = sysDoorUserService.queryList(query);
        int total = sysDoorUserService.queryTotal(query);

        PageUtils pageUtil = new PageUtils(sysDoorUserList, total, query.getLimit(), query.getPage());

        return R.ok().put("page", pageUtil);
    }
    
    @RequestMapping("/userlist/{doorid}")
    public R userlist(@PathVariable("doorid") Integer doorid  ){
    	Map<String, Object> params=new HashMap<String, Object>();
    	params.put("doorid", doorid);
    	//params.put("userId", userId);
        List<SysDoorUserEntity> sysDoorUserList = sysDoorUserService.queryList(params);
     
        return R.ok().put("page", sysDoorUserList);
    }


    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Integer id){
			SysDoorUserEntity sysDoorUser = sysDoorUserService.queryObject(id);

        return R.ok().put("sysDoorUser", sysDoorUser);
    }

    /**
     * 保存
     */
    @Autowired
    SysDoorUserDao sysDoorUserSDao;
    @RequestMapping("/save/{fuserIds}")
    public R save(@PathVariable("fuserIds") String fuserIds,@RequestBody SysDoorUserEntity sysDoorUser){
    	    String fuserIdsAttr[]=fuserIds.split(",");
    	    for (String fuserId : fuserIdsAttr) {
				String fuserIdAttr[]=fuserId.split("@");
				Integer fuserid=Integer.parseInt(fuserIdAttr[0]);
				Integer flag=Integer.parseInt(fuserIdAttr[1]);
				sysDoorUser.setUserid(fuserid);
				SysDoorUserEntity entityResult=sysDoorUserSDao.queryObjectByuserId(sysDoorUser);
				if(flag.intValue()==1&&entityResult!=null) {
					sysDoorUserService.delete(entityResult.getId());
				}else if(flag.intValue()==0&&entityResult==null) {
					sysDoorUserService.save(sysDoorUser);
					
				}
				sysDoorUserSDao.updateUserDateTime(Long.valueOf(fuserid));
			}
			

        return R.ok();
    }

    /**
     * 修改
     */
    @RequestMapping("/update")
    public R update(@RequestBody SysDoorUserEntity sysDoorUser){
			sysDoorUserService.update(sysDoorUser);

        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Integer[] ids){
	    sysDoorUserService.deleteBatch(ids);

        return R.ok();
    }
	
}
