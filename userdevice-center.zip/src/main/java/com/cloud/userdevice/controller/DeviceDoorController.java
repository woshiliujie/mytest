package com.cloud.userdevice.controller;

import java.io.*;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.cloud.common.constants.Encryption;
import com.cloud.userdevice.dao.DeviceDoorScrollPictureDao;
import com.cloud.userdevice.model.Result;
import com.cloud.userdevice.utils.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.common.utils.AppUserUtil;
import com.cloud.model.common.Page;
import com.cloud.model.device.Device;
import com.cloud.model.device.NET_Session_Body;
import com.cloud.model.user.AppUser;
import com.cloud.userdevice.dao.DeviceDoorDao;
import com.cloud.userdevice.dao.SysDoorDeptDao;
import com.cloud.userdevice.dao.UserDeviceDao;
import com.cloud.userdevice.entity.DeptVO;
import com.cloud.userdevice.entity.DeviceDoorEntity;
import com.cloud.userdevice.entity.SysDoorDeptEntity;
import com.cloud.userdevice.feign.UserClient;
import com.cloud.userdevice.service.DeviceDoorService;
import com.cloud.userdevice.service.SysDoorDeptService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.suke.czx.common.utils.R;
import org.springframework.web.multipart.MultipartFile;


/**
 * 门牌表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-01-17 08:40:44
 */
@RestController
@RequestMapping("/devicedoor")
public class DeviceDoorController {

	private static Logger logger = LoggerFactory.getLogger(DeviceDoorController.class);

    @Autowired
    private DeviceDoorService deviceDoorService;

	@Autowired
 	UserClient userClient;

	@Autowired
	UserDeviceDao userDeviceDao;

	@Autowired
	private DeviceDoorScrollPictureDao deviceDoorScrollPictureDao;

	@Value("${file.local.picServerUrl}")
	private String picServerUrl;
    /**
     * 列表
     */
    @RequestMapping("/list")
    public Page<DeviceDoorEntity> list(@RequestParam Map<String, Object> params){
        //查询列表数据
    	AppUser user = AppUserUtil.getLoginAppUser();
    	user=userClient.getLoginAppUserAnon(user.getId());
      	params.put("companysId", user.getCompanyid());
      	params.put("offset", Integer.valueOf(params.get("start").toString()));
      	params.put("page", 10);
      	params.put("limit", 10);

        List<DeviceDoorEntity> deviceDoorList = deviceDoorService.queryList(params);
        int total = deviceDoorService.queryTotal(params);

        
        Page<DeviceDoorEntity> page=new Page<>(total, deviceDoorList);
        return page;
    }

	@RequestMapping("/scrollPicture/query/{doorId}")
    public Result queryScrollPicture(@PathVariable("doorId")Integer doorId) {
		logger.info("【出入口管理-预览广告轮播图】开始：doorId:{}", StringUtils.isEmpty(doorId+"")?"为空":doorId);
		Result result = new Result();
    	Map<String, Object> map = new HashMap<>();
    	map.put("doorId", doorId);
		map.put("prefix", picServerUrl);
		List<Map<String, String>> list = deviceDoorScrollPictureDao.queryPicUrlByDoorId(map);
		logger.info("【出入口管理-预览广告轮播图】查询结果：doorId:{}, list:{}", doorId, JSON.toJSON(list));
		return result.setCode("0000").setMessage("查询成功").setList(list);
	}


	@RequestMapping("/batchScrollPicture/upload")
	public Result batchScrollPictureUpload(MultipartFile[] file, String doorIds, String[] pictureUrls,
										   Integer[] playTimes, Integer[] animationTypes, Integer[] indexs) throws Exception{

		Result result = new Result();
    	try {
			logger.info("【出入口管理-批量导入广告轮播图】开始：doorIds:{}, fileSize:{}, pictureUrls:{}, playTimes:{}, animationTypes:{}, indexs:{}",
					StringUtils.isEmpty(doorIds)?"为空":doorIds, (file==null||file.length==0)?"空":file.length, pictureUrls, playTimes, animationTypes, indexs);

			if(StringUtils.isEmpty(doorIds)) {
				return result.setCode("0001").setMessage("出入口id不能为空");
			}
			//AppUser user = AppUserUtil.getLoginAppUser();
			List<Map<String, Object>> list = new ArrayList<>();
			List<Map<String, String>> picUrlList = new ArrayList<>();
			for(String doorId : doorIds.split(",")) {
				if(file==null||file.length<=0) {
					break;
				}
				int i = 0;
				for(MultipartFile f : file) {

					String fileName = f.getOriginalFilename();
					String fileType = f.getContentType();
					Integer index = indexs[i++];
					Integer playTime = playTimes[index];
					Integer animation = animationTypes[index];

					String httpRes = HttpUtil.sendImageStoreServer(picServerUrl, FileUtil.readInputStream(f.getInputStream()), fileName);
					logger.info("【出入口管理-批量导入广告轮播图】doorIds：{}， fileName:{}, fileType:{}, 上传结果：{}", doorIds, fileName, fileType, httpRes);
					Map<String, String> m = getPicUrl(httpRes.replaceAll("\n",""));
					if(!("0".equals(m.get("code"))||"ok".equals(m.get("description")))) {
						result.setCode("0001");
						result.setMessage(m.get("description"));
						return result;
					}

					Map map = getBatchMap(doorId, fileName, fileType, playTime, animation, index,m.get("new_file_name"));
					list.add(map);
				}

				Map<String, Object> map = new HashMap<>();
				map.put("doorId", Integer.valueOf(doorId));
				map.put("prefix", picServerUrl);
				List<Map<String, String>> pList = deviceDoorScrollPictureDao.queryPicUrlByDoorId(map);
				picUrlList.addAll(pList);
			}

			//上传之前先删掉之前的图片和数据库记录

			List<Object> urlList = Arrays.asList(pictureUrls);
			Map<String, List<Object>> deleteMap = new HashMap<>();
			deleteMap.put("list", Arrays.asList(NumberUtils.StringToInt(doorIds.split(","))));
			if(pictureUrls!=null&&pictureUrls.length>0) {
				deleteMap.put("pictureUrls", urlList);
			}
			deviceDoorScrollPictureDao.deleteBatchByDoorId(deleteMap);
			for(Map<String, String> map : picUrlList) {
				String fileNewName = map.get("pictureUrl");
				if(!urlList.contains(fileNewName)) {
					try{
						HttpUtil.deleteImageStoreServer(picServerUrl, fileNewName);
					} catch (Exception e) {
						logger.error("【出入口管理-批量导入广告轮播图】删除异常，doorIds：{}，{}", doorIds, e);
					}

				}
			}

			if(list!=null&&list.size()>0) {
				deviceDoorScrollPictureDao.insertBatch(list);
			}
			//修改图片属性
			for(int i=0;i<pictureUrls.length;i++) {
				Map<String, Object> updateMap = new HashMap<>();
				updateMap.put("playTime", playTimes[i]);
				updateMap.put("animation", animationTypes[i]);
				updateMap.put("index", i);
				updateMap.put("pictureUrl", pictureUrls[i]);
				updateMap.put("updateTime", new Date());
				deviceDoorScrollPictureDao.updateBypictureUrl(updateMap);
			}

			sendMessageScrollPicture(doorIds);

			logger.info("【出入口管理-批量导入广告轮播图】成功结束：doorIds:{}", doorIds);
			return result.setCode("0000").setMessage("上传成功");
		} catch (Exception e) {
			logger.error("【出入口管理-批量导入广告轮播图】异常，doorIds：{}，{}", doorIds, e);
			sendMessageScrollPicture(doorIds);
		}
		return result.setCode("0001").setMessage("出问题了");
	}
	private static Object getUpdateTime(Map<String, Object> map) {
		return map.get("updateTime");
	}

	private static long comparingByTime(Object updateTime) {
		return ((Timestamp)updateTime).getTime();

	}

	@RequestMapping("/advertising")
	public Map<String, Object> queryPicUrlByMacAddres(String data, String ver) throws Exception {

		Map<String, Object> returnMap = new HashMap<>();
		Map<String, Object> r = new HashMap<>();

		Map<String, String> map = JSONObject.parseObject(AESUtils.Decrypt(data, Encryption.encryptionMap.get(ver)), Map.class);
		logger.info("【出入口管理-A1拉取广告轮播图】开始，入参:map:{}", map);
		List<Map<String, Object>> list = deviceDoorScrollPictureDao.queryPicUrlByMacAddres(map.get("deviceId"));
		logger.info("【出入口管理-A1拉取广告轮播图】list:{},入参：{}", list==null?"空":JSON.toJSONString(list), map);
		if(list==null||list.size()==0) {
			r.put("code", 100);
			r.put("description", "未查询到此设备广告");
			String jsonString = JSON.toJSONString(r);
			returnMap.put("data",  AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
			return returnMap;
		}
		Object updateTime = list.stream().map(DeviceDoorController::getUpdateTime).sorted(Comparator.comparing(DeviceDoorController::comparingByTime).reversed()).limit(1).findFirst().get();
		Map<String, Object> result = new HashMap<>();
		result.put("bannerStyle", 0);
		result.put("updateTime", ((Timestamp) updateTime).getTime());
		List<Map<String, Object>> data1 = new ArrayList<>();
		for(Map<String, Object> urlMap : list) {
			Map<String, Object> d = new HashMap<>();
			d.put("index", urlMap.get("index"));
			d.put("mediaType", urlMap.get("mediaType"));
			d.put("serverId", urlMap.get("pictureUrl"));
			d.put("fileName", urlMap.get("pictureName"));
			d.put("animation", urlMap.get("animation"));
			d.put("playTime", urlMap.get("playTime"));
			data1.add(d);
		}
		result.put("data", data1);

		r.put("code", 0);
		r.put("description", "OK");
		r.put("result", result);

		String jsonString = JSON.toJSONString(r);
		returnMap.put("data",  AESUtils.Encrypt(jsonString, Encryption.encryptionMap.get(ver)));
		logger.info("【出入口管理-A1拉取广告轮播图】结束，入参：{}, 返回结果：{}", map, jsonString);
    	return returnMap;
	}

	private Map<String, String> getPicUrl(String httpRes) {
		Map<String, String> m = new HashMap<>();
		Map<String, Object> map = JSONObject.parseObject(httpRes, Map.class);
		if("0".equals(map.get("code").toString())) {
			Map<String, Object> data = JSONObject.parseObject(map.get("data").toString(), Map.class);
			m.put("new_file_name", data.get("new_file_name").toString());
		}

		m.put("code", map.get("code").toString());
		m.put("description", map.get("description").toString());
		return m;
	}

	private Map<String, Object> getBatchMap(String doorId, String fileName, String fileType,
											Integer playTime, Integer animation, Integer index, String url) {
		Map<String, Object> map = new HashMap<>();
		map.put("deviceDoorId", Integer.valueOf(doorId));
		map.put("pictureUrl", url);
		map.put("pictureName", fileName);
		map.put("pictureType", fileType);
		map.put("playTime", playTime);
		map.put("animation", animation);
		map.put("index", index);
		map.put("bannerStyle", 0);
		map.put("mediaType", 0);
		map.put("updateTime", new Date());
		map.put("createTime", new Date());
		return map;
	}


	public static void main(String[] args) throws Exception {
    	/*File file = new File("G:\\nv.jpg");
		InputStream input = new FileInputStream(file);
		System.out.println(input.available());
		//String httpRes = HttpUtil.sendImageStoreServer("http://192.168.0.92:19000/picture", "G:\\nv.jpg");

		//String httpRes = HttpUtil.sendImageStoreServer("http://192.168.0.92:19000/picture", input, "nv.jpg");

		String httpRes = HttpUtil.sendImageStoreServer("http://192.168.0.92:19000/picture", FileUtil.readInputStream(input), "nv.jpg");

		System.out.println(httpRes);*/

		/*List<Map<String, String>> list = new ArrayList<>();
		Map<String, String> m = new HashMap<>();
		m.put("pictureUrl", "pictureUrlValue");
		list.add(m);

		Map<String, Object> result = new HashMap<>();
		result.put("animation", 0);
		result.put("playTime", 3000);
		List<Map<String, Object>> data = new ArrayList<>();
		for(Map<String, String> urlMap : list) {
			Map<String, Object> d = new HashMap<>();
			d.put("index", 0);
			d.put("mediaType", 1);
			d.put("url", urlMap.get("pictureUrl"));
			data.add(d);
		}
		System.out.println(JSONObject.toJSONString(data));
		result.put("data", data);
		Map<String, Object> r = new HashMap<>();
		r.put("code", 0);
		r.put("description", "OK");
		r.put("result", result);

		System.out.println(JSONObject.toJSONString(r));*/
		String[] pictureUrls = new String[]{"11", "22"};
		List<Object> urlList = Arrays.asList(pictureUrls);
		System.out.println(urlList.contains("11"));

	}

	private static byte[] aa(InputStream input) throws IOException {
		ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
		byte[] buff = new byte[100]; //buff用于存放循环读取的临时数据
		int rc = 0;
		while ((rc = input.read(buff, 0, 100)) > 0) {
			swapStream.write(buff, 0, rc);
		}
		byte[] in_b = swapStream.toByteArray();
		return in_b;
	}

    @RequestMapping("/getList")
    public R listList(){
        //查询列表数据
    	AppUser user = AppUserUtil.getLoginAppUser();
    	user=userClient.getLoginAppUserAnon(user.getId());
    	Map<String, Object> params=new HashMap<>();
      	params.put("companysId", user.getCompanyid());
        List<DeviceDoorEntity> deviceDoorList = deviceDoorService.queryList(params);
        return R.ok().put("list", deviceDoorList);
    }

    /**
     * 信息
     */
    @RequestMapping("/info/{id}")
    public R info(@PathVariable("id") Integer id){
			DeviceDoorEntity deviceDoor = deviceDoorService.queryObject(id);

        return R.ok().put("deviceDoor", deviceDoor);
    }
    @Autowired
    SysDoorDeptService sysDoorDeptService;
    /**
     * 保存
     */
    private SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    @RequestMapping("/save")
    public R save(@RequestBody DeviceDoorEntity deviceDoor){
    	AppUser user = AppUserUtil.getLoginAppUser();
    	user=userClient.getLoginAppUserAnon(user.getId());
    	
    	Map<String, Object> params=new HashMap<>();
      	params.put("companysId", user.getCompanyid());
        List<DeviceDoorEntity> deviceDoorList = deviceDoorService.queryList(params);
        
        

		for (DeviceDoorEntity deviceDoor2 : deviceDoorList) {
			if(deviceDoor2.getName().equals(deviceDoor.getName())) {
				return R.error("已经存在此出入口了");
			}
		}
        
		Long companyid=userClient.getLoginAppUserAnon(user.getId()).getCompanysId();
		
    	deviceDoor.setCreatetime(new Date());
    	deviceDoor.setUpdatetime(new Date());
    	deviceDoor.setCompanysId(user.getCompanyid());
		deviceDoorService.save(deviceDoor);
		String fdeptNos=deviceDoor.getFdeptNos();
		String fdeptNosAttr[]=fdeptNos.split(",");
		for (String fdeptNo : fdeptNosAttr) {
			if(fdeptNo==null||"".equals(fdeptNo)) {
				continue;
			}
			Integer shiftDeptNo=Integer.valueOf(fdeptNo);
			List<DeptVO> vonewList =new ArrayList<>();
			 List<DeptVO> childrenList=new ArrayList<>();
		     
			 List<DeptVO> deptList = new ArrayList<>();
			 if(shiftDeptNo<0) {//全公司部门
				 DeptVO deptVO=new DeptVO();
				 deptVO.setUnionNo(-1*shiftDeptNo.longValue());
				 deptList =  deviceDoorDao.findDeptList(deptVO);
				 childrenList.addAll(deptList);
			 }else {
				 DeptVO deptVO = deviceDoorDao.findDeptByDeptNo(shiftDeptNo.longValue());
				 deptList.add(deptVO);
				 childrenList.add(deptVO);
			 }
			
			if(deptList.size()>0){
		    boolean flag=true;
			List<DeptVO> voList2=new ArrayList<DeptVO>();
			
			
			//找出所有的下级
			while(flag){
				 for (int i=0;i<deptList.size();i++) {
					 DeptVO categoryVO2 = deptList.get(i);
					 List<DeptVO> parentDeptList= deviceDoorDao.findDeptByParentNo(categoryVO2.getDeptNo(),companyid);//找出第一层级
					 childrenList.addAll(parentDeptList);
					
					 categoryVO2.setChildren(parentDeptList);//读取所有的部门退出
					 voList2.addAll(parentDeptList);

					 boolean deptaddFlag=true;
					 
					for (DeptVO deptVO2 : childrenList) {
						if(categoryVO2.getDeptNo().intValue()==deptVO2.getDeptNo().intValue()) {
							deptaddFlag=false;
						}
					}

					 if(deptaddFlag) {
						 
					     vonewList.add(categoryVO2);
					 }
					 if(voList2.size()==0&&i==deptList.size()-1){
						
						 flag=false;
				        // continue;
					 }
					 if(i==deptList.size()-1){
						 
						
						 deptList=voList2;
						 voList2=new ArrayList<DeptVO>();
						 i=-1;
					 }
					 
				}
				
			}
			}
			HashSet h = new HashSet(childrenList);
			childrenList.clear();
			childrenList.addAll(h);
            for (DeptVO deptVO : childrenList) {
            	SysDoorDeptEntity sysDoorDept=new SysDoorDeptEntity();
    			sysDoorDept.setFdeptno(deptVO.getDeptNo().intValue());
    			sysDoorDept.setDoorid(deviceDoor.getId());
    			sysDoorDeptService.save(sysDoorDept);
			}
			
		}

        return R.ok();
    }

    /**
     * 修改
     */
    
    @Autowired
    DeviceDoorDao deviceDoorDao;
    
    @Autowired
    SysDoorDeptDao sysDoorDeptDao;
    
    @RequestMapping("/update")
    public R update(@RequestBody DeviceDoorEntity deviceDoor) throws URISyntaxException, Exception{
    	deviceDoor.setUpdatetime(new Date());
    	List<Long> updateUserList=new ArrayList<>();
    
    	AppUser user = AppUserUtil.getLoginAppUser();
    	user=userClient.getLoginAppUserAnon(user.getId());
    	Map<String, Object> params=new HashMap<>();
      	params.put("companysId", user.getCompanyid());
      	
        List<DeviceDoorEntity> deviceDoorList = deviceDoorService.queryList(params);
        
		List<DeviceDoorEntity> removeList=new ArrayList<>();
		
		for (DeviceDoorEntity deptVO2 : deviceDoorList) {
			if(deptVO2.getId().intValue()==deviceDoor.getId().intValue()) {
				removeList.add(deptVO2);
			}
		}
		Long companyid=userClient.getLoginAppUserAnon(user.getId()).getCompanysId();
		
        for (DeviceDoorEntity index : removeList) {
        	deviceDoorList.remove(index);
		}
        deviceDoorList=deviceDoorList==null?new ArrayList<>():deviceDoorList;
		for (DeviceDoorEntity deptVO2 : deviceDoorList) {
			if(deptVO2.getName().equals(deviceDoor.getName())) {
				return R.error("已经存在此出入口了");
			}
		}
		
			deviceDoorService.update(deviceDoor);
			deviceDoorDao.deletebydoorid(deviceDoor.getId());
			
			String fdeptNos=deviceDoor.getFdeptNos();
			String fdeptNosAttr[]=fdeptNos.split(",");
			 List<DeptVO> childrenList=new ArrayList<>();
		     if(fdeptNos==null||"".equals(fdeptNos)) {
		    	 fdeptNosAttr=new String[1];
		    	 fdeptNosAttr[0]=""+(user.getCompanysId()*-1);
		    	 
		     }
		     
		     if((fdeptNos==null||"".equals(fdeptNos))) {//清空所有部门
		    	 updateUserList=new ArrayList<>();
					deviceDoorDao.deletebydoorid(deviceDoor.getId().intValue());
					List<SysDoorDeptEntity> deptList=sysDoorDeptDao.queryListDoorDept(deviceDoor.getId().intValue());
					for (SysDoorDeptEntity sysDoorDeptEntity : deptList) {
						updateUserList.add(sysDoorDeptEntity.getFdeptno().longValue());
					}
					Map<String,Object> paramslist=new HashMap<>();
	            	paramslist.put("list", updateUserList);
	  			    sysDoorDeptDao.updateUserDateTimeByUnionNo(paramslist);
	  			    
					return R.ok();
			}
		     
			for (String fdeptNo : fdeptNosAttr) {
				if(fdeptNo==null||"".equals(fdeptNo)) {
					continue;
				}
				
				Integer shiftDeptNo=Integer.valueOf(fdeptNo);
				List<DeptVO> vonewList =new ArrayList<>();
				//更新部门下面的员工时间 通知设备拉取
				
				 List<DeptVO> deptList = new ArrayList<>();
				 if(shiftDeptNo<0) {//全公司部门
					 DeptVO deptVO=new DeptVO();
					 deptVO.setUnionNo(-1*shiftDeptNo.longValue());
					 deptList =  deviceDoorDao.findDeptList(deptVO);
					 childrenList.addAll(deptList);
				 }else {
					 DeptVO deptVO = deviceDoorDao.findDeptByDeptNo(shiftDeptNo.longValue());
					 deptList.add(deptVO);
					 childrenList.add(deptVO);
				 }
				
				if(deptList.size()>0){
			    boolean flag=true;
				List<DeptVO> voList2=new ArrayList<DeptVO>();
				
				
				//找出所有的下级
				while(flag){
					 for (int i=0;i<deptList.size();i++) {
						 DeptVO categoryVO2 = deptList.get(i);
						 List<DeptVO> parentDeptList= deviceDoorDao.findDeptByParentNo(categoryVO2.getDeptNo(),companyid);//找出第一层级
						 childrenList.addAll(parentDeptList);
						
						 categoryVO2.setChildren(parentDeptList);//读取所有的部门退出
						 voList2.addAll(parentDeptList);

						 boolean deptaddFlag=true;
						 
						for (DeptVO deptVO2 : childrenList) {
							if(categoryVO2.getDeptNo().intValue()==deptVO2.getDeptNo().intValue()) {
								deptaddFlag=false;
							}
						}

						 if(deptaddFlag) {
							 
						     vonewList.add(categoryVO2);
						 }
						 if(voList2.size()==0&&i==deptList.size()-1){
							
							 flag=false;
					        // continue;
						 }
						 if(i==deptList.size()-1){
							 
							
							 deptList=voList2;
							 voList2=new ArrayList<DeptVO>();
							 i=-1;
						 }
						 
					}
					
				}
				}
				HashSet h = new HashSet(childrenList);
				childrenList.clear();
				childrenList.addAll(h);
			    Map<Long, Boolean> childrenListMap=new HashMap<>();
	
	            for (DeptVO deptVO : childrenList) {
	            	updateUserList.add(deptVO.getDeptNo());
	            	childrenListMap.put(deptVO.getDeptNo(), true);
	            	SysDoorDeptEntity sysDoorDept=new SysDoorDeptEntity();
					sysDoorDept.setFdeptno(deptVO.getDeptNo().intValue());
					sysDoorDept.setDoorid(deviceDoor.getId());
					
					SysDoorDeptEntity sysDoorDept1=sysDoorDeptDao.queryObjectBydeptNo(sysDoorDept);
					
					if(sysDoorDept1==null) {
						sysDoorDeptService.save(sysDoorDept);
					} else if(sysDoorDept1.getFdelflag().intValue()==1||sysDoorDept1.getFdelflag().intValue()==2){
						sysDoorDept1.setFdelflag(0);
						sysDoorDeptService.update(sysDoorDept1);
					}
				}
	        	//查询出原来的门
		    	List<SysDoorDeptEntity>  deptdoorList=sysDoorDeptDao.queryListDoorDeptByDelFlag(deviceDoor.getId());
		    	for (SysDoorDeptEntity sysDoorDeptEntity : deptdoorList) {
		    			updateUserList.add(sysDoorDeptEntity.getFdeptno().longValue());
				}
	            if(updateUserList.size()>0) {
	            	Map<String,Object> paramslist=new HashMap<>();
	            	paramslist.put("list", updateUserList);
	  			    sysDoorDeptDao.updateUserDateTimeByUnionNo(paramslist);
	  			}
				
			}
			sendMessageDevice(user.getCompanyid());
        return R.ok();
    }

    /**
     * 删除
     */
    @RequestMapping("/delete")
    public R delete(@RequestBody Integer[] ids){
    	for (Integer id : ids) {
    		List<DeviceDoorEntity> deviceDoor = deviceDoorDao.queryObjectList(id);
            for (DeviceDoorEntity deviceDoorEntity : deviceDoor) {
            	 if(deviceDoorEntity.getDeviceId()!=null) {
                 	return R.error("已经绑定了设备；不能删除");
                 }
			}
            Map<String,Object> map=new HashMap();
            map.put("doorid", id);
            map.put("fdelflag", 0);
            List<SysDoorDeptEntity> doorDeptList= sysDoorDeptDao.queryList(map);
            int count=0;
            for (SysDoorDeptEntity sysDoorDeptEntity : doorDeptList) {
				if(sysDoorDeptEntity.getFdelflag()==0) {
					count++;
				}
			}
            
            if(count>0) {
            	return R.error("已经绑定了部门；不能删除");
            }
            
		}
			deviceDoorService.deleteBatch(ids);

        return R.ok();
    }
    
    @Autowired
 	private StringRedisTemplate template;


	private void sendMessageScrollPicture(String doorIds) throws Exception {
		logger.info("【出入口管理-批量导入广告轮播图】发送消息开始：doorIds:{}", doorIds);
		List<Map<String, String>> macList = new ArrayList<>();
		for(String doorId : doorIds.split(",")) {
			List<Map<String, String>> macs = userDeviceDao.findByDoorId(Integer.valueOf(doorId));
			macList.addAll(macs);
		}
		logger.info("【出入口管理-批量导入广告轮播图】发送消息设备的mac地址：{}", JSON.toJSON(macList));


		List<NET_Session_Body> bodyList=new ArrayList<>();

		List<NET_Session_Body> linkSnoList=null;
		Set<String> set = template.keys("*_LINK");
		Iterator<String> it1 = set.iterator();

		while(it1.hasNext()){
			String keyStr = it1.next();
			String sno=keyStr.split("_")[0];
			boolean flag=true;
			for (Map<String, String> map: macList) {
				if(map.get("mac_addres").equals(sno)) {
					flag=false;
					break;
				}
			}
			if(flag) {
				continue;
			}
			Gson gson = new Gson();
			try {
				linkSnoList=gson.fromJson(template.boundValueOps(sno+"_LINK").get(), new TypeToken<List<NET_Session_Body>>() {
				}.getType());
			}catch (Exception e) {
				linkSnoList=null;
			}
			if(linkSnoList==null) {
				linkSnoList=new ArrayList<>();
			}


			for (NET_Session_Body net_Session_Body : linkSnoList) {

				if(sno.equals(net_Session_Body.getSno())&&(template.boundValueOps(sno+"_"+net_Session_Body.getSessionId()).get()==null)) {//过滤掉以前的sessionID
					template.delete(sno+"_"+net_Session_Body.getSessionId());
				}else {
					bodyList.add(net_Session_Body);
				}
			}
		}

		logger.info("【出入口管理-批量导入广告轮播图】发送消息bodyList：{}", JSON.toJSON(bodyList));
		for (NET_Session_Body net_Session_Body : bodyList) {
			SocketClient.sendScrollPicture("http://127.0.0.1:8090",net_Session_Body.getSno(), net_Session_Body.getSessionId(), net_Session_Body.getServerip(), net_Session_Body.getServerport(), "2050");
		}
	}

    private void sendMessageDevice(Long conpanyId) throws URISyntaxException, Exception {
    	Device device=new Device();
    	device.setCompanyid(conpanyId);
	    List<Device>  deviceList=userDeviceDao.findByCompanyDeviceData(device);
	    
	    List<NET_Session_Body> bodyList=new ArrayList<>();
	   
	    List<NET_Session_Body> linkSnoList=null;
		Set<String> set = template.keys("*_LINK");
		Iterator<String> it1 = set.iterator();
		 
		while(it1.hasNext()){
			String keyStr = it1.next();
			String sno=keyStr.split("_")[0];
			boolean flag=true;
			for (Device device2 : deviceList) {
				if(device2.getMacAddres().equals(sno)) {
					flag=false;
					break;
				}
			}
			if(flag) {
				continue;
			}
			Gson gson = new Gson();
			try {
		       linkSnoList=gson.fromJson(template.boundValueOps(sno+"_LINK").get(), new TypeToken<List<NET_Session_Body>>() {
	        }.getType()); 
			}catch (Exception e) {
				linkSnoList=null;
			}
			if(linkSnoList==null) {
				linkSnoList=new ArrayList<>();
			}

			
			for (NET_Session_Body net_Session_Body : linkSnoList) {
				
				if(sno.equals(net_Session_Body.getSno())&&(template.boundValueOps(sno+"_"+net_Session_Body.getSessionId()).get()==null)) {//过滤掉以前的sessionID
					template.delete(sno+"_"+net_Session_Body.getSessionId());
				}else {
					bodyList.add(net_Session_Body);
				}
			}
		}
		
		 for (NET_Session_Body net_Session_Body : bodyList) {
			SocketClient.sendUserUploadInfo("http://127.0.0.1:8090",net_Session_Body.getSno(), net_Session_Body.getSessionId(), net_Session_Body.getServerip(), net_Session_Body.getServerport());
		}
	}
}
