package com.cloud.userdevice.config.common;

public class Constant {
	
	public static class RedisConst {
		public static final String ID_GENERATOR_PRODUCT = "idGenerator:userdevice";
		public static final String ID_GENERATOR_IMAGE_PRODUCT = "idGenerator:deviceimage";
		public static final String HEADER_KEY_HEARBEAT_KEY = "heartbeat";
		
		public static final String HEADER_KEY_LINK_KEY = "LINK";//相机的seesionId
		public static final String HEADER_KEY_CONFILICT_KEY = "conflictsno";//冲突的相机sno
	}

}
