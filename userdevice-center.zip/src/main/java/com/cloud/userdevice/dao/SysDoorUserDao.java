package com.cloud.userdevice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.cloud.userdevice.entity.SysDoorUserEntity;

/**
 * 门用户表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-18 09:11:55
 */
@Mapper
public interface SysDoorUserDao{

	void deleteBatch(Integer[] ids);

	void delete(Integer id);

	void update(SysDoorUserEntity sysDoorUser);

	void save(SysDoorUserEntity sysDoorUser);

	int queryTotal(Map<String, Object> map);

	List<SysDoorUserEntity> queryList(Map<String, Object> map);

	SysDoorUserEntity queryObject(Integer id);

	SysDoorUserEntity queryObjectByuserId(SysDoorUserEntity sysDoorUser);

	void updateUserDateTime(Long fuserId);

	List<SysDoorUserEntity> queryListDoorUser(Integer doorid);
	
}
