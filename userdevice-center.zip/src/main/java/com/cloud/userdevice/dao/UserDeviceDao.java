package com.cloud.userdevice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.*;

import com.cloud.model.device.Device;
import com.cloud.model.device.UserDevice;
import com.cloud.userdevice.model.DeviceLoginVo;

@Mapper
public interface UserDeviceDao {
	int saveDevice(Device log);
	
	
	
	@Insert("insert into t_user_device(userid,devicename, deviceid,descript) values(#{userid},#{devicename}, #{deviceid},#{descript})")
	int saveUserDevice(UserDevice log);
	
	
	 @Update("update t_user_device set devicename=#{devicename},descript=#{descript} where userid=#{userid} and deviceid=#{deviceid}") 
	 void updateUserDevice(UserDevice device);
	 
	int count(Map<String, Object> params);

	List<Device> findData(Map<String, Object> params);
	Device findById(Long id);
	
	Device findBySno(String macAddres);
    @Update("update t_device set devicename=#{deviceName},mac_addres=#{macAddres},remark=#{remark},ip=#{ip},sno=#{sno},doorId=#{doorId},password=#{password},algorithmSupplier=#{algorithmSupplier},algorithmVersion=#{algorithmVersion},wifiMac=#{wifiMac} where id=#{id}") 
	void update(Device device);
    @Update("update t_device set password=#{password} where id=#{id}") 
   	void updatePassword(Device device);
    
    @Select("select t.id,d.devicename deviceName,t.mac_addres macAddres,t.ip,t.remark,t.createTime,d.userid userId,t.sno from t_device t left join t_user_device d on t.id=d.deviceid where t.mac_addres=#{macAddres}")
    Device findByUserSno(Device device);
    
    @Select("select t.id,d.devicename deviceName,t.mac_addres macAddres,t.ip,t.remark,t.createTime,d.userid userId,t.sno from t_device t left join t_user_device d on t.id=d.deviceid where t.id=#{id} and d.userid=#{userId}")
    Device findByUserDeviceId(Device device);
    List<Device> findByDeviceData(Device params);
     void createdatabasetable(Map<String, String> map);



	DeviceLoginVo deviceLogin(String deviceId);

	List<Device> findByCompanyDeviceData(Device device);

	List<Map<String, String>> findByDoorId(Integer doorId);

    public Integer batchInsert(List<Device> list);

    public boolean deleteById(Integer id);

    public boolean deleteByDeviceId(Integer deviceId);

    public void batchInsertUserDeivce(List<UserDevice> list);
}
