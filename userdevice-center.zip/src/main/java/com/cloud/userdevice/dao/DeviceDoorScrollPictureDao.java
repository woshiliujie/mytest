package com.cloud.userdevice.dao;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2019/4/26 0026.
 */
@Mapper
public interface DeviceDoorScrollPictureDao {

    void deleteBatchByDoorId(Map<String, List<Object>> map);

    List<Map<String, Object>> queryPicUrlByMacAddres(String macAdds);

    List<Map<String, String>> queryPicUrlByDoorId(Map<String, Object> map);

    void insertBatch(List<Map<String, Object>> list);

    void updateBypictureUrl(Map<String, Object> map);

}
