package com.cloud.userdevice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.cloud.userdevice.entity.DeptVO;
import com.cloud.userdevice.entity.DeviceDoorEntity;

/**
 * 门牌表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-01-17 08:40:44
 */
@Mapper
public interface DeviceDoorDao {

	DeviceDoorEntity queryObject(Integer id);

	List<DeviceDoorEntity> queryList(Map<String, Object> map);

	int queryTotal(Map<String, Object> map);

	void save(DeviceDoorEntity deviceDoor);

	void update(DeviceDoorEntity deviceDoor);

	void delete(Integer id);

	void deleteBatch(Integer[] ids);

	void deletebydoorid(Integer id);

	List<DeviceDoorEntity> queryObjectList(Integer id);

	List<DeptVO> findDeptList(@Param("deptVO")DeptVO deptVO);

	DeptVO findDeptByDeptNo(@Param("deptNo")Long positionNo);

	List<DeptVO> findDeptByParentNo(@Param("parentNo")Long parentNo,@Param("unionNo") Long unionNo);
	
}
