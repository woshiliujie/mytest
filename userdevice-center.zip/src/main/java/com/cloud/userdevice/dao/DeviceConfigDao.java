package com.cloud.userdevice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.cloud.userdevice.model.DeviceConfigEntity;

/**
 * 设备配置表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-16 09:21:49
 */
@Mapper
public interface DeviceConfigDao {

	void deleteBatch(Integer[] ids);

	void delete(Integer id);

	void update(DeviceConfigEntity deviceConfig);

	void save(DeviceConfigEntity deviceConfig);

	int queryTotal(Map<String, Object> map);

	List<DeviceConfigEntity> queryList(Map<String, Object> map);

	DeviceConfigEntity queryObject(String sno);
	
}
