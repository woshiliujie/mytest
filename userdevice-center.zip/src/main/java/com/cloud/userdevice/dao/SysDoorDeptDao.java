package com.cloud.userdevice.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

import com.cloud.userdevice.entity.SysDoorDeptEntity;

import io.lettuce.core.dynamic.annotation.Param;

/**
 * 门部门表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-18 14:16:55
 */
@Mapper
public interface SysDoorDeptDao  {

	SysDoorDeptEntity queryObject(Integer id);

	List<SysDoorDeptEntity> queryList(Map<String, Object> map);

	int queryTotal(Map<String, Object> map);

	void update(SysDoorDeptEntity sysDoorDept);

	void delete(Integer id);

	void deleteBatch(Integer[] ids);

	void save(SysDoorDeptEntity sysDoorDept);

	SysDoorDeptEntity queryObjectBydeptNo(SysDoorDeptEntity sysDoorDept);

	List<SysDoorDeptEntity> queryListFlag(Map<String, Object> params);

	List<SysDoorDeptEntity> queryListDoorDept(Integer doorid);

	List<Long> findBasicUserList(Map<String, Object> queryUserByDept);
	void updateUserDateTimeByUnionNo(Map<String,Object> list);

	List<SysDoorDeptEntity> queryListDoorDeptByDelFlag(Integer doorid);
	
}
