package com.cloud.userdevice.model;

public class TokenResult {
  private Long  refreshTokenTime;//	刷新token 时间	number	例如：20分钟 30,40,60
  private String token;
	public Long getRefreshTokenTime() {
		return refreshTokenTime;
	}
	public void setRefreshTokenTime(Long refreshTokenTime) {
		this.refreshTokenTime = refreshTokenTime;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
}
