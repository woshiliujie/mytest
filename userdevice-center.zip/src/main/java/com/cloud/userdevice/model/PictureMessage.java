package com.cloud.userdevice.model;

public class PictureMessage {
  private PictureData data;
  private Integer identify;
public PictureData getData() {
	return data;
}
public void setData(PictureData data) {
	this.data = data;
}
public Integer getIdentify() {
	return identify;
}
public void setIdentify(Integer identify) {
	this.identify = identify;
}
}
