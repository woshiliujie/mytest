package com.cloud.userdevice.model;

import java.io.Serializable;
import java.util.Date;


/**
 * 设备配置表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-16 09:21:49
 */
public class DeviceConfigEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//自增id
	private Integer id;
	//工作状态
	private Integer workstatus;
	//公司状态
	private Integer companystatus;
	//开灯距离
	private Integer opendistance;
	//关灯灯距离
	private Integer closedistance;
	//开始时间
	private String starttime;
	//结束时间
	private String endtime;
	//工作日
	private String weeks;
	//声音间隔
	private Integer voiceinterval;
	//1:1
	private Float threshold1;
	//1:n
	private Float thresholdn;
	//n:n
	private Float thresholdnn;
	//功能权限
	private String authority;
	//工作模式名称
	private String modename;
	//运行模式编号
	private Integer workmode;
	//闸机关闸时间
	private Integer delaytime;
	
	private String deviceId;
    private String devRebootTime;
    
    private Integer livingSwitch;
    
	public Integer getLivingSwitch() {
		return livingSwitch;
	}
	public void setLivingSwitch(Integer livingSwitch) {
		this.livingSwitch = livingSwitch;
	}
	public String getDevRebootTime() {
		return devRebootTime;
	}
	public void setDevRebootTime(String devRebootTime) {
		this.devRebootTime = devRebootTime;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	/**
	 * 设置：自增id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：自增id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：工作状态
	 */
	public void setWorkstatus(Integer workstatus) {
		this.workstatus = workstatus;
	}
	/**
	 * 获取：工作状态
	 */
	public Integer getWorkstatus() {
		return workstatus;
	}
	/**
	 * 设置：公司状态
	 */
	public void setCompanystatus(Integer companystatus) {
		this.companystatus = companystatus;
	}
	/**
	 * 获取：公司状态
	 */
	public Integer getCompanystatus() {
		return companystatus;
	}
	/**
	 * 设置：开灯距离
	 */
	public void setOpendistance(Integer opendistance) {
		this.opendistance = opendistance;
	}
	/**
	 * 获取：开灯距离
	 */
	public Integer getOpendistance() {
		return opendistance;
	}
	/**
	 * 设置：关灯灯距离
	 */
	public void setClosedistance(Integer closedistance) {
		this.closedistance = closedistance;
	}
	/**
	 * 获取：关灯灯距离
	 */
	public Integer getClosedistance() {
		return closedistance;
	}
	/**
	 * 设置：开始时间
	 */
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	/**
	 * 获取：开始时间
	 */
	public String getStarttime() {
		return starttime;
	}
	/**
	 * 设置：结束时间
	 */
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	/**
	 * 获取：结束时间
	 */
	public String getEndtime() {
		return endtime;
	}
	/**
	 * 设置：工作日
	 */
	public void setWeeks(String weeks) {
		this.weeks = weeks;
	}
	/**
	 * 获取：工作日
	 */
	public String getWeeks() {
		return weeks;
	}
	/**
	 * 设置：声音间隔
	 */
	public void setVoiceinterval(Integer voiceinterval) {
		this.voiceinterval = voiceinterval;
	}
	/**
	 * 获取：声音间隔
	 */
	public Integer getVoiceinterval() {
		return voiceinterval;
	}
	/**
	 * 设置：1:1
	 */
	public void setThreshold1(Float threshold1) {
		this.threshold1 = threshold1;
	}
	/**
	 * 获取：1:1
	 */
	public Float getThreshold1() {
		return threshold1;
	}
	/**
	 * 设置：1:n
	 */
	public void setThresholdn(Float thresholdn) {
		this.thresholdn = thresholdn;
	}
	/**
	 * 获取：1:n
	 */
	public Float getThresholdn() {
		return thresholdn;
	}
	/**
	 * 设置：n:n
	 */
	public void setThresholdnn(Float thresholdnn) {
		this.thresholdnn = thresholdnn;
	}
	/**
	 * 获取：n:n
	 */
	public Float getThresholdnn() {
		return thresholdnn;
	}
	/**
	 * 设置：功能权限
	 */
	public void setAuthority(String authority) {
		this.authority = authority;
	}
	/**
	 * 获取：功能权限
	 */
	public String getAuthority() {
		return authority;
	}
	/**
	 * 设置：工作模式名称
	 */
	public void setModename(String modename) {
		this.modename = modename;
	}
	/**
	 * 获取：工作模式名称
	 */
	public String getModename() {
		return modename;
	}
	/**
	 * 设置：运行模式编号
	 */
	public void setWorkmode(Integer workmode) {
		this.workmode = workmode;
	}
	/**
	 * 获取：运行模式编号
	 */
	public Integer getWorkmode() {
		return workmode;
	}
	/**
	 * 设置：闸机关闸时间
	 */
	public void setDelaytime(Integer delaytime) {
		this.delaytime = delaytime;
	}
	/**
	 * 获取：闸机关闸时间
	 */
	public Integer getDelaytime() {
		return delaytime;
	}
}
