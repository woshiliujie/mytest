package com.cloud.userdevice.model;

public class DeviceLoginVo {
	private Long companyId;	//企业ID	string	
	private String  companyLogo;	//公司logo		
	private String  companyName;	//公司名称		
	private String  picServerUrl;	//图片服务器 URL	string	
	private String  serverApkVer;	//服务器 最新APK版本	number	
	private String  tcpHost;	//TCP 主机端口	string	
	private Integer tcpPort;	//TCP 端口号	number	
	private String  token;	//token信令	string	
	private String  updateUrl;	//升级apk 
	private String adminPhone;//管理员手机号码
	public String getAdminPhone() {
		return adminPhone;
	}
	public void setAdminPhone(String adminPhone) {
		this.adminPhone = adminPhone;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public String getCompanyLogo() {
		return companyLogo;
	}
	public void setCompanyLogo(String companyLogo) {
		this.companyLogo = companyLogo;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getPicServerUrl() {
		return picServerUrl;
	}
	public void setPicServerUrl(String picServerUrl) {
		this.picServerUrl = picServerUrl;
	}
	public String getServerApkVer() {
		return serverApkVer;
	}
	public void setServerApkVer(String serverApkVer) {
		this.serverApkVer = serverApkVer;
	}
	public String getTcpHost() {
		return tcpHost;
	}
	public void setTcpHost(String tcpHost) {
		this.tcpHost = tcpHost;
	}
	public Integer getTcpPort() {
		return tcpPort;
	}
	public void setTcpPort(Integer tcpPort) {
		this.tcpPort = tcpPort;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getUpdateUrl() {
		return updateUrl;
	}
	public void setUpdateUrl(String updateUrl) {
		this.updateUrl = updateUrl;
	}
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		URL = uRL;
	}
	private String  URL	;//string
}
