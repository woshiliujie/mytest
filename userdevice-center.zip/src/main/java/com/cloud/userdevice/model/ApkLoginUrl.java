package com.cloud.userdevice.model;

public class ApkLoginUrl {
  private String updateUrl;

public String getUpdateUrl() {
	return updateUrl;
}

public void setUpdateUrl(String updateUrl) {
	this.updateUrl = updateUrl;
}
}
