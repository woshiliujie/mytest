package com.cloud.userdevice.model;

public class TokenRefresh {
  private String code;
  private String description;
  private TokenResult result;
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public TokenResult getResult() {
	return result;
}
public void setResult(TokenResult result) {
	this.result = result;
}
}
