package com.cloud.userdevice.model;

public class DeviceOperLog {
   private String type;
   private String val;
   private String params;
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public String getVal() {
	return val;
}
public void setVal(String val) {
	this.val = val;
}
public String getParams() {
	return params;
}
public void setParams(String params) {
	this.params = params;
}
private String ylparams;
public String getYlparams() {
	return ylparams;
}
public void setYlparams(String ylparams) {
	this.ylparams = ylparams;
}
}
