package com.cloud.userdevice.model;

public class PictureData {
   private PictureScale scale;
   private Integer encrypt;
public PictureScale getScale() {
	return scale;
}
public void setScale(PictureScale scale) {
	this.scale = scale;
}
public Integer getEncrypt() {
	return encrypt;
}
public void setEncrypt(Integer encrypt) {
	this.encrypt = encrypt;
}
   
}
