package com.cloud.userdevice.model;

import java.util.List;


public class Result {

    private String code;

    private String message;

    private Object obj;

    private List list;

    public Result(String code, Object obj) {
        this.code = code;
        this.obj = obj;
    }

    public Result(String code) {
        this.code = code;
    }

    public Result(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public Result() {}

    public String getCode() {
        return code;
    }

    public Result setCode(String code) {
        this.code = code;
        return this;
    }

    public String getMessage() {
        return message;
    }

    public Result setMessage(String message) {
        this.message = message;
        return this;
    }

    public Object getObj() {
        return obj;
    }

    public Result setObj(Object obj) {
        this.obj = obj;
        return this;
    }

    public List getList() {
        return list;
    }

    public Result setList(List list) {
        this.list = list;
        return this;
    }
}
