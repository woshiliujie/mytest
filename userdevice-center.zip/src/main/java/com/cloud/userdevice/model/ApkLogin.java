package com.cloud.userdevice.model;

public class ApkLogin {
  private	String deviceId;//	A1设备序列号	string	
  private	String deviceModel;//	设备型号	string	A1
  private	Long timestamp;//	时间戳	number	
public String getDeviceId() {
	return deviceId;
}
public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
}
public String getDeviceModel() {
	return deviceModel;
}
public void setDeviceModel(String deviceModel) {
	this.deviceModel = deviceModel;
}
public Long getTimestamp() {
	return timestamp;
}
public void setTimestamp(Long timestamp) {
	this.timestamp = timestamp;
}
}
