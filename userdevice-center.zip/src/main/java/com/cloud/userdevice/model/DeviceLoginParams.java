package com.cloud.userdevice.model;

public class DeviceLoginParams {
	private String algorithmSupplier;//	算法供应商	string	
	private String algorithmVersion;//		算法版本	string	
	private String apkVer;//		apk版本号	string	
	private String btMac;//		蓝牙 MAC	string	
	private String cpu;//		CPU序列号	string	
	private String deviceId;//		A1设备序列号	string	
	private String deviceModel;//		设备型号	string	A1
	private String deviceName;//		设备使用地址	string	用户自定义输入
	private String doorId;//		门id	string	
	private String lanMac;//		有线 MAC	string	
	private String password;//		密码	string	
	private String systemVer;//		系统固件版本号	string	
	public String getAlgorithmSupplier() {
		return algorithmSupplier;
	}
	public void setAlgorithmSupplier(String algorithmSupplier) {
		this.algorithmSupplier = algorithmSupplier;
	}
	public String getAlgorithmVersion() {
		return algorithmVersion;
	}
	public void setAlgorithmVersion(String algorithmVersion) {
		this.algorithmVersion = algorithmVersion;
	}
	public String getApkVer() {
		return apkVer;
	}
	public void setApkVer(String apkVer) {
		this.apkVer = apkVer;
	}
	public String getBtMac() {
		return btMac;
	}
	public void setBtMac(String btMac) {
		this.btMac = btMac;
	}
	public String getCpu() {
		return cpu;
	}
	public void setCpu(String cpu) {
		this.cpu = cpu;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getDeviceModel() {
		return deviceModel;
	}
	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public String getDoorId() {
		return doorId;
	}
	public void setDoorId(String doorId) {
		this.doorId = doorId;
	}
	public String getLanMac() {
		return lanMac;
	}
	public void setLanMac(String lanMac) {
		this.lanMac = lanMac;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSystemVer() {
		return systemVer;
	}
	public void setSystemVer(String systemVer) {
		this.systemVer = systemVer;
	}
	public String getWifiMac() {
		return wifiMac;
	}
	public void setWifiMac(String wifiMac) {
		this.wifiMac = wifiMac;
	}
	private String wifiMac;//		WIFI MAC	string	
}
