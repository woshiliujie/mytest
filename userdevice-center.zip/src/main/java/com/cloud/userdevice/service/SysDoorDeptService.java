package com.cloud.userdevice.service;

import java.util.List;
import java.util.Map;

import com.cloud.userdevice.entity.SysDoorDeptEntity;

/**
 * 门部门表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-18 14:16:55
 */
public interface SysDoorDeptService {
	
	SysDoorDeptEntity queryObject(Integer id);
	
	List<SysDoorDeptEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(SysDoorDeptEntity sysDoorDept);
	
	void update(SysDoorDeptEntity sysDoorDept);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);
}
