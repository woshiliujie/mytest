package com.cloud.userdevice.service;

import java.util.List;
import java.util.Map;

import com.cloud.userdevice.entity.DeviceDoorEntity;

/**
 * 门牌表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-01-17 08:40:44
 */
public interface DeviceDoorService {
	
	DeviceDoorEntity queryObject(Integer id);
	
	List<DeviceDoorEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(DeviceDoorEntity deviceDoor);
	
	void update(DeviceDoorEntity deviceDoor);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);
}
