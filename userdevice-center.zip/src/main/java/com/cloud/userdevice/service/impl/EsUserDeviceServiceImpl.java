package com.cloud.userdevice.service.impl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequestBuilder;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsRequest;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.action.index.IndexRequestBuilder;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.sort.SortOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.annotation.Async;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONObject;
import com.cloud.common.utils.AppUserUtil;
import com.cloud.common.utils.PageUtil;
import com.cloud.model.common.Page;
import com.cloud.model.device.Device;
import com.cloud.model.device.UserDevice;
import com.cloud.model.log.Log;
import com.cloud.model.user.AppUser;
import com.cloud.userdevice.service.UserDeviceService;

//@Service
public class EsUserDeviceServiceImpl implements UserDeviceService, ApplicationContextAware {

	private static final Logger logger = LoggerFactory.getLogger(EsUserDeviceServiceImpl.class);

	private static final String INDEX = "index_logs";
	private static final String TYPE = "type_logs";
	AppUser user = AppUserUtil.getLoginAppUser();
	@Autowired
	private TransportClient client;

	/**
	 * 将设备保存到elasticsearch<br>
	 * 注解@Async是开启异步执行
	 *
	 * @param log
	 */

	@Override
	public Page<Device> findDevices(Map<String, Object> params) {
		SearchRequestBuilder builder = client.prepareSearch().setIndices(INDEX).setTypes(TYPE);
		if (!CollectionUtils.isEmpty(params)) {
			BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();

			// 设备名称模糊匹配
			String username = MapUtils.getString(params, "deviceName");
			if (StringUtils.isNoneBlank(username)) {
				queryBuilder.must(QueryBuilders.wildcardQuery("devicename", "*" + username + "*"));
			}
			// 模块精确匹配
		       queryBuilder.must(QueryBuilders.matchQuery("userId",  user.getId()));
		       
			// mac地址模糊匹配
			String macAddres = MapUtils.getString(params, "macAddres");
			if (StringUtils.isNoneBlank(macAddres)) {
				queryBuilder.must(QueryBuilders.wildcardQuery("mac_addres",  "*" + macAddres + "*"));
			}

			// 模块精确匹配
			String ip = MapUtils.getString(params, "id");
			if (StringUtils.isNoneBlank(ip)) {
				queryBuilder.must(QueryBuilders.matchQuery("ip",  ip));
			}

			// 大于等于开始日期,格式yyyy-MM-dd
			String beginTime = MapUtils.getString(params, "beginTime");
			if (StringUtils.isNoneBlank(beginTime)) {
				// 转化为0点0分0秒
				Long timestamp = toTimestamp(beginTime + "T00:00:00");
				queryBuilder.must(QueryBuilders.rangeQuery("createTime").from(timestamp));
			}

			// 小于等于结束日期,格式yyyy-MM-dd
			String endTime = MapUtils.getString(params, "endTime");
			if (StringUtils.isNoneBlank(endTime)) {
				// 转化为23点59分59秒
				Long timestamp = toTimestamp(endTime + "T23:59:59");
				queryBuilder.must(QueryBuilders.rangeQuery("createTime").to(timestamp));
			}

			if (queryBuilder != null) {
				builder.setPostFilter(queryBuilder);
			}
		}

		builder.addSort("createTime", SortOrder.DESC);

		PageUtil.pageParamConver(params, true);
		Integer start = MapUtils.getInteger(params, PageUtil.START);
		if (start != null) {
			builder.setFrom(start);
		}

		Integer length = MapUtils.getInteger(params, PageUtil.LENGTH);
		if (length != null) {
			builder.setSize(length);
		}

		SearchResponse searchResponse = builder.get();

		SearchHits searchHits = searchResponse.getHits();
		// 总数量
		Long total = searchHits.getTotalHits();

		int size = searchHits.getHits().length;
		List<Device> list = new ArrayList<>(size);
		if (size > 0) {
			searchHits.forEach(hit -> {
				String val = hit.getSourceAsString();
				list.add(JSONObject.parseObject(val, Device.class));
			});
		}

		return new Page<>(total.intValue(), list);
	}

	private Long toTimestamp(String str) {
		LocalDateTime localDateTime = LocalDateTime.parse(str);
		Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());

		return date.getTime();
	}

	private static ApplicationContext applicationContext = null;

	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		applicationContext = context;
	}

	/**
	 * 初始化设备es索引
	 */
	@PostConstruct
	public void initIndex() {
		UserDeviceService logService = applicationContext.getBean(UserDeviceService.class);
		// 设备实现是否采用elasticsearch
		boolean flag = (logService instanceof EsUserDeviceServiceImpl);
		if (!flag) {
			return;
		}

		try {
			// 判断索引是否存在
			IndicesExistsResponse indicesExistsResponse = client.admin().indices()
					.exists(new IndicesExistsRequest(INDEX)).get();
			if (indicesExistsResponse.isExists()) {
				return;
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}

		CreateIndexRequestBuilder requestBuilder = client.admin().indices().prepareCreate(INDEX);

		CreateIndexResponse createIndexResponse = requestBuilder.execute().actionGet();
		if (createIndexResponse.isAcknowledged()) {
			logger.info("索引：{},创建成功", INDEX);
		} else {
			logger.error("索引：{},创建失败", INDEX);
		}
	}

	@Override
	public Device findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Device device) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public List<Device> findByDeviceData(Device device) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int saveUserDevice(UserDevice log) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateUserDevice(UserDevice device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Device findByUserSno(Device device) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Device findByUserDeviceId(Device device) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Device findBySno(String sno) {
		// TODO Auto-generated method stub
		return null;
	}

    @Override
    public void batchInsert(List<Device> list) throws Exception {

    }

    @Override
    public boolean deleteById(Integer id) {
        return false;
    }

    @Override
    public void batchInsertUserDeivce(List<UserDevice> userDeviceList) {

    }
}
