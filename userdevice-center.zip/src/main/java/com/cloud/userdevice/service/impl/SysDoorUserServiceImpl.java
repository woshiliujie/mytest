package com.cloud.userdevice.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cloud.userdevice.dao.SysDoorUserDao;
import com.cloud.userdevice.entity.SysDoorUserEntity;
import com.cloud.userdevice.service.SysDoorUserService;



@Service("sysDoorUserService")
public class SysDoorUserServiceImpl implements SysDoorUserService {
	@Autowired
	private SysDoorUserDao sysDoorUserDao;
	
	@Override
	public SysDoorUserEntity queryObject(Integer id){
		return sysDoorUserDao.queryObject(id);
	}
	
	@Override
	public List<SysDoorUserEntity> queryList(Map<String, Object> map){
		return sysDoorUserDao.queryList(map);
	}
	
	@Override
	public int queryTotal(Map<String, Object> map){
		return sysDoorUserDao.queryTotal(map);
	}
	
	@Override
	public void save(SysDoorUserEntity sysDoorUser){
		sysDoorUserDao.save(sysDoorUser);
	}
	
	@Override
	public void update(SysDoorUserEntity sysDoorUser){
		sysDoorUserDao.update(sysDoorUser);
	}
	
	@Override
	public void delete(Integer id){
		sysDoorUserDao.delete(id);
	}
	
	@Override
	public void deleteBatch(Integer[] ids){
		sysDoorUserDao.deleteBatch(ids);
	}
	
}
