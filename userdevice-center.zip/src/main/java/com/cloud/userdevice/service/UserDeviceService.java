package com.cloud.userdevice.service;

import java.util.List;
import java.util.Map;

import com.cloud.model.common.Page;
import com.cloud.model.device.Device;
import com.cloud.model.device.UserDevice;

public interface UserDeviceService {

	/**
	 * 保存设备信息
	 *
	 * @param params
	 */

	Page<Device> findDevices(Map<String, Object> params);

	Device findById(Long id);
	int saveUserDevice(UserDevice log);
	void update(Device device);
	Device findBySno(String macAddres);
	List<Device> findByDeviceData(Device device);
	void updateUserDevice(UserDevice device);
	Device findByUserSno(Device device);
	 Device findByUserDeviceId(Device device);

    public void batchInsert(List<Device> list) throws Exception;

    public boolean deleteById(Integer id);

    public void batchInsertUserDeivce(List<UserDevice> userDeviceList);
}
