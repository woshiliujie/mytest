package com.cloud.userdevice.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cloud.userdevice.dao.SysDoorDeptDao;
import com.cloud.userdevice.entity.SysDoorDeptEntity;
import com.cloud.userdevice.service.SysDoorDeptService;



@Service("sysDoorDeptService")
public class SysDoorDeptServiceImpl implements SysDoorDeptService {
	@Autowired
	private SysDoorDeptDao sysDoorDeptDao;
	
	@Override
	public SysDoorDeptEntity queryObject(Integer id){
		return sysDoorDeptDao.queryObject(id);
	}
	
	@Override
	public List<SysDoorDeptEntity> queryList(Map<String, Object> map){
		return sysDoorDeptDao.queryList(map);
	}
	
	@Override
	public int queryTotal(Map<String, Object> map){
		return sysDoorDeptDao.queryTotal(map);
	}
	
	@Override
	public void save(SysDoorDeptEntity sysDoorDept){
		sysDoorDeptDao.save(sysDoorDept);
	}
	
	@Override
	public void update(SysDoorDeptEntity sysDoorDept){
		sysDoorDeptDao.update(sysDoorDept);
	}
	
	@Override
	public void delete(Integer id){
		sysDoorDeptDao.delete(id);
	}
	
	@Override
	public void deleteBatch(Integer[] ids){
		sysDoorDeptDao.deleteBatch(ids);
	}
	
}
