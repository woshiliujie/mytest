package com.cloud.userdevice.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cloud.userdevice.dao.DeviceDoorDao;
import com.cloud.userdevice.entity.DeviceDoorEntity;
import com.cloud.userdevice.service.DeviceDoorService;



@Service("deviceDoorService")
public class DeviceDoorServiceImpl implements DeviceDoorService {
	@Autowired
	private DeviceDoorDao deviceDoorDao;
	
	@Override
	public DeviceDoorEntity queryObject(Integer id){
		return deviceDoorDao.queryObject(id);
	}
	
	@Override
	public List<DeviceDoorEntity> queryList(Map<String, Object> map){
		return deviceDoorDao.queryList(map);
	}
	
	@Override
	public int queryTotal(Map<String, Object> map){
		return deviceDoorDao.queryTotal(map);
	}
	
	@Override
	public void save(DeviceDoorEntity deviceDoor){
		deviceDoorDao.save(deviceDoor);
	}
	
	@Override
	public void update(DeviceDoorEntity deviceDoor){
		deviceDoorDao.update(deviceDoor);
	}
	
	@Override
	public void delete(Integer id){
		deviceDoorDao.delete(id);
	}
	
	@Override
	public void deleteBatch(Integer[] ids){
		deviceDoorDao.deleteBatch(ids);
	}
	
}
