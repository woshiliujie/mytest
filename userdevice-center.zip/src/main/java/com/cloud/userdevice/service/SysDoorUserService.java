package com.cloud.userdevice.service;

import java.util.List;
import java.util.Map;

import com.cloud.userdevice.entity.SysDoorUserEntity;

/**
 * 门用户表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-18 09:11:55
 */
public interface SysDoorUserService {
	
	SysDoorUserEntity queryObject(Integer id);
	
	List<SysDoorUserEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(SysDoorUserEntity sysDoorUser);
	
	void update(SysDoorUserEntity sysDoorUser);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);
}
