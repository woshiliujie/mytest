package com.cloud.userdevice.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import com.cloud.userdevice.dao.DeviceConfigDao;
import com.cloud.userdevice.model.DeviceConfigEntity;



@Service("deviceConfigService")
public class DeviceConfigServiceImpl implements DeviceConfigService {
	@Autowired
	private DeviceConfigDao deviceConfigDao;
	
	@Override
	public DeviceConfigEntity queryObject(String sno){
		return deviceConfigDao.queryObject(sno);
	}
	
	@Override
	public List<DeviceConfigEntity> queryList(Map<String, Object> map){
		return deviceConfigDao.queryList(map);
	}
	
	@Override
	public int queryTotal(Map<String, Object> map){
		return deviceConfigDao.queryTotal(map);
	}
	
	@Override
	public void save(DeviceConfigEntity deviceConfig){
		deviceConfigDao.save(deviceConfig);
	}
	
	@Override
	public void update(DeviceConfigEntity deviceConfig){
		deviceConfigDao.update(deviceConfig);
	}
	
	@Override
	public void delete(Integer id){
		deviceConfigDao.delete(id);
	}
	
	@Override
	public void deleteBatch(Integer[] ids){
		deviceConfigDao.deleteBatch(ids);
	}
	
}
