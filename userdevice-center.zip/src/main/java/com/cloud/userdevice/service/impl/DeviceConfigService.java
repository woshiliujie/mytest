package com.cloud.userdevice.service.impl;

import java.util.List;
import java.util.Map;

import com.cloud.userdevice.model.DeviceConfigEntity;

/**
 * 设备配置表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-16 09:21:49
 */
public interface DeviceConfigService {
	
	DeviceConfigEntity queryObject(String sno);
	
	List<DeviceConfigEntity> queryList(Map<String, Object> map);
	
	int queryTotal(Map<String, Object> map);
	
	void save(DeviceConfigEntity deviceConfig);
	
	void update(DeviceConfigEntity deviceConfig);
	
	void delete(Integer id);
	
	void deleteBatch(Integer[] ids);
}
