package com.cloud.userdevice.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import com.cloud.common.utils.PageUtil;
import com.cloud.model.common.Page;
import com.cloud.model.device.Device;
import com.cloud.model.device.NET_Session_Body;
import com.cloud.model.device.UserDevice;
import com.cloud.userdevice.config.common.Constant.RedisConst;
import com.cloud.userdevice.dao.UserDeviceDao;
import com.cloud.userdevice.service.UserDeviceService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.springframework.transaction.annotation.Transactional;

//@Primary
@Service
public class UserDeviceServiceImpl implements UserDeviceService {

	@Autowired
	private UserDeviceDao logDao;

	/**
	 * 将日志保存到数据库<br>
	 * 注解@Async是开启异步执行
	 *
	 * @param log
	 */
	@Autowired
	private StringRedisTemplate template;
	@Override
	public Page<Device> findDevices(Map<String, Object> params) {
		int total = logDao.count(params);
		List<Device> list = Collections.emptyList();
		if (total > 0) {
			PageUtil.pageParamConver(params, true);

			list = logDao.findData(params);
			
			getDeviceData(list);
		}
		return new Page<>(total, list);
	}

	@Override
	public Device findById(Long id) {
		// TODO Auto-generated method stub
		return logDao.findById(id);
	}

	@Override
	public void update(Device device) {
		logDao.update( device);
		
	}
    private void getDeviceData(List<Device> list){
              for (Device device : list) {
			int count=0;
			String sno=device.getMacAddres().trim();
			Gson gson = new Gson();
			List<NET_Session_Body> linkSnoList=gson.fromJson(template.boundValueOps(sno+"_"+RedisConst.HEADER_KEY_LINK_KEY).get(), new TypeToken<List<NET_Session_Body>>() {
	        }.getType()); 
			if(linkSnoList==null) {
				linkSnoList=new ArrayList<>();
			}
			int index=0;
			for (NET_Session_Body net_Session_Body : linkSnoList) {
				String status=template.boundValueOps(sno+"_"+net_Session_Body.getSessionId()).get();
				if(status!=null&&!"".equals(status)) {
					device.setSessionId(net_Session_Body.getSessionId());
					count++;device.setServerIp((device.getServerIp()==null?"":device.getServerIp()+";")+net_Session_Body.getServerip()+"_"+net_Session_Body.getServerport());
				}
			}
			if(count==1) {
				device.setStatus("在线");//1在线
				
			}else if(count==0) {
				device.setStatus("离线");//2离线
			}else if(count>1) {
				device.setStatus("冲突");//3冲突
			}
			
		}  
              
//              Collections.sort(list, new Comparator<Device>(){
//                  /*
//                   * int compare(Person p1, Person p2) 返回一个基本类型的整型，
//                   * 返回负数表示：p1 小于p2，
//                   * 返回0 表示：p1和p2相等，
//                   * 返回正数表示：p1大于p2
//                   */
//                  public int compare(Device p1, Device p2) {
//                    
//                      if(p1.getStatus().equals("在线")&&p2.getStatus().equals("离线")){
//                          return -1;
//                      }
//                      if(p2.getStatus().equals("在线")&&p1.getStatus().equals("离线")){
//                          return 1;
//                      }
//                      return -1;
//                  }
//              });
    }

	@Override
	public List<Device> findByDeviceData(Device device1) {
		// TODO Auto-generated method stub
		List<Device> list= logDao.findByDeviceData(device1);
		if(device1.getUserId().longValue()==0) {
			
		}
		getDeviceData(list); 
	      return list;
	}

	@Override
	public int saveUserDevice(UserDevice log) {
		// TODO Auto-generated method stub
		return logDao.saveUserDevice(log);
	}

	@Override
	public void updateUserDevice(UserDevice device) {
		// TODO Auto-generated method stub
		logDao.updateUserDevice(device);
	}

	@Override
	public Device findByUserSno(Device device) {
		// TODO Auto-generated method stub
		return logDao.findByUserSno(device);
	}

	@Override
	public Device findByUserDeviceId(Device device) {
		// TODO Auto-generated method stub
		return logDao.findByUserDeviceId(device);
	}

	@Override
	public Device findBySno(String macAddres) {
		return logDao.findBySno(macAddres);
	}

    @Transactional
    @Override
    public void batchInsert(List<Device> list) throws Exception {
        logDao.batchInsert(list);

        List<UserDevice> userDeviceList = new ArrayList<>();
        for (Device env : list) {
            UserDevice userDevice = new UserDevice();
            userDevice.setUserid(env.getUserId());
            userDevice.setDeviceid(env.getId());
            userDevice.setDevicename(env.getDeviceName());
            userDevice.setDescript(env.getRemark());

            userDeviceList.add(userDevice);
        }

        logDao.batchInsertUserDeivce(userDeviceList);

    }

    @Transactional
    @Override
    public void batchInsertUserDeivce(List<UserDevice> userDeviceList) {
//        logDao.batchInsertUserDeivce(userDeviceList);
    }

    @Transactional
    @Override
    public boolean deleteById(Integer id) {
        boolean flag = logDao.deleteById(id);
        boolean flag2 = logDao.deleteByDeviceId(id);
        if (flag && flag2) {
            return true;
        }
        return false;
    }
}
