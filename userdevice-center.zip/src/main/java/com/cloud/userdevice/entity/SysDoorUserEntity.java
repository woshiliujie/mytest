package com.cloud.userdevice.entity;

import java.io.Serializable;
import java.util.Date;


/**
 * 门用户表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-18 09:11:55
 */
public class SysDoorUserEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//自增id
	private Integer id;
	//门id
	private Integer doorid;
	//
	private Integer userid;
    private Integer fdelflag;
	/**
	 * 设置：自增id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：自增id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：门id
	 */
	public void setDoorid(Integer doorid) {
		this.doorid = doorid;
	}
	/**
	 * 获取：门id
	 */
	public Integer getDoorid() {
		return doorid;
	}
	/**
	 * 设置：
	 */
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	/**
	 * 获取：
	 */
	public Integer getUserid() {
		return userid;
	}
	public Integer getFdelflag() {
		return fdelflag;
	}
	public void setFdelflag(Integer fdelflag) {
		this.fdelflag = fdelflag;
	}
	
}
