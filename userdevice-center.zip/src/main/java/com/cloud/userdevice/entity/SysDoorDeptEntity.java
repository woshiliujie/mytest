package com.cloud.userdevice.entity;

import java.io.Serializable;
import java.util.Date;


/**
 * 门部门表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-02-18 14:16:55
 */
public class SysDoorDeptEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//自增id
	private Integer id;
	//门id
	private Integer doorid;
	//部门
	private Integer fdeptno;
    private String fdeptName;
    private Integer fdelflag;
	public Integer getFdelflag() {
		return fdelflag;
	}
	public void setFdelflag(Integer fdelflag) {
		this.fdelflag = fdelflag;
	}
	/**
	 * 设置：自增id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：自增id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：门id
	 */
	public void setDoorid(Integer doorid) {
		this.doorid = doorid;
	}
	/**
	 * 获取：门id
	 */
	public Integer getDoorid() {
		return doorid;
	}
	/**
	 * 设置：部门
	 */
	public void setFdeptno(Integer fdeptno) {
		this.fdeptno = fdeptno;
	}
	/**
	 * 获取：部门
	 */
	public Integer getFdeptno() {
		return fdeptno;
	}
	public String getFdeptName() {
		return fdeptName;
	}
	public void setFdeptName(String fdeptName) {
		this.fdeptName = fdeptName;
	}
	
}
