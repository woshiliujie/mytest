package com.cloud.userdevice.entity;

import java.util.List;


/**
 * 位置信息VO
 * @author iori
 *
 */
public class DeptVO  {

	private static final long serialVersionUID = -7419252917784444170L;
	private String name;
	private Long deptNo;
	private Long parentNo;
	private String parentName;
	private String parentShortName;
	private Long isLeaf;
	private String descNo;
	private String descName;
	private String oldDescNo;
	private String oldDescName;
	private String oldDeptName;
	private String oldShortName;
	private String deptName;
	private String deptShortName;
	private String description;
	private String searchDesc;
	private Long regionNo;
	private Long unionNo;
	private String title;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	private Long id;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	private String unionName;
	private Long groupNo;
	private Long flag=1l;
	private List<DeptVO> children;
	public List<DeptVO> getChildren() {
		return children;
	}
	public void setChildren(List<DeptVO> children) {
		this.children = children;
	}
	public Long getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(Long groupNo) {
		this.groupNo = groupNo;
	}
	public Long getFlag() {
		return flag;
	}
	public void setFlag(Long flag) {
		this.flag = flag;
	}
	public Long getRegionNo() {
		return regionNo;
	}
	public void setRegionNo(Long regionNo) {
		this.regionNo = regionNo;
	}
	public Long getUnionNo() {
		return unionNo;
	}
	public void setUnionNo(Long unionNo) {
		this.unionNo = unionNo;
	}
	public String getUnionName() {
		return unionName;
	}
	public void setUnionName(String unionName) {
		this.unionName = unionName;
	}
	public String getOldShortName() {
		return oldShortName;
	}
	public void setOldShortName(String oldShortName) {
		this.oldShortName = oldShortName;
	}
	public String getSearchDesc() {
		return searchDesc;
	}
	public String getOldDeptName() {
		return oldDeptName;
	}
	public void setOldDeptName(String oldDeptName) {
		this.oldDeptName = oldDeptName;
	}
	public void setSearchDesc(String searchDesc) {
		this.searchDesc = searchDesc;
	}
	public Long getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(Long deptNo) {
		this.setId(deptNo);
		this.deptNo = deptNo;
	}
	public Long getParentNo() {
		return parentNo;
	}
	public void setParentNo(Long parentNo) {
		this.parentNo = parentNo;
	}
	public Long getIsLeaf() {
		return isLeaf;
	}
	public void setIsLeaf(Long isLeaf) {
		this.isLeaf = isLeaf;
	}
	public String getDescNo() {
		return descNo;
	}
	public void setDescNo(String descNo) {
		this.descNo = descNo;
	}
	public String getDescName() {
		return descName;
	}
	public void setDescName(String descName) {
		this.descName = descName;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptShortName() {
		return deptShortName;
	}
	public void setDeptShortName(String deptShortName) {
		this.deptShortName = deptShortName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getParentShortName() {
		return parentShortName;
	}
	public void setParentShortName(String parentShortName) {
		this.parentShortName = parentShortName;
	}
	public String getOldDescNo() {
		return oldDescNo;
	}
	public void setOldDescNo(String oldDescNo) {
		this.oldDescNo = oldDescNo;
	}
	public String getOldDescName() {
		return oldDescName;
	}
	public void setOldDescName(String oldDescName) {
		this.oldDescName = oldDescName;
	}
	
}
