package com.cloud.userdevice.entity;

import java.io.Serializable;
import java.util.Date;


/**
 * 门牌表
 * 
 * @author 
 * @email object_czx@163.com
 * @date 2019-01-17 08:40:44
 */
public class DeviceDoorEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	//自增id
	private Integer id;
	//名称
	private String name;
	//创建时间
	private Date createtime;
	//修改时间
	private Date updatetime;
    private Long companysId;
    
   private Long fcountry;
   private Long fprovince;
   private Long fcity;
   private String fdetailAddr;
   private String fdeptNos;
   private String fdeptNames;
   public String getFdeptNames() {
	return fdeptNames;
}
public void setFdeptNames(String fdeptNames) {
	this.fdeptNames = fdeptNames;
}
private String deviceId;
	public String getDeviceId() {
	return deviceId;
}
public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
}
	public String getFdeptNos() {
	return fdeptNos;
}
public void setFdeptNos(String fdeptNos) {
	this.fdeptNos = fdeptNos;
}
	public Long getFcountry() {
	return fcountry;
}
public void setFcountry(Long fcountry) {
	this.fcountry = fcountry;
}
public Long getFprovince() {
	return fprovince;
}
public void setFprovince(Long fprovince) {
	this.fprovince = fprovince;
}
public Long getFcity() {
	return fcity;
}
public void setFcity(Long fcity) {
	this.fcity = fcity;
}
public String getFdetailAddr() {
	return fdetailAddr;
}
public void setFdetailAddr(String fdetailAddr) {
	this.fdetailAddr = fdetailAddr;
}
	public Long getCompanysId() {
		return companysId;
	}
	public void setCompanysId(Long companysId) {
		this.companysId = companysId;
	}
	/**
	 * 设置：自增id
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：自增id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：名称
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * 获取：名称
	 */
	public String getName() {
		return name;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreatetime() {
		return createtime;
	}
	/**
	 * 设置：修改时间
	 */
	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	/**
	 * 获取：修改时间
	 */
	public Date getUpdatetime() {
		return updatetime;
	}
}
