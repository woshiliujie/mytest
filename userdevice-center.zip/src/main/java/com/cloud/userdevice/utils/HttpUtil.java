package com.cloud.userdevice.utils;

import java.io.*;
import java.net.URI;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.*;

import com.alibaba.fastjson.JSONObject;
import com.cloud.common.constants.Encryption;
import com.cloud.userdevice.model.PictureData;
import com.cloud.userdevice.model.PictureMessage;
import com.cloud.userdevice.model.PictureScale;
import com.cloud.userdevice.model.TokenRefresh;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.*;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

/**
 * @author 马弦
 * @date 2017年10月23日 下午2:49
 * HttpClient工具类
 */
public class HttpUtil {
	
	
	
	
	 private static final Logger logger = LoggerFactory.getLogger(HttpUtil.class);

    //保存到图片服务器
    public static String sendImageStoreServer (String url, InputStream in, String filename) throws Exception {
        String httpRes = null;
        PictureMessage message=new PictureMessage();
        PictureScale scale=new PictureScale();
        scale.setHeight(0);
        scale.setWidth(0);
        PictureData data=new PictureData();
        data.setEncrypt(0);
        data.setScale(scale);
        message.setData(data);
        message.setIdentify(42);
        Map<String,ContentBody> reqParam = new HashMap<String,ContentBody>();
        reqParam.put("message", new StringBody(JSONObject.toJSONString(message), ContentType.APPLICATION_JSON));
        reqParam.put("file", new InputStreamBody(in, filename));

        httpRes = HttpUtil.postFileMultiPart(url+"/upload",reqParam);
        logger.info("存储图片="+httpRes);
        return httpRes;

    }

    //保存到图片服务器
    public static String sendImageStoreServer (String url, byte[] b, String filename) throws Exception {
        String httpRes = null;
        PictureMessage message=new PictureMessage();
        PictureScale scale=new PictureScale();
        scale.setHeight(0);
        scale.setWidth(0);
        PictureData data=new PictureData();
        data.setEncrypt(0);
        data.setScale(scale);
        message.setData(data);
        message.setIdentify(42);
        Map<String,ContentBody> reqParam = new HashMap<String,ContentBody>();
        reqParam.put("message", new StringBody(JSONObject.toJSONString(message), ContentType.APPLICATION_JSON));
        reqParam.put("file", new ByteArrayBody(b, filename));

        httpRes = HttpUtil.postFileMultiPart(url+"/upload",reqParam);
        logger.info("存储图片="+httpRes);
        return httpRes;

    }

    //保存到图片服务器
    public static String sendImageStoreServer (String url,String localFileName) throws Exception {
        String httpRes = null;
        PictureMessage message=new PictureMessage();
        PictureScale scale=new PictureScale();
        scale.setHeight(0);
        scale.setWidth(0);
        PictureData data=new PictureData();
        data.setEncrypt(0);
        data.setScale(scale);
        message.setData(data);
        message.setIdentify(42);
        Map<String,ContentBody> reqParam = new HashMap<String,ContentBody>();
        reqParam.put("message", new StringBody(JSONObject.toJSONString(message), ContentType.APPLICATION_JSON));
        reqParam.put("file", new FileBody(new File(localFileName)));
        httpRes = HttpUtil.postFileMultiPart(url+"/upload",reqParam);
        logger.info("存储图片="+httpRes);
        return httpRes;

    }

    //删除图片服务器的图片
    public static String deleteImageStoreServer (String url,String fileNewName) throws Exception {
        String httpRes = null;
        Map<String,Object> message=new HashMap<>();
        message.put("identify", 22);
        Map<String,Object> data=new HashMap<>();
        List<Map<String,String>> fileNewNameList=new ArrayList<>();
        Map<String,String> fileNewNameListMap=new HashMap<>();
        fileNewNameListMap.put("file_name", fileNewName);
        fileNewNameList.add(fileNewNameListMap);
        data.put("file_list", fileNewNameList);
        message.put("data", data);
        httpRes = HttpUtil.doDeletePost(url+"/delete",JSONObject.toJSONString(message));
        return httpRes;

    }

    public static String doDeletePost(String url, String params) throws Exception {

        CloseableHttpClient httpclient = createSSLClientDefault();
        HttpPost httpPost = new HttpPost(url);// 创建httpPost
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("apiToken",getToken().getResult().getToken());
        httpPost.setHeader("Content-Type", "application/json; charset=utf-8");
        String charSet = "UTF-8";
        StringEntity entity = new StringEntity(params, charSet);
        httpPost.setEntity(entity);
        CloseableHttpResponse response = null;

        try {

            response = httpclient.execute(httpPost);
            StatusLine status = response.getStatusLine();
            int state = status.getStatusCode();
            if (state == HttpStatus.SC_OK) {
                HttpEntity responseEntity = response.getEntity();
                String jsonString = EntityUtils.toString(responseEntity);
                return jsonString;
            }
            else{
                logger.error("请求返回:"+state+"("+url+")");
            }
        }
        finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
                httpclient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public static String postFileMultiPart(String url,Map<String,ContentBody> reqParam) throws Exception{
        CloseableHttpClient httpclient = createSSLClientDefault();

        try {
            // 创建httpget.
            HttpPost httppost = new HttpPost(url);

            //setConnectTimeout：设置连接超时时间，单位毫秒。setConnectionRequestTimeout：设置从connect Manager获取Connection 超时时间，单位毫秒。这个属性是新加的属性，因为目前版本是可以共享连接池的。setSocketTimeout：请求获取数据的超时时间，单位毫秒。 如果访问一个接口，多少时间内无法返回数据，就直接放弃此次调用。
            RequestConfig defaultRequestConfig = RequestConfig.custom().setConnectTimeout(5000).setConnectionRequestTimeout(5000).setSocketTimeout(15000).build();
            httppost.setConfig(defaultRequestConfig);
            httppost.setHeader("encrypt","0");
            httppost.setHeader("apiToken",getToken().getResult().getToken());
            System.out.println("executing request " + httppost.getURI());

            MultipartEntityBuilder multipartEntityBuilder = MultipartEntityBuilder.create();
            for(Map.Entry<String,ContentBody> param : reqParam.entrySet()){
                multipartEntityBuilder.addPart(param.getKey(), param.getValue());
            }
            HttpEntity reqEntity = multipartEntityBuilder.build();
            httppost.setEntity(reqEntity);

            // 执行post请求.
            CloseableHttpResponse response = httpclient.execute(httppost);

            System.out.println("got response");

            try {
                // 获取响应实体
                HttpEntity entity = response.getEntity();
                //System.out.println("--------------------------------------");
                // 打印响应状态
                //System.out.println(response.getStatusLine());
                if (entity != null) {
                    return EntityUtils.toString(entity, Charset.forName("UTF-8"));
                }
                //System.out.println("------------------------------------");
            } finally {
                response.close();

            }
        } finally {
            // 关闭连接,释放资源
            try {
                httpclient.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private static String tokenUrlHeader="https://work.alfeye.com:8081";
    private static TokenRefresh getToken() throws Exception {
        String datatoken=HttpUtil.doPost(tokenUrlHeader+"/api-d/userdevice-anon/tokenRefresh?ver=2", "");
        Map<String,String> tokendata=(Map<String,String>)com.alibaba.fastjson.JSONObject.parseObject(datatoken, Map.class);
        TokenRefresh tokenRefresh=(TokenRefresh)com.alibaba.fastjson.JSONObject.parseObject(AESUtils.Decrypt(tokendata.get("data"), Encryption.encryptionMap.get("2")), TokenRefresh.class);

        return tokenRefresh;
    }

    public static CloseableHttpClient createSSLClientDefault() {
        try {
            //使用 loadTrustMaterial() 方法实现一个信任策略，信任所有证书
            SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
                // 信任所有
                public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                    return true;
                }
            }).build();
            //NoopHostnameVerifier类:  作为主机名验证工具，实质上关闭了主机名验证，它接受任何
            //有效的SSL会话并匹配到目标主机。
            HostnameVerifier hostnameVerifier = NoopHostnameVerifier.INSTANCE;
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);
            return HttpClients.custom().setSSLSocketFactory(sslsf).build();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        }
        return HttpClients.createDefault();

    }
 
	/**
	 * get请求
	 * @return
	 */
	public static String doGet(String url) {
        try {
        	HttpClient client = new DefaultHttpClient();
            //发送get请求
            HttpGet request = new HttpGet(url);
            HttpResponse response = client.execute(request);
 
            /**请求发送成功，并得到响应**/
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                /**读取服务器返回过来的json字符串数据**/
                String strResult = EntityUtils.toString(response.getEntity());
                
                return strResult;
            }
        } 
        catch (IOException e) {
        	e.printStackTrace();
        }
        
        return null;
	}
	
	/**
	 * post请求(用于key-value格式的参数)
	 * @param url
	 * @param params
	 * @return
	 */
	public static String doPost(String url, Map params){
		
		BufferedReader in = null;  
        try {  
            // 定义HttpClient  
            HttpClient client = new DefaultHttpClient();  
            // 实例化HTTP方法  
            HttpPost request = new HttpPost();  
            
            request.setURI(new URI(url));
            request.setHeader("Accept", "application/json"); 
            request.setHeader("Content-Type", "application/json; charset=utf-8");
            //设置参数
            List<NameValuePair> nvps = new ArrayList<NameValuePair>(); 
            for (Iterator iter = params.keySet().iterator(); iter.hasNext();) {
    			String name = (String) iter.next();
    			String value = String.valueOf(params.get(name));
    			nvps.add(new BasicNameValuePair(name, value));
    			
    			//System.out.println(name +"-"+value);
    		}
            request.setEntity(new UrlEncodedFormEntity(nvps,HTTP.UTF_8));
            
            HttpResponse response = client.execute(request);  
            int code = response.getStatusLine().getStatusCode();
            if(code == 200){	//请求成功
            	in = new BufferedReader(new InputStreamReader(response.getEntity()  
                        .getContent(),"utf-8"));
                StringBuffer sb = new StringBuffer("");  
                String line = "";  
                String NL = System.getProperty("line.separator");  
                while ((line = in.readLine()) != null) {  
                    sb.append(line + NL);  
                }
                
                in.close();  
                
                return sb.toString();
            }
            else{	//
            	System.out.println("状态码：" + code);
            	return null;
            }
        }
        catch(Exception e){
        	e.printStackTrace();
        	
        	return null;
        }
	}
	
	/**
	 * post请求（用于请求json格式的参数）
	 * @param url
	 * @param params
	 * @return
	 */
	public static String doPost(String url, String params) throws Exception {
		
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url);// 创建httpPost   
    	httpPost.setHeader("Accept", "application/json"); 
    	httpPost.setHeader("Content-Type", "application/json; charset=utf-8");
    	String charSet = "UTF-8";
    	StringEntity entity = new StringEntity(params, charSet);
    	httpPost.setEntity(entity);        
        CloseableHttpResponse response = null;
        
        try {
        	
        	response = httpclient.execute(httpPost);
            StatusLine status = response.getStatusLine();
            int state = status.getStatusCode();
            if (state == HttpStatus.SC_OK) {
            	HttpEntity responseEntity = response.getEntity();
            	String jsonString = EntityUtils.toString(responseEntity);
            	return jsonString;
            }
            else{
				 logger.error("请求返回:"+state+"("+url+")");
			}
        }
        finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            try {
				httpclient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
        }
        return null;
	}
	
}

