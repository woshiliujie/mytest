package com.cloud.userdevice.utils;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
public class SocketClient { 
	private static Logger log = LoggerFactory.getLogger(SocketClient.class);
	private static Map<String,Socket> snoSocketMap=new HashMap<>();
	static Socket socket=null;
    public  static void sendUserUploadInfo(String url,String sno,String sessionId,String serverip,Integer  serverport) throws URISyntaxException, Exception{
    	Map<String,Object> params=new HashMap<>();
    	params.put("username", "qianyi2018web");
    	params.put("password", "copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k=");
    	params.put("sno", sno);
    	
    	String resultInfo="";
		try {
			resultInfo = HttpUtil.doPost(url+"/weblogin", com.alibaba.fastjson.JSONObject.toJSONString(params));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	Map<String,Map<String,Object>> resultMap=(Map<String,Map<String,Object>>)com.alibaba.fastjson.JSONObject.parseObject(resultInfo, Map.class);
    	
    	String nssserverhost=resultMap.get("content").get("nssserverhost").toString();
    	String nssserverport=resultMap.get("content").get("nssserverport").toString();
    	String user_token=resultMap.get("content").get("user_token").toString();


 
         
            //par1 是任意参数
            if(snoSocketMap.get(sno)!=null) {
            	socket=snoSocketMap.get(sno);
            }else {
            	socket =IO.socket("http://127.0.0.1:"+nssserverport+"?sno="+sno+"&connect=web&user_token="+ user_token);
                socket.connect();
                snoSocketMap.put(sno, socket);
            }
            int count=0;
            while(!socket.connected()&&count<3) {
            	
            	socket.disconnect();
            	 params=new HashMap<>();
            	params.put("username", "qianyi2018web");
            	params.put("password", "copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k=");
            	params.put("sno", sno);
            	
            	 resultInfo="";
        		try {
        			resultInfo = HttpUtil.doPost(url+"/weblogin", com.alibaba.fastjson.JSONObject.toJSONString(params));
        		} catch (Exception e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
            	
            	resultMap=(Map<String,Map<String,Object>>)com.alibaba.fastjson.JSONObject.parseObject(resultInfo, Map.class);
            	
            	 nssserverhost=resultMap.get("content").get("nssserverhost").toString();
            	 nssserverport=resultMap.get("content").get("nssserverport").toString();
            	 user_token=resultMap.get("content").get("user_token").toString();
            	 
            	 IO.Options options = new IO.Options();
                 options.transports = new String[]{"websocket"};
                 options.reconnectionAttempts = 2;
                 options.reconnectionDelay = 1000;//失败重连的时间间隔
                 options.timeout = 500;//连接超时时间(ms)

                 
                 final Socket  socket1 =IO.socket("http://127.0.0.1:"+nssserverport+"/?sno="+sno+"&connect=web&user_token="+ user_token,options);
        		
                 socket1.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                     @Override
                     public void call(Object... args) {
                    	 socket1.send("hello");
                     }
                 });
          
                 socket1.on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                     @Override
                     public void call(Object... args) {
                         System.out.println("连接关闭");
                     }
                 });
          
                 socket1.on(Socket.EVENT_MESSAGE, new Emitter.Listener() {
                     @Override
                     public void call(Object... args) {
                         System.out.println("sessionId:" + socket.id());
                         for (Object obj : args) {
                             System.out.println(obj);
                         }
                         System.out.println("收到服务器应答，将要断开连接...");
                         socket1.disconnect();
                     }
                 });
                 socket1.connect();
                 
                snoSocketMap.put(sno, socket1);
                socket=socket1;
                count++;
        	}
           
        socket.emit("Net_MESSAGE_SetupWeb","_"+sessionId,serverip,serverport,sno,1,"1002","");
        socket.emit("Net_MESSAGE_SetupWeb","_"+sessionId,serverip,serverport,sno,1,"1002","");

        //socket.disconnect();
    }
    
    public  static void sendUserDeviceConfigInfo(String url,String sno,String sessionId,String serverip,Integer  serverport,String sendMessage) throws URISyntaxException, Exception{
    	Map<String,Object> params=new HashMap<>();
    	params.put("username", "qianyi2018web");
    	params.put("password", "copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k=");
    	params.put("sno", sno);
    	
    	String resultInfo="";
		try {
			resultInfo = HttpUtil.doPost(url+"/weblogin", com.alibaba.fastjson.JSONObject.toJSONString(params));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	Map<String,Map<String,Object>> resultMap=(Map<String,Map<String,Object>>)com.alibaba.fastjson.JSONObject.parseObject(resultInfo, Map.class);
    	
    	String nssserverhost=resultMap.get("content").get("nssserverhost").toString();
    	String nssserverport=resultMap.get("content").get("nssserverport").toString();
    	String user_token=resultMap.get("content").get("user_token").toString();


 
         
            //par1 是任意参数
            if(snoSocketMap.get(sno)!=null) {
            	socket=snoSocketMap.get(sno);
            }else {
            	socket =IO.socket("http://127.0.0.1:"+nssserverport+"?sno="+sno+"&connect=web&user_token="+ user_token);
                socket.connect();
                snoSocketMap.put(sno, socket);
            }
            int count=0;
            while(!socket.connected()&&count<3) {
            	
            	socket.disconnect();
            	 params=new HashMap<>();
            	params.put("username", "qianyi2018web");
            	params.put("password", "copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k=");
            	params.put("sno", sno);
            	
            	 resultInfo="";
        		try {
        			resultInfo = HttpUtil.doPost(url+"/weblogin", com.alibaba.fastjson.JSONObject.toJSONString(params));
        		} catch (Exception e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
            	
            	resultMap=(Map<String,Map<String,Object>>)com.alibaba.fastjson.JSONObject.parseObject(resultInfo, Map.class);
            	
            	 nssserverhost=resultMap.get("content").get("nssserverhost").toString();
            	 nssserverport=resultMap.get("content").get("nssserverport").toString();
            	 user_token=resultMap.get("content").get("user_token").toString();
            	 
            	 IO.Options options = new IO.Options();
                 options.transports = new String[]{"websocket"};
                 options.reconnectionAttempts = 2;
                 options.reconnectionDelay = 1000;//失败重连的时间间隔
                 options.timeout = 500;//连接超时时间(ms)

                 
                 final Socket  socket1 =IO.socket("http://127.0.0.1:"+nssserverport+"/?sno="+sno+"&connect=web&user_token="+ user_token,options);
        		
                 socket1.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                     @Override
                     public void call(Object... args) {
                    	 socket1.send("hello");
                     }
                 });
          
                 socket1.on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                     @Override
                     public void call(Object... args) {
                         System.out.println("连接关闭");
                     }
                 });
          
                 socket1.on(Socket.EVENT_MESSAGE, new Emitter.Listener() {
                     @Override
                     public void call(Object... args) {
                         System.out.println("sessionId:" + socket.id());
                         for (Object obj : args) {
                             System.out.println(obj);
                         }
                         System.out.println("收到服务器应答，将要断开连接...");
                         socket1.disconnect();
                     }
                 });
                 socket1.connect();
                 
                snoSocketMap.put(sno, socket1);
                socket=socket1;
                count++;
        	}
           
        socket.emit("Net_MESSAGE_SetupWeb","_"+sessionId,serverip,serverport,sno,1,"1003",sendMessage);
        socket.emit("Net_MESSAGE_SetupWeb","_"+sessionId,serverip,serverport,sno,1,"1003",sendMessage);

        //socket.disconnect();
    }

    public  static void sendScrollPicture(String url,String sno,String sessionId,String serverip,Integer  serverport,String sendMessage) throws URISyntaxException, Exception{
        Map<String,Object> params=new HashMap<>();
        params.put("username", "qianyi2018web");
        params.put("password", "copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k=");
        params.put("sno", sno);

        String resultInfo="";
        try {
            resultInfo = HttpUtil.doPost(url+"/weblogin", com.alibaba.fastjson.JSONObject.toJSONString(params));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        Map<String,Map<String,Object>> resultMap=(Map<String,Map<String,Object>>)com.alibaba.fastjson.JSONObject.parseObject(resultInfo, Map.class);

        String nssserverhost=resultMap.get("content").get("nssserverhost").toString();
        String nssserverport=resultMap.get("content").get("nssserverport").toString();
        String user_token=resultMap.get("content").get("user_token").toString();




        //par1 是任意参数
        if(snoSocketMap.get(sno)!=null) {
            socket=snoSocketMap.get(sno);
        }else {
            socket =IO.socket("http://127.0.0.1:"+nssserverport+"?sno="+sno+"&connect=web&user_token="+ user_token);
            socket.connect();
            snoSocketMap.put(sno, socket);
        }
        int count=0;
        while(!socket.connected()&&count<3) {

            socket.disconnect();
            params=new HashMap<>();
            params.put("username", "qianyi2018web");
            params.put("password", "copeCXiXB6Jnk03DwT3nKVR+GC7b+0MtiT98HmrV2ZmXx5hSve/GbnKO2HZcYNRRkfr3502nyowt9O7KY5LycMlBBG/jm5jg09sXWLKnke2q28IWof34AHx2rYMMOflYGI09y8d9zngGRyPdf/T5rYgdfkPHBkw+IciyolE1z5k=");
            params.put("sno", sno);

            resultInfo="";
            try {
                resultInfo = HttpUtil.doPost(url+"/weblogin", com.alibaba.fastjson.JSONObject.toJSONString(params));
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            resultMap=(Map<String,Map<String,Object>>)com.alibaba.fastjson.JSONObject.parseObject(resultInfo, Map.class);

            nssserverhost=resultMap.get("content").get("nssserverhost").toString();
            nssserverport=resultMap.get("content").get("nssserverport").toString();
            user_token=resultMap.get("content").get("user_token").toString();

            IO.Options options = new IO.Options();
            options.transports = new String[]{"websocket"};
            options.reconnectionAttempts = 2;
            options.reconnectionDelay = 1000;//失败重连的时间间隔
            options.timeout = 500;//连接超时时间(ms)


            final Socket  socket1 =IO.socket("http://127.0.0.1:"+nssserverport+"/?sno="+sno+"&connect=web&user_token="+ user_token,options);

            socket1.on(Socket.EVENT_CONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    socket1.send("hello");
                }
            });

            socket1.on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    System.out.println("连接关闭");
                }
            });

            socket1.on(Socket.EVENT_MESSAGE, new Emitter.Listener() {
                @Override
                public void call(Object... args) {
                    System.out.println("sessionId:" + socket.id());
                    for (Object obj : args) {
                        System.out.println(obj);
                    }
                    System.out.println("收到服务器应答，将要断开连接...");
                    socket1.disconnect();
                }
            });
            socket1.connect();

            snoSocketMap.put(sno, socket1);
            socket=socket1;
            count++;
        }

        socket.emit("Net_MESSAGE_SetupWeb","_"+sessionId,serverip,serverport,sno,1,"2050",sendMessage);

        //socket.disconnect();
    }

}
