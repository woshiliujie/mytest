package com.cloud.userdevice.utils;

/**
 * Created by Administrator on 2019/4/28 0028.
 */
public class NumberUtils {

    public static Integer[] StringToInt(String[] strs){
        Integer[] ints = new Integer[strs.length];
        for(int i=0;i<strs.length;i++){
            ints[i] = Integer.parseInt(strs[i]);
        }
        return ints;
    }
}
