package com.gupaoedu.example.springcloudhystrixdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudHystrixDashboardApplicationTests {

    @Test
    void contextLoads() {
    }

}
