package com.gupaoedu.example.springcloudconfigserver9091;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigServer9091ApplicationTests {

    @Test
    void contextLoads() {
    }

}
