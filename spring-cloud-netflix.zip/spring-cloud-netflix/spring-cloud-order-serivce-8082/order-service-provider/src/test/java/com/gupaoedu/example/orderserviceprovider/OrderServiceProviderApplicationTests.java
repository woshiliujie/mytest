package com.gupaoedu.example.orderserviceprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServiceProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
