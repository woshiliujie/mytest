package com.gupaoedu.example.userserviceprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
