package com.gupaoedu.example.nacosdubboprovider.dubbo;

import org.springframework.context.annotation.Configuration;

/**
 * The typical configuration for Dubbo.
 * @author <a href="mailto:chenxilzx1@gmail.com">theonefx</a>
 */
@Configuration
public class DubboConfiguration {
}
