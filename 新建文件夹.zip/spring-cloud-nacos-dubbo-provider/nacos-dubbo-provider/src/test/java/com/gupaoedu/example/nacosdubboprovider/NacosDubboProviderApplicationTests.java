package com.gupaoedu.example.nacosdubboprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NacosDubboProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
