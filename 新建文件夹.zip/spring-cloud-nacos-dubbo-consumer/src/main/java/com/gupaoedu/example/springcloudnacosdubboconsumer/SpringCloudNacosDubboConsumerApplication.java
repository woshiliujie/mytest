package com.gupaoedu.example.springcloudnacosdubboconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudNacosDubboConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringCloudNacosDubboConsumerApplication.class, args);
    }

}
