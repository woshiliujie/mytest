package com.gupaoedu.example.springcloudnacosdubboconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudNacosDubboConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
